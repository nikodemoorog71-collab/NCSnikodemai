package E;

import android.os.Parcel;
import android.os.Parcelable;
import i.c1;

public final class b implements Parcelable.ClassLoaderCreator {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f51a;

    public /* synthetic */ b(int i2) {
        this.f51a = i2;
    }

    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        switch (this.f51a) {
            case 0:
                if (parcel.readParcelable(classLoader) == null) {
                    return c.b;
                }
                throw new IllegalStateException("superState must be null");
            default:
                return new c1(parcel, classLoader);
        }
    }

    public final Object[] newArray(int i2) {
        switch (this.f51a) {
            case 0:
                return new c[i2];
            default:
                return new c1[i2];
        }
    }

    public final Object createFromParcel(Parcel parcel) {
        switch (this.f51a) {
            case 0:
                if (parcel.readParcelable((ClassLoader) null) == null) {
                    return c.b;
                }
                throw new IllegalStateException("superState must be null");
            default:
                return new c1(parcel, (ClassLoader) null);
        }
    }
}
