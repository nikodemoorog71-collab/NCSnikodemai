package E;

import android.os.Parcel;
import android.os.Parcelable;

public abstract class c implements Parcelable {
    public static final Parcelable.Creator<c> CREATOR = new b(0);
    public static final a b = new c();

    /* renamed from: a  reason: collision with root package name */
    public final Parcelable f52a;

    public c() {
        this.f52a = null;
    }

    public final int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeParcelable(this.f52a, i2);
    }

    public c(Parcelable parcelable) {
        if (parcelable != null) {
            this.f52a = parcelable == b ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    public c(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        this.f52a = readParcelable == null ? b : readParcelable;
    }
}
