package E;

public final class a extends c {
}
