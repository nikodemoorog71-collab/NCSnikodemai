package s;

/* renamed from: s.d  reason: case insensitive filesystem */
public interface C0145d {
}
