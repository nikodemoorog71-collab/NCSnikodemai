package s;

import android.graphics.drawable.Drawable;

/* renamed from: s.b  reason: case insensitive filesystem */
public abstract class C0143b {
    public static int a(Drawable drawable) {
        return drawable.getLayoutDirection();
    }

    public static boolean b(Drawable drawable, int i2) {
        return drawable.setLayoutDirection(i2);
    }
}
