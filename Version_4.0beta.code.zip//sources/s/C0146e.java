package s;

import android.graphics.drawable.Drawable;

/* renamed from: s.e  reason: case insensitive filesystem */
public abstract class C0146e extends Drawable implements Drawable.Callback, C0145d {
    public abstract void a(Drawable drawable);
}
