package G;

import F.b;
import F.d;
import android.os.Bundle;
import android.text.Editable;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.widget.EditText;
import androidx.emoji2.text.g;
import androidx.emoji2.text.k;
import java.nio.ByteBuffer;

public final class c extends InputConnectionWrapper {

    /* renamed from: a  reason: collision with root package name */
    public final EditText f60a;
    public final d b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(EditText editText, InputConnection inputConnection, EditorInfo editorInfo) {
        super(inputConnection, false);
        int i2;
        d dVar = new d(1);
        this.f60a = editText;
        this.b = dVar;
        if (k.f518k != null) {
            k a2 = k.a();
            if (a2.b() == 1 && editorInfo != null) {
                if (editorInfo.extras == null) {
                    editorInfo.extras = new Bundle();
                }
                g gVar = a2.f522e;
                gVar.getClass();
                Bundle bundle = editorInfo.extras;
                b bVar = (b) gVar.f515c.f174a;
                int a3 = bVar.a(4);
                if (a3 != 0) {
                    i2 = ((ByteBuffer) bVar.f55d).getInt(a3 + bVar.f53a);
                } else {
                    i2 = 0;
                }
                bundle.putInt("android.support.text.emoji.emojiCompat_metadataVersion", i2);
                Bundle bundle2 = editorInfo.extras;
                gVar.f514a.getClass();
                bundle2.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", false);
            }
        }
    }

    public final boolean deleteSurroundingText(int i2, int i3) {
        Editable editableText = this.f60a.getEditableText();
        this.b.getClass();
        if (d.f(this, editableText, i2, i3, false) || super.deleteSurroundingText(i2, i3)) {
            return true;
        }
        return false;
    }

    public final boolean deleteSurroundingTextInCodePoints(int i2, int i3) {
        Editable editableText = this.f60a.getEditableText();
        this.b.getClass();
        if (d.f(this, editableText, i2, i3, true) || super.deleteSurroundingTextInCodePoints(i2, i3)) {
            return true;
        }
        return false;
    }
}
