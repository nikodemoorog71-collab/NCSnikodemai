package G;

import D.g;
import android.text.InputFilter;
import android.widget.TextView;
import androidx.emoji2.text.k;

public final class h extends g {

    /* renamed from: o  reason: collision with root package name */
    public final g f67o;

    public h(TextView textView) {
        this.f67o = new g(textView);
    }

    public final void N(boolean z2) {
        boolean z3;
        if (k.f518k != null) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (z3) {
            this.f67o.N(z2);
        }
    }

    public final void O(boolean z2) {
        boolean z3;
        if (k.f518k != null) {
            z3 = true;
        } else {
            z3 = false;
        }
        g gVar = this.f67o;
        if (!z3) {
            gVar.f66q = z2;
        } else {
            gVar.O(z2);
        }
    }

    public final InputFilter[] u(InputFilter[] inputFilterArr) {
        boolean z2;
        if (k.f518k != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (!z2) {
            return inputFilterArr;
        }
        return this.f67o.u(inputFilterArr);
    }
}
