package G;

import C.h;
import F.d;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.View;

public final class f implements KeyListener {

    /* renamed from: a  reason: collision with root package name */
    public final KeyListener f63a;
    public final d b;

    public f(KeyListener keyListener) {
        d dVar = new d(2);
        this.f63a = keyListener;
        this.b = dVar;
    }

    public final void clearMetaKeyState(View view, Editable editable, int i2) {
        this.f63a.clearMetaKeyState(view, editable, i2);
    }

    public final int getInputType() {
        return this.f63a.getInputType();
    }

    public final boolean onKeyDown(View view, Editable editable, int i2, KeyEvent keyEvent) {
        boolean z2;
        boolean z3;
        this.b.getClass();
        if (i2 == 67) {
            z2 = h.f(editable, keyEvent, false);
        } else if (i2 != 112) {
            z2 = false;
        } else {
            z2 = h.f(editable, keyEvent, true);
        }
        if (z2) {
            MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
            z3 = true;
        } else {
            z3 = false;
        }
        if (z3 || this.f63a.onKeyDown(view, editable, i2, keyEvent)) {
            return true;
        }
        return false;
    }

    public final boolean onKeyOther(View view, Editable editable, KeyEvent keyEvent) {
        return this.f63a.onKeyOther(view, editable, keyEvent);
    }

    public final boolean onKeyUp(View view, Editable editable, int i2, KeyEvent keyEvent) {
        return this.f63a.onKeyUp(view, editable, i2, keyEvent);
    }
}
