package G;

import C.j;
import D.b;
import F.d;
import Q.o;
import a0.c;
import android.content.Context;
import android.os.Handler;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.ActionMode;
import android.view.Menu;
import android.view.ViewGroup;
import androidx.activity.s;
import androidx.activity.t;
import androidx.emoji2.text.p;
import androidx.emoji2.text.w;
import androidx.emoji2.text.x;
import androidx.emoji2.text.z;
import androidx.fragment.app.k;
import androidx.fragment.app.l;
import e.C0012C;
import e.r;
import g.C0025a;
import g.C0029e;
import h.C;
import h.n;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import v.e;
import y.C0180y;
import y.K;
import y.Q;

public final class a implements o, p {

    /* renamed from: a  reason: collision with root package name */
    public Object f57a;
    public final Object b;

    public /* synthetic */ a(Object obj, Object obj2) {
        this.f57a = obj;
        this.b = obj2;
    }

    public void a() {
        t tVar = (t) this.b;
        U.a aVar = tVar.b;
        k kVar = (k) this.f57a;
        aVar.remove((Object) kVar);
        if (c.a(tVar.f312c, kVar)) {
            kVar.getClass();
            tVar.f312c = null;
        }
        kVar.b.remove(this);
        s sVar = kVar.f593c;
        if (sVar != null) {
            sVar.a();
        }
        kVar.f593c = null;
    }

    public File b() {
        if (((File) this.f57a) == null) {
            this.f57a = new File(((Context) this.b).getCacheDir(), "volley");
        }
        return (File) this.f57a;
    }

    public boolean c(CharSequence charSequence, int i2, int i3, w wVar) {
        Spannable spannable;
        if ((wVar.f548c & 4) > 0) {
            return true;
        }
        if (((z) this.f57a) == null) {
            if (charSequence instanceof Spannable) {
                spannable = (Spannable) charSequence;
            } else {
                spannable = new SpannableString(charSequence);
            }
            this.f57a = new z(spannable);
        }
        ((d) this.b).getClass();
        ((z) this.f57a).setSpan(new x(wVar), i2, i3, 33);
        return true;
    }

    public void d() {
        Iterator it = ((CopyOnWriteArrayList) this.b).iterator();
        while (it.hasNext()) {
            androidx.fragment.app.p pVar = ((l) it.next()).f595a;
            if (pVar.f615q >= 1) {
                for (Object obj : pVar.f602c.n()) {
                    if (obj != null) {
                        throw new ClassCastException();
                    }
                }
                continue;
            }
        }
    }

    public void e(C0025a aVar) {
        Q.t tVar = (Q.t) this.f57a;
        ((ActionMode.Callback) tVar.f174a).onDestroyActionMode(tVar.a(aVar));
        C0012C c2 = (C0012C) this.b;
        if (c2.f778w != null) {
            c2.f767l.getDecorView().removeCallbacks(c2.f779x);
        }
        if (c2.f777v != null) {
            Q q2 = c2.f780y;
            if (q2 != null) {
                q2.b();
            }
            Q a2 = K.a(c2.f777v);
            a2.a(0.0f);
            c2.f780y = a2;
            a2.d(new r(2, this));
        }
        c2.f776u = null;
        ViewGroup viewGroup = c2.f734A;
        WeakHashMap weakHashMap = K.f1547a;
        C0180y.c(viewGroup);
        c2.H();
    }

    public void f() {
        Iterator it = ((CopyOnWriteArrayList) this.b).iterator();
        while (it.hasNext()) {
            androidx.fragment.app.p pVar = ((l) it.next()).f595a;
            if (pVar.f615q >= 1) {
                for (Object obj : pVar.f602c.n()) {
                    if (obj != null) {
                        throw new ClassCastException();
                    }
                }
                continue;
            }
        }
    }

    public boolean g(C0025a aVar, n nVar) {
        ViewGroup viewGroup = ((C0012C) this.b).f734A;
        WeakHashMap weakHashMap = K.f1547a;
        C0180y.c(viewGroup);
        Q.t tVar = (Q.t) this.f57a;
        C0029e a2 = tVar.a(aVar);
        l.k kVar = (l.k) tVar.f176d;
        Menu menu = (Menu) kVar.getOrDefault(nVar, (Object) null);
        if (menu == null) {
            menu = new C((Context) tVar.b, nVar);
            kVar.put(nVar, menu);
        }
        return ((ActionMode.Callback) tVar.f174a).onPrepareActionMode(a2, menu);
    }

    public void h() {
        Iterator it = ((CopyOnWriteArrayList) this.b).iterator();
        while (it.hasNext()) {
            androidx.fragment.app.p pVar = ((l) it.next()).f595a;
            if (pVar.f615q >= 1) {
                for (Object obj : pVar.f602c.n()) {
                    if (obj != null) {
                        throw new ClassCastException();
                    }
                }
                continue;
            }
        }
    }

    public Object i() {
        return (z) this.f57a;
    }

    public void j(e eVar) {
        int i2 = eVar.b;
        Handler handler = (Handler) this.b;
        j jVar = (j) this.f57a;
        if (i2 == 0) {
            handler.post(new Q.c(jVar, 4, eVar.f1531a));
        } else {
            handler.post(new b(jVar, i2));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:58:0x00d3  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x0189 A[LOOP:0: B:1:0x0004->B:93:0x0189, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x01a5 A[EDGE_INSN: B:94:0x01a5->B:95:? ?: BREAK  , SYNTHETIC, Splitter:B:94:0x01a5] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Q.k k(R.h r14) {
        /*
            r13 = this;
            long r0 = android.os.SystemClock.elapsedRealtime()
        L_0x0004:
            r2 = 0
            Q.b r3 = r14.f202l     // Catch:{ IOException -> 0x00c9 }
            if (r3 != 0) goto L_0x000f
            java.util.Map r3 = java.util.Collections.EMPTY_MAP     // Catch:{ IOException -> 0x000c }
            goto L_0x0046
        L_0x000c:
            r3 = move-exception
            goto L_0x00cd
        L_0x000f:
            java.util.HashMap r4 = new java.util.HashMap     // Catch:{ IOException -> 0x000c }
            r4.<init>()     // Catch:{ IOException -> 0x000c }
            java.lang.String r5 = r3.b     // Catch:{ IOException -> 0x000c }
            if (r5 == 0) goto L_0x001d
            java.lang.String r6 = "If-None-Match"
            r4.put(r6, r5)     // Catch:{ IOException -> 0x000c }
        L_0x001d:
            long r5 = r3.f134d     // Catch:{ IOException -> 0x000c }
            r7 = 0
            int r3 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r3 <= 0) goto L_0x0045
            java.lang.String r3 = "EEE, dd MMM yyyy HH:mm:ss 'GMT'"
            java.text.SimpleDateFormat r7 = new java.text.SimpleDateFormat     // Catch:{ IOException -> 0x000c }
            java.util.Locale r8 = java.util.Locale.US     // Catch:{ IOException -> 0x000c }
            r7.<init>(r3, r8)     // Catch:{ IOException -> 0x000c }
            java.lang.String r3 = "GMT"
            java.util.TimeZone r3 = java.util.TimeZone.getTimeZone(r3)     // Catch:{ IOException -> 0x000c }
            r7.setTimeZone(r3)     // Catch:{ IOException -> 0x000c }
            java.util.Date r3 = new java.util.Date     // Catch:{ IOException -> 0x000c }
            r3.<init>(r5)     // Catch:{ IOException -> 0x000c }
            java.lang.String r3 = r7.format(r3)     // Catch:{ IOException -> 0x000c }
            java.lang.String r5 = "If-Modified-Since"
            r4.put(r5, r3)     // Catch:{ IOException -> 0x000c }
        L_0x0045:
            r3 = r4
        L_0x0046:
            java.lang.Object r4 = r13.f57a     // Catch:{ IOException -> 0x00cc }
            F.d r4 = (F.d) r4     // Catch:{ IOException -> 0x00cc }
            R.b r3 = r4.d(r14, r3)     // Catch:{ IOException -> 0x00c9 }
            int r4 = r3.f178a     // Catch:{ IOException -> 0x0062 }
            java.util.ArrayList r5 = r3.b     // Catch:{ IOException -> 0x0062 }
            java.util.List r5 = java.util.Collections.unmodifiableList(r5)     // Catch:{ IOException -> 0x0062 }
            r6 = 304(0x130, float:4.26E-43)
            if (r4 != r6) goto L_0x0068
            android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0062 }
            Q.k r14 = D.g.w(r14, r5)     // Catch:{ IOException -> 0x0062 }
            return r14
        L_0x0062:
            r4 = move-exception
            r12 = r3
            r3 = r2
            r2 = r12
            goto L_0x00cf
        L_0x0068:
            java.lang.Object r6 = r3.f180d     // Catch:{ IOException -> 0x0062 }
            java.io.InputStream r6 = (java.io.InputStream) r6     // Catch:{ IOException -> 0x0062 }
            if (r6 == 0) goto L_0x006f
            goto L_0x0070
        L_0x006f:
            r6 = r2
        L_0x0070:
            r7 = 0
            if (r6 == 0) goto L_0x007e
            int r8 = r3.f179c     // Catch:{ IOException -> 0x0062 }
            java.lang.Object r9 = r13.b     // Catch:{ IOException -> 0x0062 }
            R.b r9 = (R.b) r9     // Catch:{ IOException -> 0x0062 }
            byte[] r2 = D.g.z(r6, r8, r9)     // Catch:{ IOException -> 0x0062 }
            goto L_0x0080
        L_0x007e:
            byte[] r2 = new byte[r7]     // Catch:{ IOException -> 0x0062 }
        L_0x0080:
            long r8 = android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0062 }
            long r8 = r8 - r0
            boolean r6 = Q.s.f173a     // Catch:{ IOException -> 0x0062 }
            if (r6 != 0) goto L_0x008f
            r10 = 3000(0xbb8, double:1.482E-320)
            int r6 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r6 <= 0) goto L_0x00b2
        L_0x008f:
            java.lang.Long r6 = java.lang.Long.valueOf(r8)     // Catch:{ IOException -> 0x0062 }
            if (r2 == 0) goto L_0x009b
            int r8 = r2.length     // Catch:{ IOException -> 0x0062 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ IOException -> 0x0062 }
            goto L_0x009d
        L_0x009b:
            java.lang.String r8 = "null"
        L_0x009d:
            java.lang.Integer r9 = java.lang.Integer.valueOf(r4)     // Catch:{ IOException -> 0x0062 }
            Q.f r10 = r14.f201k     // Catch:{ IOException -> 0x0062 }
            int r10 = r10.b     // Catch:{ IOException -> 0x0062 }
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ IOException -> 0x0062 }
            java.lang.Object[] r6 = new java.lang.Object[]{r14, r6, r8, r9, r10}     // Catch:{ IOException -> 0x0062 }
            java.lang.String r8 = "HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]"
            Q.s.b(r8, r6)     // Catch:{ IOException -> 0x0062 }
        L_0x00b2:
            r6 = 200(0xc8, float:2.8E-43)
            if (r4 < r6) goto L_0x00c3
            r6 = 299(0x12b, float:4.19E-43)
            if (r4 > r6) goto L_0x00c3
            Q.k r4 = new Q.k     // Catch:{ IOException -> 0x0062 }
            android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0062 }
            r4.<init>(r2, r7, r5)     // Catch:{ IOException -> 0x0062 }
            return r4
        L_0x00c3:
            java.io.IOException r4 = new java.io.IOException     // Catch:{ IOException -> 0x0062 }
            r4.<init>()     // Catch:{ IOException -> 0x0062 }
            throw r4     // Catch:{ IOException -> 0x0062 }
        L_0x00c9:
            r4 = move-exception
        L_0x00ca:
            r3 = r2
            goto L_0x00cf
        L_0x00cc:
            r3 = move-exception
        L_0x00cd:
            r4 = r3
            goto L_0x00ca
        L_0x00cf:
            boolean r5 = r4 instanceof java.net.SocketTimeoutException
            if (r5 == 0) goto L_0x00e1
            G.a r2 = new G.a
            Q.a r3 = new Q.a
            r3.<init>()
            java.lang.String r4 = "socket"
            r2.<init>((java.lang.Object) r4, (java.lang.Object) r3)
            goto L_0x016b
        L_0x00e1:
            boolean r5 = r4 instanceof java.net.MalformedURLException
            java.lang.String r6 = r14.f194c
            if (r5 != 0) goto L_0x01c8
            if (r2 == 0) goto L_0x01c2
            int r4 = r2.f178a
            java.lang.Integer r5 = java.lang.Integer.valueOf(r4)
            java.lang.Object[] r5 = new java.lang.Object[]{r5, r6}
            java.lang.String r6 = "Unexpected response code %d for %s"
            Q.s.c(r6, r5)
            if (r3 == 0) goto L_0x015f
            java.util.ArrayList r2 = r2.b
            java.util.List r2 = java.util.Collections.unmodifiableList(r2)
            android.os.SystemClock.elapsedRealtime()
            if (r2 != 0) goto L_0x0106
            goto L_0x012e
        L_0x0106:
            boolean r3 = r2.isEmpty()
            if (r3 == 0) goto L_0x010f
            java.util.Map r3 = java.util.Collections.EMPTY_MAP
            goto L_0x012e
        L_0x010f:
            java.util.TreeMap r3 = new java.util.TreeMap
            java.util.Comparator r5 = java.lang.String.CASE_INSENSITIVE_ORDER
            r3.<init>(r5)
            java.util.Iterator r5 = r2.iterator()
        L_0x011a:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x012e
            java.lang.Object r6 = r5.next()
            Q.i r6 = (Q.i) r6
            java.lang.String r7 = r6.f150a
            java.lang.String r6 = r6.b
            r3.put(r7, r6)
            goto L_0x011a
        L_0x012e:
            if (r2 != 0) goto L_0x0131
            goto L_0x0134
        L_0x0131:
            java.util.Collections.unmodifiableList(r2)
        L_0x0134:
            r2 = 401(0x191, float:5.62E-43)
            if (r4 == r2) goto L_0x0152
            r2 = 403(0x193, float:5.65E-43)
            if (r4 != r2) goto L_0x013d
            goto L_0x0152
        L_0x013d:
            r14 = 400(0x190, float:5.6E-43)
            if (r4 < r14) goto L_0x014c
            r14 = 499(0x1f3, float:6.99E-43)
            if (r4 <= r14) goto L_0x0146
            goto L_0x014c
        L_0x0146:
            Q.e r14 = new Q.e
            r14.<init>()
            throw r14
        L_0x014c:
            Q.a r14 = new Q.a
            r14.<init>()
            throw r14
        L_0x0152:
            G.a r2 = new G.a
            Q.a r3 = new Q.a
            r3.<init>()
            java.lang.String r4 = "auth"
            r2.<init>((java.lang.Object) r4, (java.lang.Object) r3)
            goto L_0x016b
        L_0x015f:
            G.a r2 = new G.a
            Q.a r3 = new Q.a
            r3.<init>()
            java.lang.String r4 = "network"
            r2.<init>((java.lang.Object) r4, (java.lang.Object) r3)
        L_0x016b:
            java.lang.Object r3 = r2.f57a
            java.lang.String r3 = (java.lang.String) r3
            java.lang.String r4 = "]"
            Q.f r5 = r14.f201k
            int r6 = r5.f145a
            java.lang.Object r2 = r2.b     // Catch:{ p -> 0x01a6 }
            Q.p r2 = (Q.p) r2     // Catch:{ p -> 0x01a6 }
            int r7 = r5.b     // Catch:{ p -> 0x01a6 }
            r8 = 1
            int r7 = r7 + r8
            r5.b = r7     // Catch:{ p -> 0x01a6 }
            float r9 = (float) r6     // Catch:{ p -> 0x01a6 }
            r10 = 1065353216(0x3f800000, float:1.0)
            float r9 = r9 * r10
            int r9 = (int) r9     // Catch:{ p -> 0x01a6 }
            int r9 = r9 + r6
            r5.f145a = r9     // Catch:{ p -> 0x01a6 }
            if (r7 > r8) goto L_0x01a5
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r3)
            java.lang.String r3 = "-retry [timeout="
            r2.append(r3)
            r2.append(r6)
            r2.append(r4)
            java.lang.String r2 = r2.toString()
            r14.a(r2)
            goto L_0x0004
        L_0x01a5:
            throw r2     // Catch:{ p -> 0x01a6 }
        L_0x01a6:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r3)
            java.lang.String r2 = "-timeout-giveup [timeout="
            r1.append(r2)
            r1.append(r6)
            r1.append(r4)
            java.lang.String r1 = r1.toString()
            r14.a(r1)
            throw r0
        L_0x01c2:
            Q.l r14 = new Q.l
            r14.<init>(r4)
            throw r14
        L_0x01c8:
            java.lang.RuntimeException r14 = new java.lang.RuntimeException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Bad URL "
            r0.<init>(r1)
            r0.append(r6)
            java.lang.String r0 = r0.toString()
            r14.<init>(r0, r4)
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: G.a.k(R.h):Q.k");
    }

    /* JADX WARNING: type inference failed for: r3v12, types: [S.l, android.os.AsyncTask] */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x005a A[SYNTHETIC, Splitter:B:15:0x005a] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005e A[Catch:{ JSONException -> 0x004c }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void u(java.lang.String r27) {
        /*
            r26 = this;
            r1 = r26
            java.lang.String r0 = "ad_button_text_color"
            java.lang.String r2 = "ad_text_color"
            java.lang.String r3 = "ad_button_text"
            java.lang.String r4 = "ad_price"
            java.lang.String r5 = "ad_rating_color"
            java.lang.String r6 = "ad_rating"
            java.lang.String r7 = "ad_url"
            java.lang.String r8 = "ad_icon"
            java.lang.String r9 = "ad_desc"
            java.lang.String r10 = "ad_title"
            java.lang.String r11 = "request_id"
            java.lang.String r12 = "ad_display"
            java.lang.String r13 = "ad_button_background_color"
            org.json.JSONObject r14 = new org.json.JSONObject     // Catch:{ JSONException -> 0x004c }
            r15 = r27
            r14.<init>(r15)     // Catch:{ JSONException -> 0x004c }
            java.lang.String r15 = "0"
            java.lang.String r16 = "WebIntoApp"
            java.lang.String r17 = "Convert your Website / HTML files into your own mobile App for Android and iOS, online & within a minute!"
            java.lang.String r18 = ""
            java.lang.String r19 = "https://www.webintoapp.com"
            java.lang.String r20 = "5"
            java.lang.String r21 = "#fdcc0d"
            java.lang.String r22 = "FREE | DEDICATED"
            java.lang.String r23 = "#ffffff"
            java.lang.String r24 = "Click Here"
            boolean r25 = r14.has(r12)     // Catch:{ JSONException -> 0x004c }
            r27 = r15
            java.lang.String r15 = "true"
            if (r25 == 0) goto L_0x004f
            boolean r25 = r14.isNull(r12)     // Catch:{ JSONException -> 0x004c }
            if (r25 != 0) goto L_0x004f
            java.lang.String r12 = r14.getString(r12)     // Catch:{ JSONException -> 0x004c }
            goto L_0x0050
        L_0x004c:
            r0 = move-exception
            goto L_0x0240
        L_0x004f:
            r12 = r15
        L_0x0050:
            boolean r12 = r12.equals(r15)     // Catch:{ JSONException -> 0x004c }
            java.lang.Object r15 = r1.f57a
            nikodemai.firmware.ncs.MainActivity r15 = (nikodemai.firmware.ncs.MainActivity) r15
            if (r12 != 0) goto L_0x005e
            r15.finish()     // Catch:{ JSONException -> 0x004c }
            return
        L_0x005e:
            boolean r12 = r14.has(r11)     // Catch:{ JSONException -> 0x004c }
            if (r12 == 0) goto L_0x006f
            boolean r12 = r14.isNull(r11)     // Catch:{ JSONException -> 0x004c }
            if (r12 != 0) goto L_0x006f
            java.lang.String r11 = r14.getString(r11)     // Catch:{ JSONException -> 0x004c }
            goto L_0x0071
        L_0x006f:
            r11 = r27
        L_0x0071:
            boolean r12 = r14.has(r10)     // Catch:{ JSONException -> 0x004c }
            if (r12 == 0) goto L_0x0081
            boolean r12 = r14.isNull(r10)     // Catch:{ JSONException -> 0x004c }
            if (r12 != 0) goto L_0x0081
            java.lang.String r16 = r14.getString(r10)     // Catch:{ JSONException -> 0x004c }
        L_0x0081:
            r10 = r16
            boolean r12 = r14.has(r9)     // Catch:{ JSONException -> 0x004c }
            if (r12 == 0) goto L_0x0093
            boolean r12 = r14.isNull(r9)     // Catch:{ JSONException -> 0x004c }
            if (r12 != 0) goto L_0x0093
            java.lang.String r17 = r14.getString(r9)     // Catch:{ JSONException -> 0x004c }
        L_0x0093:
            r9 = r17
            boolean r12 = r14.has(r8)     // Catch:{ JSONException -> 0x004c }
            if (r12 == 0) goto L_0x00a5
            boolean r12 = r14.isNull(r8)     // Catch:{ JSONException -> 0x004c }
            if (r12 != 0) goto L_0x00a5
            java.lang.String r18 = r14.getString(r8)     // Catch:{ JSONException -> 0x004c }
        L_0x00a5:
            boolean r8 = r14.has(r7)     // Catch:{ JSONException -> 0x004c }
            if (r8 == 0) goto L_0x00b5
            boolean r8 = r14.isNull(r7)     // Catch:{ JSONException -> 0x004c }
            if (r8 != 0) goto L_0x00b5
            java.lang.String r19 = r14.getString(r7)     // Catch:{ JSONException -> 0x004c }
        L_0x00b5:
            r7 = r19
            boolean r8 = r14.has(r6)     // Catch:{ JSONException -> 0x004c }
            if (r8 == 0) goto L_0x00c7
            boolean r8 = r14.isNull(r6)     // Catch:{ JSONException -> 0x004c }
            if (r8 != 0) goto L_0x00c7
            java.lang.String r20 = r14.getString(r6)     // Catch:{ JSONException -> 0x004c }
        L_0x00c7:
            boolean r6 = r14.has(r5)     // Catch:{ JSONException -> 0x004c }
            if (r6 == 0) goto L_0x00d7
            boolean r6 = r14.isNull(r5)     // Catch:{ JSONException -> 0x004c }
            if (r6 != 0) goto L_0x00d7
            java.lang.String r21 = r14.getString(r5)     // Catch:{ JSONException -> 0x004c }
        L_0x00d7:
            boolean r5 = r14.has(r4)     // Catch:{ JSONException -> 0x004c }
            if (r5 == 0) goto L_0x00e7
            boolean r5 = r14.isNull(r4)     // Catch:{ JSONException -> 0x004c }
            if (r5 != 0) goto L_0x00e7
            java.lang.String r22 = r14.getString(r4)     // Catch:{ JSONException -> 0x004c }
        L_0x00e7:
            r4 = r22
            boolean r5 = r14.has(r3)     // Catch:{ JSONException -> 0x004c }
            if (r5 == 0) goto L_0x00f9
            boolean r5 = r14.isNull(r3)     // Catch:{ JSONException -> 0x004c }
            if (r5 != 0) goto L_0x00f9
            java.lang.String r24 = r14.getString(r3)     // Catch:{ JSONException -> 0x004c }
        L_0x00f9:
            r3 = r24
            boolean r5 = r14.has(r2)     // Catch:{ JSONException -> 0x004c }
            java.lang.String r6 = "#000000"
            if (r5 == 0) goto L_0x010e
            boolean r5 = r14.isNull(r2)     // Catch:{ JSONException -> 0x004c }
            if (r5 != 0) goto L_0x010e
            java.lang.String r2 = r14.getString(r2)     // Catch:{ JSONException -> 0x004c }
            goto L_0x010f
        L_0x010e:
            r2 = r6
        L_0x010f:
            boolean r5 = r14.has(r0)     // Catch:{ JSONException -> 0x004c }
            if (r5 == 0) goto L_0x011f
            boolean r5 = r14.isNull(r0)     // Catch:{ JSONException -> 0x004c }
            if (r5 != 0) goto L_0x011f
            java.lang.String r6 = r14.getString(r0)     // Catch:{ JSONException -> 0x004c }
        L_0x011f:
            boolean r0 = r14.has(r13)     // Catch:{ JSONException -> 0x004c }
            if (r0 == 0) goto L_0x012f
            boolean r0 = r14.isNull(r13)     // Catch:{ JSONException -> 0x004c }
            if (r0 != 0) goto L_0x012f
            java.lang.String r23 = r14.getString(r13)     // Catch:{ JSONException -> 0x004c }
        L_0x012f:
            boolean r0 = r14.has(r13)     // Catch:{ JSONException -> 0x004c }
            if (r0 == 0) goto L_0x013f
            boolean r0 = r14.isNull(r13)     // Catch:{ JSONException -> 0x004c }
            if (r0 != 0) goto L_0x013f
            java.lang.String r23 = r14.getString(r13)     // Catch:{ JSONException -> 0x004c }
        L_0x013f:
            android.app.Dialog r0 = new android.app.Dialog     // Catch:{ JSONException -> 0x004c }
            r0.<init>(r15)     // Catch:{ JSONException -> 0x004c }
            r5 = 2131427359(0x7f0b001f, float:1.8476332E38)
            r0.setContentView(r5)     // Catch:{ JSONException -> 0x004c }
            r0.setTitle(r10)     // Catch:{ JSONException -> 0x004c }
            r5 = 2131230790(0x7f080046, float:1.8077643E38)
            android.view.View r5 = r0.findViewById(r5)     // Catch:{ JSONException -> 0x004c }
            android.widget.TextView r5 = (android.widget.TextView) r5     // Catch:{ JSONException -> 0x004c }
            r5.setText(r10)     // Catch:{ JSONException -> 0x004c }
            int r8 = android.graphics.Color.parseColor(r2)     // Catch:{ JSONException -> 0x004c }
            r5.setTextColor(r8)     // Catch:{ JSONException -> 0x004c }
            r5 = 2131230786(0x7f080042, float:1.8077635E38)
            android.view.View r5 = r0.findViewById(r5)     // Catch:{ JSONException -> 0x004c }
            android.widget.TextView r5 = (android.widget.TextView) r5     // Catch:{ JSONException -> 0x004c }
            r5.setText(r9)     // Catch:{ JSONException -> 0x004c }
            int r8 = android.graphics.Color.parseColor(r2)     // Catch:{ JSONException -> 0x004c }
            r5.setTextColor(r8)     // Catch:{ JSONException -> 0x004c }
            r5 = 2131230788(0x7f080044, float:1.8077639E38)
            android.view.View r5 = r0.findViewById(r5)     // Catch:{ JSONException -> 0x004c }
            android.widget.TextView r5 = (android.widget.TextView) r5     // Catch:{ JSONException -> 0x004c }
            r5.setText(r4)     // Catch:{ JSONException -> 0x004c }
            int r2 = android.graphics.Color.parseColor(r2)     // Catch:{ JSONException -> 0x004c }
            r5.setTextColor(r2)     // Catch:{ JSONException -> 0x004c }
            r2 = 2131230785(0x7f080041, float:1.8077633E38)
            android.view.View r2 = r0.findViewById(r2)     // Catch:{ JSONException -> 0x004c }
            android.widget.Button r2 = (android.widget.Button) r2     // Catch:{ JSONException -> 0x004c }
            r2.setText(r3)     // Catch:{ JSONException -> 0x004c }
            int r3 = android.graphics.Color.parseColor(r6)     // Catch:{ JSONException -> 0x004c }
            r2.setTextColor(r3)     // Catch:{ JSONException -> 0x004c }
            r3 = 2131165274(0x7f07005a, float:1.794476E38)
            r2.setBackgroundResource(r3)     // Catch:{ JSONException -> 0x004c }
            android.graphics.drawable.Drawable r3 = r2.getBackground()     // Catch:{ JSONException -> 0x004c }
            android.graphics.drawable.GradientDrawable r3 = (android.graphics.drawable.GradientDrawable) r3     // Catch:{ JSONException -> 0x004c }
            int r4 = android.graphics.Color.parseColor(r23)     // Catch:{ JSONException -> 0x004c }
            r3.setColor(r4)     // Catch:{ JSONException -> 0x004c }
            r3 = 2131230789(0x7f080045, float:1.807764E38)
            android.view.View r3 = r0.findViewById(r3)     // Catch:{ JSONException -> 0x004c }
            androidx.appcompat.widget.AppCompatRatingBar r3 = (androidx.appcompat.widget.AppCompatRatingBar) r3     // Catch:{ JSONException -> 0x004c }
            float r4 = java.lang.Float.parseFloat(r20)     // Catch:{ JSONException -> 0x004c }
            r3.setRating(r4)     // Catch:{ JSONException -> 0x004c }
            android.graphics.drawable.Drawable r3 = r3.getProgressDrawable()     // Catch:{ JSONException -> 0x004c }
            android.graphics.drawable.LayerDrawable r3 = (android.graphics.drawable.LayerDrawable) r3     // Catch:{ JSONException -> 0x004c }
            r4 = 2
            android.graphics.drawable.Drawable r4 = r3.getDrawable(r4)     // Catch:{ JSONException -> 0x004c }
            int r5 = android.graphics.Color.parseColor(r21)     // Catch:{ JSONException -> 0x004c }
            android.graphics.PorterDuff$Mode r6 = android.graphics.PorterDuff.Mode.SRC_ATOP     // Catch:{ JSONException -> 0x004c }
            r4.setColorFilter(r5, r6)     // Catch:{ JSONException -> 0x004c }
            r4 = 0
            android.graphics.drawable.Drawable r5 = r3.getDrawable(r4)     // Catch:{ JSONException -> 0x004c }
            r8 = -7829368(0xffffffffff888888, float:NaN)
            r5.setColorFilter(r8, r6)     // Catch:{ JSONException -> 0x004c }
            r5 = 1
            android.graphics.drawable.Drawable r3 = r3.getDrawable(r5)     // Catch:{ JSONException -> 0x004c }
            int r5 = android.graphics.Color.parseColor(r21)     // Catch:{ JSONException -> 0x004c }
            r3.setColorFilter(r5, r6)     // Catch:{ JSONException -> 0x004c }
            S.l r3 = new S.l     // Catch:{ JSONException -> 0x004c }
            r5 = 2131230784(0x7f080040, float:1.807763E38)
            android.view.View r5 = r0.findViewById(r5)     // Catch:{ JSONException -> 0x004c }
            android.widget.ImageView r5 = (android.widget.ImageView) r5     // Catch:{ JSONException -> 0x004c }
            r3.<init>()     // Catch:{ JSONException -> 0x004c }
            r3.f240a = r5     // Catch:{ JSONException -> 0x004c }
            java.lang.String[] r5 = new java.lang.String[]{r18}     // Catch:{ JSONException -> 0x004c }
            r3.execute(r5)     // Catch:{ JSONException -> 0x004c }
            S.h r3 = new S.h     // Catch:{ JSONException -> 0x004c }
            r3.<init>(r1, r7, r11, r0)     // Catch:{ JSONException -> 0x004c }
            r2.setOnClickListener(r3)     // Catch:{ JSONException -> 0x004c }
            S.i r2 = new S.i     // Catch:{ JSONException -> 0x004c }
            r2.<init>(r1)     // Catch:{ JSONException -> 0x004c }
            r0.setOnShowListener(r2)     // Catch:{ JSONException -> 0x004c }
            S.j r2 = new S.j     // Catch:{ JSONException -> 0x004c }
            r2.<init>(r1)     // Catch:{ JSONException -> 0x004c }
            r0.setOnDismissListener(r2)     // Catch:{ JSONException -> 0x004c }
            android.view.Window r2 = r0.getWindow()     // Catch:{ JSONException -> 0x004c }
            r3 = -1
            r5 = -2
            r2.setLayout(r3, r5)     // Catch:{ JSONException -> 0x004c }
            android.view.Window r2 = r0.getWindow()     // Catch:{ JSONException -> 0x004c }
            android.graphics.drawable.ColorDrawable r3 = new android.graphics.drawable.ColorDrawable     // Catch:{ JSONException -> 0x004c }
            r3.<init>(r4)     // Catch:{ JSONException -> 0x004c }
            r2.setBackgroundDrawable(r3)     // Catch:{ JSONException -> 0x004c }
            r2 = 2131230798(0x7f08004e, float:1.8077659E38)
            android.view.View r2 = r0.findViewById(r2)     // Catch:{ JSONException -> 0x004c }
            android.widget.ImageButton r2 = (android.widget.ImageButton) r2     // Catch:{ JSONException -> 0x004c }
            S.k r3 = new S.k     // Catch:{ JSONException -> 0x004c }
            r3.<init>(r1, r0)     // Catch:{ JSONException -> 0x004c }
            r2.setOnClickListener(r3)     // Catch:{ JSONException -> 0x004c }
            r0.show()     // Catch:{ JSONException -> 0x004c }
            return
        L_0x0240:
            r0.printStackTrace()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: G.a.u(java.lang.String):void");
    }

    public /* synthetic */ a(Object obj, Object obj2, boolean z2) {
        this.b = obj;
        this.f57a = obj2;
    }

    public a(Runnable runnable) {
        this.b = new CopyOnWriteArrayList();
        new HashMap();
        this.f57a = runnable;
    }

    public a(d dVar) {
        R.b bVar = new R.b();
        this.f57a = dVar;
        this.b = bVar;
    }

    public a(Context context) {
        this.b = context;
        this.f57a = null;
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [android.text.Editable$Factory, G.b] */
    /* JADX WARNING: Can't wrap try/catch for region: R(6:7|8|9|10|11|12) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x002e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public a(android.widget.EditText r6) {
        /*
            r5 = this;
            r5.<init>()
            r5.f57a = r6
            G.j r0 = new G.j
            r0.<init>(r6)
            r5.b = r0
            r6.addTextChangedListener(r0)
            G.b r0 = G.b.b
            if (r0 != 0) goto L_0x0037
            java.lang.Object r0 = G.b.f58a
            monitor-enter(r0)
            G.b r1 = G.b.b     // Catch:{ all -> 0x0031 }
            if (r1 != 0) goto L_0x0033
            G.b r1 = new G.b     // Catch:{ all -> 0x0031 }
            r1.<init>()     // Catch:{ all -> 0x0031 }
            java.lang.String r2 = "android.text.DynamicLayout$ChangeWatcher"
            java.lang.Class<G.b> r3 = G.b.class
            java.lang.ClassLoader r3 = r3.getClassLoader()     // Catch:{ all -> 0x002e }
            r4 = 0
            java.lang.Class r2 = java.lang.Class.forName(r2, r4, r3)     // Catch:{ all -> 0x002e }
            G.b.f59c = r2     // Catch:{ all -> 0x002e }
        L_0x002e:
            G.b.b = r1     // Catch:{ all -> 0x0031 }
            goto L_0x0033
        L_0x0031:
            r6 = move-exception
            goto L_0x0035
        L_0x0033:
            monitor-exit(r0)     // Catch:{ all -> 0x0031 }
            goto L_0x0037
        L_0x0035:
            monitor-exit(r0)     // Catch:{ all -> 0x0031 }
            throw r6
        L_0x0037:
            G.b r0 = G.b.b
            r6.setEditableFactory(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: G.a.<init>(android.widget.EditText):void");
    }

    public a(t tVar, k kVar) {
        c.e(kVar, "onBackPressedCallback");
        this.b = tVar;
        this.f57a = kVar;
    }
}
