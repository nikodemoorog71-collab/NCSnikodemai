package G;

import android.graphics.Rect;
import android.text.method.TransformationMethod;
import android.view.View;

public final class k implements TransformationMethod {

    /* renamed from: a  reason: collision with root package name */
    public final TransformationMethod f71a;

    public k(TransformationMethod transformationMethod) {
        this.f71a = transformationMethod;
    }

    public final CharSequence getTransformation(CharSequence charSequence, View view) {
        if (view.isInEditMode()) {
            return charSequence;
        }
        TransformationMethod transformationMethod = this.f71a;
        if (transformationMethod != null) {
            charSequence = transformationMethod.getTransformation(charSequence, view);
        }
        if (charSequence == null || androidx.emoji2.text.k.a().b() != 1) {
            return charSequence;
        }
        androidx.emoji2.text.k a2 = androidx.emoji2.text.k.a();
        a2.getClass();
        return a2.e(charSequence, 0, charSequence.length());
    }

    public final void onFocusChanged(View view, CharSequence charSequence, boolean z2, int i2, Rect rect) {
        TransformationMethod transformationMethod = this.f71a;
        if (transformationMethod != null) {
            transformationMethod.onFocusChanged(view, charSequence, z2, i2, rect);
        }
    }
}
