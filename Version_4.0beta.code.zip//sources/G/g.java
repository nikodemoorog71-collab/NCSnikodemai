package G;

import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.SparseArray;
import android.widget.TextView;

public final class g extends D.g {

    /* renamed from: o  reason: collision with root package name */
    public final TextView f64o;

    /* renamed from: p  reason: collision with root package name */
    public final e f65p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f66q = true;

    public g(TextView textView) {
        this.f64o = textView;
        this.f65p = new e(textView);
    }

    public final void N(boolean z2) {
        if (z2) {
            V();
        }
    }

    public final void O(boolean z2) {
        this.f66q = z2;
        V();
        TextView textView = this.f64o;
        textView.setFilters(u(textView.getFilters()));
    }

    public final void V() {
        TextView textView = this.f64o;
        TransformationMethod transformationMethod = textView.getTransformationMethod();
        if (this.f66q) {
            if (!(transformationMethod instanceof k) && !(transformationMethod instanceof PasswordTransformationMethod)) {
                transformationMethod = new k(transformationMethod);
            }
        } else if (transformationMethod instanceof k) {
            transformationMethod = ((k) transformationMethod).f71a;
        }
        textView.setTransformationMethod(transformationMethod);
    }

    public final InputFilter[] u(InputFilter[] inputFilterArr) {
        if (!this.f66q) {
            SparseArray sparseArray = new SparseArray(1);
            for (int i2 = 0; i2 < inputFilterArr.length; i2++) {
                InputFilter inputFilter = inputFilterArr[i2];
                if (inputFilter instanceof e) {
                    sparseArray.put(i2, inputFilter);
                }
            }
            if (sparseArray.size() == 0) {
                return inputFilterArr;
            }
            int length = inputFilterArr.length;
            InputFilter[] inputFilterArr2 = new InputFilter[(inputFilterArr.length - sparseArray.size())];
            int i3 = 0;
            for (int i4 = 0; i4 < length; i4++) {
                if (sparseArray.indexOfKey(i4) < 0) {
                    inputFilterArr2[i3] = inputFilterArr[i4];
                    i3++;
                }
            }
            return inputFilterArr2;
        }
        int length2 = inputFilterArr.length;
        int i5 = 0;
        while (true) {
            e eVar = this.f65p;
            if (i5 >= length2) {
                InputFilter[] inputFilterArr3 = new InputFilter[(inputFilterArr.length + 1)];
                System.arraycopy(inputFilterArr, 0, inputFilterArr3, 0, length2);
                inputFilterArr3[length2] = eVar;
                return inputFilterArr3;
            } else if (inputFilterArr[i5] == eVar) {
                return inputFilterArr;
            } else {
                i5++;
            }
        }
    }
}
