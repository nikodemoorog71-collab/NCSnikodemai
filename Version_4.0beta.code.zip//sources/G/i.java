package G;

import android.widget.EditText;
import androidx.emoji2.text.h;
import java.lang.ref.WeakReference;

public final class i extends h {

    /* renamed from: a  reason: collision with root package name */
    public final WeakReference f68a;

    public i(EditText editText) {
        this.f68a = new WeakReference(editText);
    }

    public final void a() {
        j.a((EditText) this.f68a.get(), 1);
    }
}
