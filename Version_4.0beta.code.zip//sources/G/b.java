package G;

import android.text.Editable;
import androidx.emoji2.text.v;

public final class b extends Editable.Factory {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f58a = new Object();
    public static volatile b b;

    /* renamed from: c  reason: collision with root package name */
    public static Class f59c;

    public final Editable newEditable(CharSequence charSequence) {
        Class cls = f59c;
        if (cls != null) {
            return new v(cls, charSequence);
        }
        return super.newEditable(charSequence);
    }
}
