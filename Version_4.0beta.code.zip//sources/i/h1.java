package i;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import java.util.WeakHashMap;
import nikodemai.firmware.ncs.R;
import y.K;
import y.L;
import y.N;

public final class h1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: k  reason: collision with root package name */
    public static h1 f1245k;

    /* renamed from: l  reason: collision with root package name */
    public static h1 f1246l;

    /* renamed from: a  reason: collision with root package name */
    public final View f1247a;
    public final CharSequence b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1248c;

    /* renamed from: d  reason: collision with root package name */
    public final g1 f1249d = new g1(this, 0);

    /* renamed from: e  reason: collision with root package name */
    public final g1 f1250e = new g1(this, 1);
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public int f1251g;

    /* renamed from: h  reason: collision with root package name */
    public i1 f1252h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f1253i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f1254j;

    public h1(View view, CharSequence charSequence) {
        int i2;
        this.f1247a = view;
        this.b = charSequence;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(view.getContext());
        int i3 = N.f1551a;
        if (Build.VERSION.SDK_INT >= 28) {
            i2 = L.a(viewConfiguration);
        } else {
            i2 = viewConfiguration.getScaledTouchSlop() / 2;
        }
        this.f1248c = i2;
        this.f1254j = true;
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    public static void b(h1 h1Var) {
        h1 h1Var2 = f1245k;
        if (h1Var2 != null) {
            h1Var2.f1247a.removeCallbacks(h1Var2.f1249d);
        }
        f1245k = h1Var;
        if (h1Var != null) {
            h1Var.f1247a.postDelayed(h1Var.f1249d, (long) ViewConfiguration.getLongPressTimeout());
        }
    }

    public final void a() {
        h1 h1Var = f1246l;
        View view = this.f1247a;
        if (h1Var == this) {
            f1246l = null;
            i1 i1Var = this.f1252h;
            if (i1Var != null) {
                View view2 = i1Var.b;
                if (view2.getParent() != null) {
                    ((WindowManager) i1Var.f1267a.getSystemService("window")).removeView(view2);
                }
                this.f1252h = null;
                this.f1254j = true;
                view.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1245k == this) {
            b((h1) null);
        }
        view.removeCallbacks(this.f1250e);
    }

    public final void c(boolean z2) {
        int i2;
        int i3;
        int i4;
        int i5;
        long j2;
        long longPressTimeout;
        long j3;
        int i6;
        int i7;
        int i8;
        int i9;
        View view = this.f1247a;
        if (view.isAttachedToWindow()) {
            b((h1) null);
            h1 h1Var = f1246l;
            if (h1Var != null) {
                h1Var.a();
            }
            f1246l = this;
            this.f1253i = z2;
            i1 i1Var = new i1(view.getContext());
            this.f1252h = i1Var;
            int i10 = this.f;
            int i11 = this.f1251g;
            boolean z3 = this.f1253i;
            View view2 = i1Var.b;
            ViewParent parent = view2.getParent();
            Context context = i1Var.f1267a;
            if (!(parent == null || view2.getParent() == null)) {
                ((WindowManager) context.getSystemService("window")).removeView(view2);
            }
            i1Var.f1268c.setText(this.b);
            WindowManager.LayoutParams layoutParams = i1Var.f1269d;
            layoutParams.token = view.getApplicationWindowToken();
            int dimensionPixelOffset = context.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
            if (view.getWidth() < dimensionPixelOffset) {
                i10 = view.getWidth() / 2;
            }
            if (view.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = context.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
                i2 = i11 + dimensionPixelOffset2;
                i3 = i11 - dimensionPixelOffset2;
            } else {
                i2 = view.getHeight();
                i3 = 0;
            }
            layoutParams.gravity = 49;
            Resources resources = context.getResources();
            if (z3) {
                i4 = R.dimen.tooltip_y_offset_touch;
            } else {
                i4 = R.dimen.tooltip_y_offset_non_touch;
            }
            int dimensionPixelOffset3 = resources.getDimensionPixelOffset(i4);
            View rootView = view.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context2 = view.getContext();
                while (true) {
                    if (!(context2 instanceof ContextWrapper)) {
                        break;
                    } else if (context2 instanceof Activity) {
                        rootView = ((Activity) context2).getWindow().getDecorView();
                        break;
                    } else {
                        context2 = ((ContextWrapper) context2).getBaseContext();
                    }
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
                i5 = 1;
            } else {
                Rect rect = i1Var.f1270e;
                rootView.getWindowVisibleDisplayFrame(rect);
                if (rect.left >= 0 || rect.top >= 0) {
                    i7 = i10;
                    i6 = i3;
                    i8 = 0;
                    i5 = 1;
                } else {
                    Resources resources2 = context.getResources();
                    i5 = 1;
                    i7 = i10;
                    i6 = i3;
                    int identifier = resources2.getIdentifier("status_bar_height", "dimen", "android");
                    if (identifier != 0) {
                        i9 = resources2.getDimensionPixelSize(identifier);
                    } else {
                        i9 = 0;
                    }
                    DisplayMetrics displayMetrics = resources2.getDisplayMetrics();
                    i8 = 0;
                    rect.set(0, i9, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                int[] iArr = i1Var.f1271g;
                rootView.getLocationOnScreen(iArr);
                int[] iArr2 = i1Var.f;
                view.getLocationOnScreen(iArr2);
                int i12 = iArr2[i8] - iArr[i8];
                iArr2[i8] = i12;
                iArr2[i5] = iArr2[i5] - iArr[i5];
                layoutParams.x = (i12 + i7) - (rootView.getWidth() / 2);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i8, i8);
                view2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredHeight = view2.getMeasuredHeight();
                int i13 = iArr2[i5];
                int i14 = ((i13 + i6) - dimensionPixelOffset3) - measuredHeight;
                int i15 = i13 + i2 + dimensionPixelOffset3;
                if (z3) {
                    if (i14 >= 0) {
                        layoutParams.y = i14;
                    } else {
                        layoutParams.y = i15;
                    }
                } else if (measuredHeight + i15 <= rect.height()) {
                    layoutParams.y = i15;
                } else {
                    layoutParams.y = i14;
                }
            }
            ((WindowManager) context.getSystemService("window")).addView(view2, layoutParams);
            view.addOnAttachStateChangeListener(this);
            if (this.f1253i) {
                j2 = 2500;
            } else {
                WeakHashMap weakHashMap = K.f1547a;
                if ((view.getWindowSystemUiVisibility() & 1) == i5) {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j3 = 3000;
                } else {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j3 = 15000;
                }
                j2 = j3 - longPressTimeout;
            }
            g1 g1Var = this.f1250e;
            view.removeCallbacks(g1Var);
            view.postDelayed(g1Var, j2);
        }
    }

    public final boolean onHover(View view, MotionEvent motionEvent) {
        int i2;
        if (this.f1252h == null || !this.f1253i) {
            View view2 = this.f1247a;
            AccessibilityManager accessibilityManager = (AccessibilityManager) view2.getContext().getSystemService("accessibility");
            if (!accessibilityManager.isEnabled() || !accessibilityManager.isTouchExplorationEnabled()) {
                int action = motionEvent.getAction();
                if (action != 7) {
                    if (action == 10) {
                        this.f1254j = true;
                        a();
                        return false;
                    }
                } else if (view2.isEnabled() && this.f1252h == null) {
                    int x2 = (int) motionEvent.getX();
                    int y2 = (int) motionEvent.getY();
                    if (this.f1254j || Math.abs(x2 - this.f) > (i2 = this.f1248c) || Math.abs(y2 - this.f1251g) > i2) {
                        this.f = x2;
                        this.f1251g = y2;
                        this.f1254j = false;
                        b(this);
                    }
                }
            }
        }
        return false;
    }

    public final boolean onLongClick(View view) {
        this.f = view.getWidth() / 2;
        this.f1251g = view.getHeight() / 2;
        c(true);
        return true;
    }

    public final void onViewDetachedFromWindow(View view) {
        a();
    }

    public final void onViewAttachedToWindow(View view) {
    }
}
