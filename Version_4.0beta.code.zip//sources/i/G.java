package i;

import C.j;
import android.app.Activity;
import android.content.ClipData;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import y.C0161e;
import y.K;

public abstract class G {
    /* JADX INFO: finally extract failed */
    public static boolean a(DragEvent dragEvent, TextView textView, Activity activity) {
        j jVar;
        activity.requestDragAndDropPermissions(dragEvent);
        int offsetForPosition = textView.getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
        textView.beginBatchEdit();
        try {
            Selection.setSelection((Spannable) textView.getText(), offsetForPosition);
            ClipData clipData = dragEvent.getClipData();
            if (Build.VERSION.SDK_INT >= 31) {
                jVar = new j(clipData, 3);
            } else {
                C0161e eVar = new C0161e();
                eVar.b = clipData;
                eVar.f1581c = 3;
                jVar = eVar;
            }
            K.f(textView, jVar.k());
            textView.endBatchEdit();
            return true;
        } catch (Throwable th) {
            textView.endBatchEdit();
            throw th;
        }
    }

    public static boolean b(DragEvent dragEvent, View view, Activity activity) {
        j jVar;
        activity.requestDragAndDropPermissions(dragEvent);
        ClipData clipData = dragEvent.getClipData();
        if (Build.VERSION.SDK_INT >= 31) {
            jVar = new j(clipData, 3);
        } else {
            C0161e eVar = new C0161e();
            eVar.b = clipData;
            eVar.f1581c = 3;
            jVar = eVar;
        }
        K.f(view, jVar.k());
        return true;
    }
}
