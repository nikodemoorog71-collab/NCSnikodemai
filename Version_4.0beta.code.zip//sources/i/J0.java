package i;

import android.widget.PopupWindow;

public abstract class J0 {
    public static void a(PopupWindow popupWindow, boolean z2) {
        popupWindow.setTouchModal(z2);
    }
}
