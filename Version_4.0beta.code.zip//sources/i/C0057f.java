package i;

import android.view.ViewGroup;

/* renamed from: i.f  reason: case insensitive filesystem */
public final class C0057f extends ViewGroup.MarginLayoutParams {
}
