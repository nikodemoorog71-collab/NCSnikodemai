package i;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import h.k;
import h.n;
import h.p;

public final class K0 extends C0085t0 {

    /* renamed from: m  reason: collision with root package name */
    public final int f1150m;

    /* renamed from: n  reason: collision with root package name */
    public final int f1151n;

    /* renamed from: o  reason: collision with root package name */
    public H0 f1152o;

    /* renamed from: p  reason: collision with root package name */
    public p f1153p;

    public K0(Context context, boolean z2) {
        super(context, z2);
        if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
            this.f1150m = 21;
            this.f1151n = 22;
            return;
        }
        this.f1150m = 22;
        this.f1151n = 21;
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int i2;
        k kVar;
        p pVar;
        int pointToPosition;
        int i3;
        if (this.f1152o != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                i2 = headerViewListAdapter.getHeadersCount();
                kVar = (k) headerViewListAdapter.getWrappedAdapter();
            } else {
                kVar = (k) adapter;
                i2 = 0;
            }
            if (motionEvent.getAction() == 10 || (pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i3 = pointToPosition - i2) < 0 || i3 >= kVar.getCount()) {
                pVar = null;
            } else {
                pVar = kVar.getItem(i3);
            }
            p pVar2 = this.f1153p;
            if (pVar2 != pVar) {
                n nVar = kVar.f1026a;
                if (pVar2 != null) {
                    this.f1152o.t(nVar, pVar2);
                }
                this.f1153p = pVar;
                if (pVar != null) {
                    this.f1152o.r(nVar, pVar);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        k kVar;
        ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
        if (listMenuItemView != null && i2 == this.f1150m) {
            if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        } else if (listMenuItemView == null || i2 != this.f1151n) {
            return super.onKeyDown(i2, keyEvent);
        } else {
            setSelection(-1);
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                kVar = (k) ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            } else {
                kVar = (k) adapter;
            }
            kVar.f1026a.c(false);
            return true;
        }
    }

    public void setHoverListener(H0 h0) {
        this.f1152o = h0;
    }

    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
