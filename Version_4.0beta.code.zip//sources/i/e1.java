package i;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;

public final class e1 implements C0072m0 {

    /* renamed from: a  reason: collision with root package name */
    public Toolbar f1229a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public View f1230c;

    /* renamed from: d  reason: collision with root package name */
    public Drawable f1231d;

    /* renamed from: e  reason: collision with root package name */
    public Drawable f1232e;
    public Drawable f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1233g;

    /* renamed from: h  reason: collision with root package name */
    public CharSequence f1234h;

    /* renamed from: i  reason: collision with root package name */
    public CharSequence f1235i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f1236j;

    /* renamed from: k  reason: collision with root package name */
    public Window.Callback f1237k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f1238l;

    /* renamed from: m  reason: collision with root package name */
    public C0069l f1239m;

    /* renamed from: n  reason: collision with root package name */
    public int f1240n;

    /* renamed from: o  reason: collision with root package name */
    public Drawable f1241o;

    public final void a(int i2) {
        View view;
        int i3 = this.b ^ i2;
        this.b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    b();
                }
                int i4 = this.b & 4;
                Toolbar toolbar = this.f1229a;
                if (i4 != 0) {
                    Drawable drawable = this.f;
                    if (drawable == null) {
                        drawable = this.f1241o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i3 & 3) != 0) {
                c();
            }
            int i5 = i3 & 8;
            Toolbar toolbar2 = this.f1229a;
            if (i5 != 0) {
                if ((i2 & 8) != 0) {
                    toolbar2.setTitle(this.f1234h);
                    toolbar2.setSubtitle(this.f1235i);
                } else {
                    toolbar2.setTitle((CharSequence) null);
                    toolbar2.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) != 0 && (view = this.f1230c) != null) {
                if ((i2 & 16) != 0) {
                    toolbar2.addView(view);
                } else {
                    toolbar2.removeView(view);
                }
            }
        }
    }

    public final void b() {
        if ((this.b & 4) != 0) {
            boolean isEmpty = TextUtils.isEmpty(this.f1236j);
            Toolbar toolbar = this.f1229a;
            if (isEmpty) {
                toolbar.setNavigationContentDescription(this.f1240n);
            } else {
                toolbar.setNavigationContentDescription(this.f1236j);
            }
        }
    }

    public final void c() {
        Drawable drawable;
        int i2 = this.b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) != 0) {
            drawable = this.f1232e;
            if (drawable == null) {
                drawable = this.f1231d;
            }
        } else {
            drawable = this.f1231d;
        }
        this.f1229a.setLogo(drawable);
    }
}
