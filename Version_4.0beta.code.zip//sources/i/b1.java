package i;

public interface b1 {
}
