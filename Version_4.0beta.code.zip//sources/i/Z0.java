package i;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.Toolbar;
import g.C0026b;
import h.F;
import h.n;
import h.p;
import h.r;
import h.z;
import java.util.ArrayList;

public final class Z0 implements z {

    /* renamed from: a  reason: collision with root package name */
    public n f1211a;
    public p b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1212c;

    public Z0(Toolbar toolbar) {
        this.f1212c = toolbar;
    }

    public final void c() {
        if (this.b != null) {
            n nVar = this.f1211a;
            if (nVar != null) {
                int size = nVar.f.size();
                int i2 = 0;
                while (i2 < size) {
                    if (this.f1211a.getItem(i2) != this.b) {
                        i2++;
                    } else {
                        return;
                    }
                }
            }
            d(this.b);
        }
    }

    public final boolean d(p pVar) {
        Toolbar toolbar = this.f1212c;
        View view = toolbar.f444i;
        if (view instanceof C0026b) {
            ((r) ((C0026b) view)).f1084a.onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.f444i);
        toolbar.removeView(toolbar.f443h);
        toolbar.f444i = null;
        ArrayList arrayList = toolbar.f425E;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.b = null;
        toolbar.requestLayout();
        pVar.f1057C = false;
        pVar.f1069n.p(false);
        toolbar.t();
        return true;
    }

    public final void g(Context context, n nVar) {
        p pVar;
        n nVar2 = this.f1211a;
        if (!(nVar2 == null || (pVar = this.b) == null)) {
            nVar2.d(pVar);
        }
        this.f1211a = nVar;
    }

    public final boolean i() {
        return false;
    }

    public final boolean j(F f) {
        return false;
    }

    public final boolean k(p pVar) {
        Toolbar toolbar = this.f1212c;
        toolbar.c();
        ViewParent parent = toolbar.f443h.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f443h);
            }
            toolbar.addView(toolbar.f443h);
        }
        View actionView = pVar.getActionView();
        toolbar.f444i = actionView;
        this.b = pVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f444i);
            }
            a1 h2 = Toolbar.h();
            h2.f1215a = (toolbar.f449n & 112) | 8388611;
            h2.b = 2;
            toolbar.f444i.setLayoutParams(h2);
            toolbar.addView(toolbar.f444i);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (!(((a1) childAt.getLayoutParams()).b == 2 || childAt == toolbar.f438a)) {
                toolbar.removeViewAt(childCount);
                toolbar.f425E.add(childAt);
            }
        }
        toolbar.requestLayout();
        pVar.f1057C = true;
        pVar.f1069n.p(false);
        View view = toolbar.f444i;
        if (view instanceof C0026b) {
            ((r) ((C0026b) view)).f1084a.onActionViewExpanded();
        }
        toolbar.t();
        return true;
    }

    public final void b(n nVar, boolean z2) {
    }
}
