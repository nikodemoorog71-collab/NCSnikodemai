package i;

import android.graphics.Typeface;
import android.widget.TextView;

public final class V implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ TextView f1196a;
    public final /* synthetic */ Typeface b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f1197c;

    public V(TextView textView, Typeface typeface, int i2) {
        this.f1196a = textView;
        this.b = typeface;
        this.f1197c = i2;
    }

    public final void run() {
        this.f1196a.setTypeface(this.b, this.f1197c);
    }
}
