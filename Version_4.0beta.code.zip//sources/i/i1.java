package i;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import nikodemai.firmware.ncs.R;

public final class i1 {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1267a;
    public final View b;

    /* renamed from: c  reason: collision with root package name */
    public final TextView f1268c;

    /* renamed from: d  reason: collision with root package name */
    public final WindowManager.LayoutParams f1269d;

    /* renamed from: e  reason: collision with root package name */
    public final Rect f1270e = new Rect();
    public final int[] f = new int[2];

    /* renamed from: g  reason: collision with root package name */
    public final int[] f1271g = new int[2];

    public i1(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f1269d = layoutParams;
        this.f1267a = context;
        View inflate = LayoutInflater.from(context).inflate(R.layout.abc_tooltip, (ViewGroup) null);
        this.b = inflate;
        this.f1268c = (TextView) inflate.findViewById(R.id.message);
        layoutParams.setTitle(i1.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = 2131689476;
        layoutParams.flags = 24;
    }
}
