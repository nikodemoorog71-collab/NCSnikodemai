package X;

import W.a;
import b0.c;

public class b extends a {
    /* JADX WARNING: type inference failed for: r0v1, types: [java.lang.Object, b0.a] */
    public final b0.a a() {
        Integer num = a.f254a;
        if (num == null || num.intValue() >= 34) {
            return new Object();
        }
        return new c();
    }
}
