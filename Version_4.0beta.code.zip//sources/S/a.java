package S;

import C.j;
import Q.h;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;

public final class a implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f206a;
    public final /* synthetic */ d b;

    public a(d dVar, String str) {
        this.b = dVar;
        this.f206a = str;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        ((WebView) view).getHitTestResult();
        j jVar = (j) this.b.f209c;
        if (jVar == null) {
            return false;
        }
        String str = this.f206a;
        j jVar2 = (j) jVar.b;
        g gVar = (g) ((h) jVar2.b).f149d;
        String str2 = gVar.f229p;
        gVar.getClass();
        g gVar2 = (g) ((h) jVar2.b).f149d;
        gVar2.a(gVar2.f229p, str, gVar2.f227n);
        return false;
    }
}
