package S;

import Q.h;
import Q.o;
import android.widget.Toast;
import nikodemai.firmware.ncs.MainActivity;
import org.json.JSONException;
import org.json.JSONObject;

public final class e implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f212a;

    public /* synthetic */ e(g gVar) {
        this.f212a = gVar;
    }

    public void a() {
        this.f212a.b.finish();
    }

    public void u(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            boolean has = jSONObject.has("ad_display_running");
            g gVar = this.f212a;
            if (has) {
                if (!jSONObject.isNull("ad_display_running")) {
                    gVar.f222i = jSONObject.getString("ad_display_running");
                }
            }
            if (jSONObject.has("ad_display_exit") && !jSONObject.isNull("ad_display_exit")) {
                gVar.f223j = jSONObject.getString("ad_display_exit");
            }
            if (jSONObject.has("session_id") && !jSONObject.isNull("session_id")) {
                gVar.f229p = jSONObject.getString("session_id");
            }
            if (jSONObject.has("app_mode") && !jSONObject.isNull("app_mode")) {
                gVar.f230q = jSONObject.getString("app_mode");
            }
            String str2 = gVar.f230q;
            MainActivity mainActivity = gVar.b;
            if (str2.equals("finish")) {
                Toast.makeText(mainActivity, "The current version of this App is not available anymore. Please update to the new version or contact the administrator.", 1).show();
                mainActivity.finish();
            }
            if (jSONObject.has("next_call") && !jSONObject.isNull("next_call")) {
                gVar.f220g = Integer.parseInt(jSONObject.getString("next_call")) * 1000;
            }
            h hVar = new h(gVar, (gVar.f221h + "ads-running.json") + "?ai=" + gVar.f227n + "&ik=" + gVar.f228o + "&si=" + gVar.f229p);
            gVar.f216a = hVar;
            gVar.f218d.post(hVar);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }
}
