package S;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.appcompat.widget.Toolbar;
import e.C0017e;
import g.C0025a;
import h.p;
import i.Z0;

public final class c implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f207a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(int i2, Object obj) {
        this.f207a = i2;
        this.b = obj;
    }

    public final void onClick(View view) {
        p pVar;
        switch (this.f207a) {
            case 0:
                d dVar = (d) this.b;
                ((ViewGroup) dVar.f211e).removeView((View) dVar.f);
                return;
            case 1:
                C0017e eVar = (C0017e) this.b;
                Button button = eVar.f;
                eVar.f854v.obtainMessage(1, eVar.b).sendToTarget();
                return;
            case 2:
                ((C0025a) this.b).a();
                return;
            default:
                Z0 z0 = ((Toolbar) this.b).f432L;
                if (z0 == null) {
                    pVar = null;
                } else {
                    pVar = z0.b;
                }
                if (pVar != null) {
                    pVar.collapseActionView();
                    return;
                }
                return;
        }
    }
}
