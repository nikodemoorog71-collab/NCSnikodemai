package S;

import F.d;
import Q.h;
import Q.n;
import android.os.Handler;
import nikodemai.firmware.ncs.MainActivity;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public h f216a;
    public MainActivity b;

    /* renamed from: c  reason: collision with root package name */
    public int f217c;

    /* renamed from: d  reason: collision with root package name */
    public Handler f218d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f219e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public int f220g;

    /* renamed from: h  reason: collision with root package name */
    public String f221h;

    /* renamed from: i  reason: collision with root package name */
    public String f222i;

    /* renamed from: j  reason: collision with root package name */
    public String f223j;

    /* renamed from: k  reason: collision with root package name */
    public String f224k;

    /* renamed from: l  reason: collision with root package name */
    public String f225l;

    /* renamed from: m  reason: collision with root package name */
    public String f226m;

    /* renamed from: n  reason: collision with root package name */
    public String f227n;

    /* renamed from: o  reason: collision with root package name */
    public String f228o;

    /* renamed from: p  reason: collision with root package name */
    public String f229p;

    /* renamed from: q  reason: collision with root package name */
    public String f230q;

    /* renamed from: r  reason: collision with root package name */
    public String f231r;

    /* renamed from: s  reason: collision with root package name */
    public Boolean f232s;

    public final void a(String str, String str2, String str3) {
        if (!this.f232s.booleanValue()) {
            n C2 = D.g.C(this.b);
            C2.a(new f(this.f221h + "ads-click.json", new d(10), new d(11), str, str2, str3));
            this.f232s = Boolean.TRUE;
        }
    }
}
