package S;

import F.d;
import R.h;
import java.util.HashMap;
import java.util.Map;

public final class f extends h {

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ String f213p;

    /* renamed from: q  reason: collision with root package name */
    public final /* synthetic */ String f214q;

    /* renamed from: r  reason: collision with root package name */
    public final /* synthetic */ String f215r;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(String str, d dVar, d dVar2, String str2, String str3, String str4) {
        super(1, str, dVar, dVar2);
        this.f213p = str2;
        this.f214q = str3;
        this.f215r = str4;
    }

    public final Map e() {
        HashMap hashMap = new HashMap();
        hashMap.put("si", this.f213p);
        hashMap.put("ri", this.f214q);
        hashMap.put("ai", this.f215r);
        return hashMap;
    }
}
