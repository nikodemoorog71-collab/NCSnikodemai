package o;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1464a;

    public r(boolean z2) {
        this.f1464a = z2;
    }
}
