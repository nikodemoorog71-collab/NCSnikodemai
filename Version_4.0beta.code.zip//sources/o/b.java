package o;

public interface b {
}
