package o;

import android.app.NotificationManager;
import android.content.Context;
import java.util.HashSet;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public final NotificationManager f1463a;

    static {
        new HashSet();
    }

    public q(Context context) {
        this.f1463a = (NotificationManager) context.getSystemService("notification");
    }
}
