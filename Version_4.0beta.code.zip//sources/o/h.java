package o;

import D.g;
import a0.c;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import androidx.lifecycle.A;
import androidx.lifecycle.l;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import androidx.lifecycle.y;
import y.C0167k;

public abstract class h extends Activity implements q, C0167k {

    /* renamed from: a  reason: collision with root package name */
    public final s f1461a = new s(this);

    public final boolean d(KeyEvent keyEvent) {
        c.e(keyEvent, "event");
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        c.e(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        c.d(decorView, "window.decorView");
        if (g.n(decorView, keyEvent)) {
            return true;
        }
        return g.o(this, decorView, this, keyEvent);
    }

    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        c.e(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        c.d(decorView, "window.decorView");
        if (g.n(decorView, keyEvent)) {
            return true;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i2 = A.b;
        y.b(this);
    }

    public void onSaveInstanceState(Bundle bundle) {
        c.e(bundle, "outState");
        l lVar = l.f673c;
        s sVar = this.f1461a;
        sVar.c("setCurrentState");
        sVar.e(lVar);
        super.onSaveInstanceState(bundle);
    }
}
