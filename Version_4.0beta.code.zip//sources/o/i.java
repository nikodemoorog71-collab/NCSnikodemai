package o;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f1462a;

    public i(boolean z2) {
        this.f1462a = z2;
    }
}
