package o;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

public final class c implements Application.ActivityLifecycleCallbacks {

    /* renamed from: a  reason: collision with root package name */
    public Object f1451a;
    public Activity b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1452c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1453d = false;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1454e = false;
    public boolean f = false;

    public c(Activity activity) {
        this.b = activity;
        this.f1452c = activity.hashCode();
    }

    public final void onActivityDestroyed(Activity activity) {
        if (this.b == activity) {
            this.b = null;
            this.f1454e = true;
        }
    }

    public final void onActivityPaused(Activity activity) {
        if (this.f1454e && !this.f && !this.f1453d) {
            Object obj = this.f1451a;
            try {
                Object obj2 = d.f1456c.get(activity);
                if (obj2 == obj && activity.hashCode() == this.f1452c) {
                    d.f1459g.postAtFrontOfQueue(new Q.c(d.b.get(activity), 3, obj2));
                    this.f = true;
                    this.f1451a = null;
                }
            } catch (Throwable th) {
                Log.e("ActivityRecreator", "Exception while fetching field values", th);
            }
        }
    }

    public final void onActivityStarted(Activity activity) {
        if (this.b == activity) {
            this.f1453d = true;
        }
    }

    public final void onActivityResumed(Activity activity) {
    }

    public final void onActivityStopped(Activity activity) {
    }

    public final void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
