package x;

/* renamed from: x.a  reason: case insensitive filesystem */
public interface C0156a {
    void a(Object obj);
}
