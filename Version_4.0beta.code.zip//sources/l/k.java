package l;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class k {

    /* renamed from: d  reason: collision with root package name */
    public static Object[] f1416d;

    /* renamed from: e  reason: collision with root package name */
    public static int f1417e;
    public static Object[] f;

    /* renamed from: g  reason: collision with root package name */
    public static int f1418g;

    /* renamed from: a  reason: collision with root package name */
    public int[] f1419a = C0108d.f1398a;
    public Object[] b = C0108d.b;

    /* renamed from: c  reason: collision with root package name */
    public int f1420c = 0;

    public static void b(int[] iArr, Object[] objArr, int i2) {
        if (iArr.length == 8) {
            synchronized (k.class) {
                try {
                    if (f1418g < 10) {
                        objArr[0] = f;
                        objArr[1] = iArr;
                        for (int i3 = (i2 << 1) - 1; i3 >= 2; i3--) {
                            objArr[i3] = null;
                        }
                        f = objArr;
                        f1418g++;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (k.class) {
                try {
                    if (f1417e < 10) {
                        objArr[0] = f1416d;
                        objArr[1] = iArr;
                        for (int i4 = (i2 << 1) - 1; i4 >= 2; i4--) {
                            objArr[i4] = null;
                        }
                        f1416d = objArr;
                        f1417e++;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    public final void a(int i2) {
        if (i2 == 8) {
            synchronized (k.class) {
                try {
                    Object[] objArr = f;
                    if (objArr != null) {
                        this.b = objArr;
                        f = (Object[]) objArr[0];
                        this.f1419a = (int[]) objArr[1];
                        objArr[1] = null;
                        objArr[0] = null;
                        f1418g--;
                        return;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (i2 == 4) {
            synchronized (k.class) {
                try {
                    Object[] objArr2 = f1416d;
                    if (objArr2 != null) {
                        this.b = objArr2;
                        f1416d = (Object[]) objArr2[0];
                        this.f1419a = (int[]) objArr2[1];
                        objArr2[1] = null;
                        objArr2[0] = null;
                        f1417e--;
                        return;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        this.f1419a = new int[i2];
        this.b = new Object[(i2 << 1)];
    }

    public final int c(int i2, Object obj) {
        int i3 = this.f1420c;
        if (i3 == 0) {
            return -1;
        }
        try {
            int a2 = C0108d.a(i3, i2, this.f1419a);
            if (a2 < 0 || obj.equals(this.b[a2 << 1])) {
                return a2;
            }
            int i4 = a2 + 1;
            while (i4 < i3 && this.f1419a[i4] == i2) {
                if (obj.equals(this.b[i4 << 1])) {
                    return i4;
                }
                i4++;
            }
            int i5 = a2 - 1;
            while (i5 >= 0 && this.f1419a[i5] == i2) {
                if (obj.equals(this.b[i5 << 1])) {
                    return i5;
                }
                i5--;
            }
            return ~i4;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public final void clear() {
        int i2 = this.f1420c;
        if (i2 > 0) {
            int[] iArr = this.f1419a;
            Object[] objArr = this.b;
            this.f1419a = C0108d.f1398a;
            this.b = C0108d.b;
            this.f1420c = 0;
            b(iArr, objArr, i2);
        }
        if (this.f1420c > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public final boolean containsKey(Object obj) {
        if (d(obj) >= 0) {
            return true;
        }
        return false;
    }

    public final boolean containsValue(Object obj) {
        if (f(obj) >= 0) {
            return true;
        }
        return false;
    }

    public final int d(Object obj) {
        if (obj == null) {
            return e();
        }
        return c(obj.hashCode(), obj);
    }

    public final int e() {
        int i2 = this.f1420c;
        if (i2 == 0) {
            return -1;
        }
        try {
            int a2 = C0108d.a(i2, 0, this.f1419a);
            if (a2 < 0 || this.b[a2 << 1] == null) {
                return a2;
            }
            int i3 = a2 + 1;
            while (i3 < i2 && this.f1419a[i3] == 0) {
                if (this.b[i3 << 1] == null) {
                    return i3;
                }
                i3++;
            }
            int i4 = a2 - 1;
            while (i4 >= 0 && this.f1419a[i4] == 0) {
                if (this.b[i4 << 1] == null) {
                    return i4;
                }
                i4--;
            }
            return ~i3;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof k) {
            k kVar = (k) obj;
            if (this.f1420c != kVar.f1420c) {
                return false;
            }
            int i2 = 0;
            while (i2 < this.f1420c) {
                try {
                    Object g2 = g(i2);
                    Object i3 = i(i2);
                    Object orDefault = kVar.getOrDefault(g2, (Object) null);
                    if (i3 == null) {
                        if (orDefault != null || !kVar.containsKey(g2)) {
                            return false;
                        }
                    } else if (!i3.equals(orDefault)) {
                        return false;
                    }
                    i2++;
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (this.f1420c != map.size()) {
                return false;
            }
            int i4 = 0;
            while (i4 < this.f1420c) {
                try {
                    Object g3 = g(i4);
                    Object i5 = i(i4);
                    Object obj2 = map.get(g3);
                    if (i5 == null) {
                        if (obj2 != null || !map.containsKey(g3)) {
                            return false;
                        }
                    } else if (!i5.equals(obj2)) {
                        return false;
                    }
                    i4++;
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    public final int f(Object obj) {
        int i2 = this.f1420c * 2;
        Object[] objArr = this.b;
        if (obj == null) {
            for (int i3 = 1; i3 < i2; i3 += 2) {
                if (objArr[i3] == null) {
                    return i3 >> 1;
                }
            }
            return -1;
        }
        for (int i4 = 1; i4 < i2; i4 += 2) {
            if (obj.equals(objArr[i4])) {
                return i4 >> 1;
            }
        }
        return -1;
    }

    public final Object g(int i2) {
        return this.b[i2 << 1];
    }

    public final Object get(Object obj) {
        return getOrDefault(obj, (Object) null);
    }

    public final Object getOrDefault(Object obj, Object obj2) {
        int d2 = d(obj);
        if (d2 >= 0) {
            return this.b[(d2 << 1) + 1];
        }
        return obj2;
    }

    public final Object h(int i2) {
        Object[] objArr = this.b;
        int i3 = i2 << 1;
        Object obj = objArr[i3 + 1];
        int i4 = this.f1420c;
        int i5 = 0;
        if (i4 <= 1) {
            b(this.f1419a, objArr, i4);
            this.f1419a = C0108d.f1398a;
            this.b = C0108d.b;
        } else {
            int i6 = i4 - 1;
            int[] iArr = this.f1419a;
            int i7 = 8;
            if (iArr.length <= 8 || i4 >= iArr.length / 3) {
                if (i2 < i6) {
                    int i8 = i2 + 1;
                    int i9 = i6 - i2;
                    System.arraycopy(iArr, i8, iArr, i2, i9);
                    Object[] objArr2 = this.b;
                    System.arraycopy(objArr2, i8 << 1, objArr2, i3, i9 << 1);
                }
                Object[] objArr3 = this.b;
                int i10 = i6 << 1;
                objArr3[i10] = null;
                objArr3[i10 + 1] = null;
            } else {
                if (i4 > 8) {
                    i7 = i4 + (i4 >> 1);
                }
                a(i7);
                if (i4 == this.f1420c) {
                    if (i2 > 0) {
                        System.arraycopy(iArr, 0, this.f1419a, 0, i2);
                        System.arraycopy(objArr, 0, this.b, 0, i3);
                    }
                    if (i2 < i6) {
                        int i11 = i2 + 1;
                        int i12 = i6 - i2;
                        System.arraycopy(iArr, i11, this.f1419a, i2, i12);
                        System.arraycopy(objArr, i11 << 1, this.b, i3, i12 << 1);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
            i5 = i6;
        }
        if (i4 == this.f1420c) {
            this.f1420c = i5;
            return obj;
        }
        throw new ConcurrentModificationException();
    }

    public final int hashCode() {
        int i2;
        int[] iArr = this.f1419a;
        Object[] objArr = this.b;
        int i3 = this.f1420c;
        int i4 = 1;
        int i5 = 0;
        int i6 = 0;
        while (i5 < i3) {
            Object obj = objArr[i4];
            int i7 = iArr[i5];
            if (obj == null) {
                i2 = 0;
            } else {
                i2 = obj.hashCode();
            }
            i6 += i2 ^ i7;
            i5++;
            i4 += 2;
        }
        return i6;
    }

    public final Object i(int i2) {
        return this.b[(i2 << 1) + 1];
    }

    public final boolean isEmpty() {
        if (this.f1420c <= 0) {
            return true;
        }
        return false;
    }

    public final Object put(Object obj, Object obj2) {
        int i2;
        int i3;
        int i4 = this.f1420c;
        if (obj == null) {
            i3 = e();
            i2 = 0;
        } else {
            int hashCode = obj.hashCode();
            i2 = hashCode;
            i3 = c(hashCode, obj);
        }
        if (i3 >= 0) {
            int i5 = (i3 << 1) + 1;
            Object[] objArr = this.b;
            Object obj3 = objArr[i5];
            objArr[i5] = obj2;
            return obj3;
        }
        int i6 = ~i3;
        int[] iArr = this.f1419a;
        if (i4 >= iArr.length) {
            int i7 = 8;
            if (i4 >= 8) {
                i7 = (i4 >> 1) + i4;
            } else if (i4 < 4) {
                i7 = 4;
            }
            Object[] objArr2 = this.b;
            a(i7);
            if (i4 == this.f1420c) {
                int[] iArr2 = this.f1419a;
                if (iArr2.length > 0) {
                    System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                    System.arraycopy(objArr2, 0, this.b, 0, objArr2.length);
                }
                b(iArr, objArr2, i4);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (i6 < i4) {
            int[] iArr3 = this.f1419a;
            int i8 = i6 + 1;
            System.arraycopy(iArr3, i6, iArr3, i8, i4 - i6);
            Object[] objArr3 = this.b;
            System.arraycopy(objArr3, i6 << 1, objArr3, i8 << 1, (this.f1420c - i6) << 1);
        }
        int i9 = this.f1420c;
        if (i4 == i9) {
            int[] iArr4 = this.f1419a;
            if (i6 < iArr4.length) {
                iArr4[i6] = i2;
                Object[] objArr4 = this.b;
                int i10 = i6 << 1;
                objArr4[i10] = obj;
                objArr4[i10 + 1] = obj2;
                this.f1420c = i9 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public final Object putIfAbsent(Object obj, Object obj2) {
        Object orDefault = getOrDefault(obj, (Object) null);
        if (orDefault == null) {
            return put(obj, obj2);
        }
        return orDefault;
    }

    public final Object remove(Object obj) {
        int d2 = d(obj);
        if (d2 >= 0) {
            return h(d2);
        }
        return null;
    }

    public final Object replace(Object obj, Object obj2) {
        int d2 = d(obj);
        if (d2 < 0) {
            return null;
        }
        int i2 = (d2 << 1) + 1;
        Object[] objArr = this.b;
        Object obj3 = objArr[i2];
        objArr[i2] = obj2;
        return obj3;
    }

    public final int size() {
        return this.f1420c;
    }

    public final String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1420c * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.f1420c; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            Object g2 = g(i2);
            if (g2 != this) {
                sb.append(g2);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            Object i3 = i(i2);
            if (i3 != this) {
                sb.append(i3);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public final boolean remove(Object obj, Object obj2) {
        int d2 = d(obj);
        if (d2 < 0) {
            return false;
        }
        Object i2 = i(d2);
        if (obj2 != i2 && (obj2 == null || !obj2.equals(i2))) {
            return false;
        }
        h(d2);
        return true;
    }

    public final boolean replace(Object obj, Object obj2, Object obj3) {
        int d2 = d(obj);
        if (d2 < 0) {
            return false;
        }
        Object i2 = i(d2);
        if (i2 != obj2 && (obj2 == null || !obj2.equals(i2))) {
            return false;
        }
        int i3 = (d2 << 1) + 1;
        Object[] objArr = this.b;
        Object obj4 = objArr[i3];
        objArr[i3] = obj3;
        return true;
    }
}
