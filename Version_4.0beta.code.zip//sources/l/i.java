package l;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

public final class i implements Iterator, Map.Entry {

    /* renamed from: a  reason: collision with root package name */
    public int f1412a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1413c = false;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0105a f1414d;

    public i(C0105a aVar) {
        this.f1414d = aVar;
        this.f1412a = aVar.d() - 1;
        this.b = -1;
    }

    public final boolean equals(Object obj) {
        if (!this.f1413c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        } else if (!(obj instanceof Map.Entry)) {
            return false;
        } else {
            Map.Entry entry = (Map.Entry) obj;
            Object key = entry.getKey();
            int i2 = this.b;
            C0105a aVar = this.f1414d;
            Object b2 = aVar.b(i2, 0);
            if (key != b2 && (key == null || !key.equals(b2))) {
                return false;
            }
            Object value = entry.getValue();
            Object b3 = aVar.b(this.b, 1);
            if (value == b3 || (value != null && value.equals(b3))) {
                return true;
            }
            return false;
        }
    }

    public final Object getKey() {
        if (this.f1413c) {
            return this.f1414d.b(this.b, 0);
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final Object getValue() {
        if (this.f1413c) {
            return this.f1414d.b(this.b, 1);
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final boolean hasNext() {
        if (this.b < this.f1412a) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i2;
        if (this.f1413c) {
            int i3 = this.b;
            C0105a aVar = this.f1414d;
            int i4 = 0;
            Object b2 = aVar.b(i3, 0);
            Object b3 = aVar.b(this.b, 1);
            if (b2 == null) {
                i2 = 0;
            } else {
                i2 = b2.hashCode();
            }
            if (b3 != null) {
                i4 = b3.hashCode();
            }
            return i2 ^ i4;
        }
        throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final Object next() {
        if (hasNext()) {
            this.b++;
            this.f1413c = true;
            return this;
        }
        throw new NoSuchElementException();
    }

    public final void remove() {
        if (this.f1413c) {
            this.f1414d.g(this.b);
            this.b--;
            this.f1412a--;
            this.f1413c = false;
            return;
        }
        throw new IllegalStateException();
    }

    public final Object setValue(Object obj) {
        if (this.f1413c) {
            C0105a aVar = this.f1414d;
            int i2 = this.b;
            switch (aVar.f1387d) {
                case 0:
                    int i3 = (i2 << 1) + 1;
                    Object[] objArr = ((C0106b) aVar.f1388e).b;
                    Object obj2 = objArr[i3];
                    objArr[i3] = obj;
                    return obj2;
                default:
                    throw new UnsupportedOperationException("not a map");
            }
        } else {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
    }

    public final String toString() {
        return getKey() + "=" + getValue();
    }
}
