package l;

import java.util.Collection;
import java.util.Iterator;

public final class j implements Collection {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0105a f1415a;

    public j(C0105a aVar) {
        this.f1415a = aVar;
    }

    public final boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    public final boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    public final void clear() {
        this.f1415a.a();
    }

    public final boolean contains(Object obj) {
        if (this.f1415a.f(obj) >= 0) {
            return true;
        }
        return false;
    }

    public final boolean containsAll(Collection collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final boolean isEmpty() {
        if (this.f1415a.d() == 0) {
            return true;
        }
        return false;
    }

    public final Iterator iterator() {
        return new C0111g(this.f1415a, 1);
    }

    public final boolean remove(Object obj) {
        C0105a aVar = this.f1415a;
        int f = aVar.f(obj);
        if (f < 0) {
            return false;
        }
        aVar.g(f);
        return true;
    }

    public final boolean removeAll(Collection collection) {
        C0105a aVar = this.f1415a;
        int d2 = aVar.d();
        int i2 = 0;
        boolean z2 = false;
        while (i2 < d2) {
            if (collection.contains(aVar.b(i2, 1))) {
                aVar.g(i2);
                i2--;
                d2--;
                z2 = true;
            }
            i2++;
        }
        return z2;
    }

    public final boolean retainAll(Collection collection) {
        C0105a aVar = this.f1415a;
        int d2 = aVar.d();
        int i2 = 0;
        boolean z2 = false;
        while (i2 < d2) {
            if (!collection.contains(aVar.b(i2, 1))) {
                aVar.g(i2);
                i2--;
                d2--;
                z2 = true;
            }
            i2++;
        }
        return z2;
    }

    public final int size() {
        return this.f1415a.d();
    }

    public final Object[] toArray() {
        C0105a aVar = this.f1415a;
        int d2 = aVar.d();
        Object[] objArr = new Object[d2];
        for (int i2 = 0; i2 < d2; i2++) {
            objArr[i2] = aVar.b(i2, 1);
        }
        return objArr;
    }

    public final Object[] toArray(Object[] objArr) {
        return this.f1415a.i(objArr, 1);
    }
}
