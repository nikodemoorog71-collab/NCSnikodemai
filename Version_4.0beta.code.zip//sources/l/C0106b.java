package l;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Map;
import java.util.Set;

/* renamed from: l.b  reason: case insensitive filesystem */
public final class C0106b extends k implements Map {

    /* renamed from: h  reason: collision with root package name */
    public C0105a f1389h;

    public final Set entrySet() {
        if (this.f1389h == null) {
            this.f1389h = new C0105a(0, this);
        }
        C0105a aVar = this.f1389h;
        if (aVar.f1385a == null) {
            aVar.f1385a = new h(aVar, 0);
        }
        return aVar.f1385a;
    }

    public final Set keySet() {
        if (this.f1389h == null) {
            this.f1389h = new C0105a(0, this);
        }
        C0105a aVar = this.f1389h;
        if (aVar.b == null) {
            aVar.b = new h(aVar, 1);
        }
        return aVar.b;
    }

    public final void putAll(Map map) {
        int size = map.size() + this.f1420c;
        int i2 = this.f1420c;
        int[] iArr = this.f1419a;
        if (iArr.length < size) {
            Object[] objArr = this.b;
            a(size);
            if (this.f1420c > 0) {
                System.arraycopy(iArr, 0, this.f1419a, 0, i2);
                System.arraycopy(objArr, 0, this.b, 0, i2 << 1);
            }
            k.b(iArr, objArr, i2);
        }
        if (this.f1420c == i2) {
            for (Map.Entry entry : map.entrySet()) {
                put(entry.getKey(), entry.getValue());
            }
            return;
        }
        throw new ConcurrentModificationException();
    }

    public final Collection values() {
        if (this.f1389h == null) {
            this.f1389h = new C0105a(0, this);
        }
        C0105a aVar = this.f1389h;
        if (aVar.f1386c == null) {
            aVar.f1386c = new j(aVar);
        }
        return aVar.f1386c;
    }
}
