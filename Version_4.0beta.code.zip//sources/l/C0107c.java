package l;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/* renamed from: l.c  reason: case insensitive filesystem */
public final class C0107c implements Collection, Set {

    /* renamed from: e  reason: collision with root package name */
    public static final int[] f1390e = new int[0];
    public static final Object[] f = new Object[0];

    /* renamed from: g  reason: collision with root package name */
    public static Object[] f1391g;

    /* renamed from: h  reason: collision with root package name */
    public static int f1392h;

    /* renamed from: i  reason: collision with root package name */
    public static Object[] f1393i;

    /* renamed from: j  reason: collision with root package name */
    public static int f1394j;

    /* renamed from: a  reason: collision with root package name */
    public int[] f1395a;
    public Object[] b;

    /* renamed from: c  reason: collision with root package name */
    public int f1396c;

    /* renamed from: d  reason: collision with root package name */
    public C0105a f1397d;

    public C0107c(int i2) {
        if (i2 == 0) {
            this.f1395a = f1390e;
            this.b = f;
        } else {
            a(i2);
        }
        this.f1396c = 0;
    }

    public static void b(int[] iArr, Object[] objArr, int i2) {
        if (iArr.length == 8) {
            synchronized (C0107c.class) {
                try {
                    if (f1394j < 10) {
                        objArr[0] = f1393i;
                        objArr[1] = iArr;
                        for (int i3 = i2 - 1; i3 >= 2; i3--) {
                            objArr[i3] = null;
                        }
                        f1393i = objArr;
                        f1394j++;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (C0107c.class) {
                try {
                    if (f1392h < 10) {
                        objArr[0] = f1391g;
                        objArr[1] = iArr;
                        for (int i4 = i2 - 1; i4 >= 2; i4--) {
                            objArr[i4] = null;
                        }
                        f1391g = objArr;
                        f1392h++;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    public final void a(int i2) {
        if (i2 == 8) {
            synchronized (C0107c.class) {
                try {
                    Object[] objArr = f1393i;
                    if (objArr != null) {
                        this.b = objArr;
                        f1393i = (Object[]) objArr[0];
                        this.f1395a = (int[]) objArr[1];
                        objArr[1] = null;
                        objArr[0] = null;
                        f1394j--;
                        return;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } else if (i2 == 4) {
            synchronized (C0107c.class) {
                try {
                    Object[] objArr2 = f1391g;
                    if (objArr2 != null) {
                        this.b = objArr2;
                        f1391g = (Object[]) objArr2[0];
                        this.f1395a = (int[]) objArr2[1];
                        objArr2[1] = null;
                        objArr2[0] = null;
                        f1392h--;
                        return;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        this.f1395a = new int[i2];
        this.b = new Object[i2];
    }

    public final boolean add(Object obj) {
        int i2;
        int i3;
        if (obj == null) {
            i3 = d();
            i2 = 0;
        } else {
            int hashCode = obj.hashCode();
            i2 = hashCode;
            i3 = c(hashCode, obj);
        }
        if (i3 >= 0) {
            return false;
        }
        int i4 = ~i3;
        int i5 = this.f1396c;
        int[] iArr = this.f1395a;
        if (i5 >= iArr.length) {
            int i6 = 8;
            if (i5 >= 8) {
                i6 = (i5 >> 1) + i5;
            } else if (i5 < 4) {
                i6 = 4;
            }
            Object[] objArr = this.b;
            a(i6);
            int[] iArr2 = this.f1395a;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.b, 0, objArr.length);
            }
            b(iArr, objArr, this.f1396c);
        }
        int i7 = this.f1396c;
        if (i4 < i7) {
            int[] iArr3 = this.f1395a;
            int i8 = i4 + 1;
            System.arraycopy(iArr3, i4, iArr3, i8, i7 - i4);
            Object[] objArr2 = this.b;
            System.arraycopy(objArr2, i4, objArr2, i8, this.f1396c - i4);
        }
        this.f1395a[i4] = i2;
        this.b[i4] = obj;
        this.f1396c++;
        return true;
    }

    public final boolean addAll(Collection collection) {
        int size = collection.size() + this.f1396c;
        int[] iArr = this.f1395a;
        boolean z2 = false;
        if (iArr.length < size) {
            Object[] objArr = this.b;
            a(size);
            int i2 = this.f1396c;
            if (i2 > 0) {
                System.arraycopy(iArr, 0, this.f1395a, 0, i2);
                System.arraycopy(objArr, 0, this.b, 0, this.f1396c);
            }
            b(iArr, objArr, this.f1396c);
        }
        for (Object add : collection) {
            z2 |= add(add);
        }
        return z2;
    }

    public final int c(int i2, Object obj) {
        int i3 = this.f1396c;
        if (i3 == 0) {
            return -1;
        }
        int a2 = C0108d.a(i3, i2, this.f1395a);
        if (a2 < 0 || obj.equals(this.b[a2])) {
            return a2;
        }
        int i4 = a2 + 1;
        while (i4 < i3 && this.f1395a[i4] == i2) {
            if (obj.equals(this.b[i4])) {
                return i4;
            }
            i4++;
        }
        int i5 = a2 - 1;
        while (i5 >= 0 && this.f1395a[i5] == i2) {
            if (obj.equals(this.b[i5])) {
                return i5;
            }
            i5--;
        }
        return ~i4;
    }

    public final void clear() {
        int i2 = this.f1396c;
        if (i2 != 0) {
            b(this.f1395a, this.b, i2);
            this.f1395a = f1390e;
            this.b = f;
            this.f1396c = 0;
        }
    }

    public final boolean contains(Object obj) {
        int i2;
        if (obj == null) {
            i2 = d();
        } else {
            i2 = c(obj.hashCode(), obj);
        }
        if (i2 >= 0) {
            return true;
        }
        return false;
    }

    public final boolean containsAll(Collection collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final int d() {
        int i2 = this.f1396c;
        if (i2 == 0) {
            return -1;
        }
        int a2 = C0108d.a(i2, 0, this.f1395a);
        if (a2 < 0 || this.b[a2] == null) {
            return a2;
        }
        int i3 = a2 + 1;
        while (i3 < i2 && this.f1395a[i3] == 0) {
            if (this.b[i3] == null) {
                return i3;
            }
            i3++;
        }
        int i4 = a2 - 1;
        while (i4 >= 0 && this.f1395a[i4] == 0) {
            if (this.b[i4] == null) {
                return i4;
            }
            i4--;
        }
        return ~i3;
    }

    public final void e(int i2) {
        Object[] objArr = this.b;
        Object obj = objArr[i2];
        int i3 = this.f1396c;
        if (i3 <= 1) {
            b(this.f1395a, objArr, i3);
            this.f1395a = f1390e;
            this.b = f;
            this.f1396c = 0;
            return;
        }
        int[] iArr = this.f1395a;
        int i4 = 8;
        if (iArr.length <= 8 || i3 >= iArr.length / 3) {
            int i5 = i3 - 1;
            this.f1396c = i5;
            if (i2 < i5) {
                int i6 = i2 + 1;
                System.arraycopy(iArr, i6, iArr, i2, i5 - i2);
                Object[] objArr2 = this.b;
                System.arraycopy(objArr2, i6, objArr2, i2, this.f1396c - i2);
            }
            this.b[this.f1396c] = null;
            return;
        }
        if (i3 > 8) {
            i4 = i3 + (i3 >> 1);
        }
        a(i4);
        this.f1396c--;
        if (i2 > 0) {
            System.arraycopy(iArr, 0, this.f1395a, 0, i2);
            System.arraycopy(objArr, 0, this.b, 0, i2);
        }
        int i7 = this.f1396c;
        if (i2 < i7) {
            int i8 = i2 + 1;
            System.arraycopy(iArr, i8, this.f1395a, i2, i7 - i2);
            System.arraycopy(objArr, i8, this.b, i2, this.f1396c - i2);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (this.f1396c != set.size()) {
                return false;
            }
            int i2 = 0;
            while (i2 < this.f1396c) {
                try {
                    if (!set.contains(this.b[i2])) {
                        return false;
                    }
                    i2++;
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int[] iArr = this.f1395a;
        int i2 = this.f1396c;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            i3 += iArr[i4];
        }
        return i3;
    }

    public final boolean isEmpty() {
        if (this.f1396c <= 0) {
            return true;
        }
        return false;
    }

    public final Iterator iterator() {
        if (this.f1397d == null) {
            this.f1397d = new C0105a(1, this);
        }
        C0105a aVar = this.f1397d;
        if (aVar.b == null) {
            aVar.b = new h(aVar, 1);
        }
        return aVar.b.iterator();
    }

    public final boolean remove(Object obj) {
        int i2;
        if (obj == null) {
            i2 = d();
        } else {
            i2 = c(obj.hashCode(), obj);
        }
        if (i2 < 0) {
            return false;
        }
        e(i2);
        return true;
    }

    public final boolean removeAll(Collection collection) {
        boolean z2 = false;
        for (Object remove : collection) {
            z2 |= remove(remove);
        }
        return z2;
    }

    public final boolean retainAll(Collection collection) {
        boolean z2 = false;
        for (int i2 = this.f1396c - 1; i2 >= 0; i2--) {
            if (!collection.contains(this.b[i2])) {
                e(i2);
                z2 = true;
            }
        }
        return z2;
    }

    public final int size() {
        return this.f1396c;
    }

    public final Object[] toArray() {
        int i2 = this.f1396c;
        Object[] objArr = new Object[i2];
        System.arraycopy(this.b, 0, objArr, 0, i2);
        return objArr;
    }

    public final String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1396c * 14);
        sb.append('{');
        for (int i2 = 0; i2 < this.f1396c; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            Object obj = this.b[i2];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public final Object[] toArray(Object[] objArr) {
        if (objArr.length < this.f1396c) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), this.f1396c);
        }
        System.arraycopy(this.b, 0, objArr, 0, this.f1396c);
        int length = objArr.length;
        int i2 = this.f1396c;
        if (length > i2) {
            objArr[i2] = null;
        }
        return objArr;
    }
}
