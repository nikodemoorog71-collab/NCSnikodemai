package l;

/* renamed from: l.e  reason: case insensitive filesystem */
public final class C0109e implements Cloneable {

    /* renamed from: e  reason: collision with root package name */
    public static final Object f1399e = new Object();

    /* renamed from: a  reason: collision with root package name */
    public boolean f1400a;
    public long[] b;

    /* renamed from: c  reason: collision with root package name */
    public Object[] f1401c;

    /* renamed from: d  reason: collision with root package name */
    public int f1402d;

    public final void a() {
        int i2 = this.f1402d;
        long[] jArr = this.b;
        Object[] objArr = this.f1401c;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != f1399e) {
                if (i4 != i3) {
                    jArr[i3] = jArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.f1400a = false;
        this.f1402d = i3;
    }

    public final void b(long j2, Object obj) {
        int b2 = C0108d.b(this.b, this.f1402d, j2);
        if (b2 >= 0) {
            this.f1401c[b2] = obj;
            return;
        }
        int i2 = ~b2;
        int i3 = this.f1402d;
        if (i2 < i3) {
            Object[] objArr = this.f1401c;
            if (objArr[i2] == f1399e) {
                this.b[i2] = j2;
                objArr[i2] = obj;
                return;
            }
        }
        if (this.f1400a && i3 >= this.b.length) {
            a();
            i2 = ~C0108d.b(this.b, this.f1402d, j2);
        }
        int i4 = this.f1402d;
        if (i4 >= this.b.length) {
            int i5 = (i4 + 1) * 8;
            int i6 = 4;
            while (true) {
                if (i6 >= 32) {
                    break;
                }
                int i7 = (1 << i6) - 12;
                if (i5 <= i7) {
                    i5 = i7;
                    break;
                }
                i6++;
            }
            int i8 = i5 / 8;
            long[] jArr = new long[i8];
            Object[] objArr2 = new Object[i8];
            long[] jArr2 = this.b;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f1401c;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.b = jArr;
            this.f1401c = objArr2;
        }
        int i9 = this.f1402d - i2;
        if (i9 != 0) {
            long[] jArr3 = this.b;
            int i10 = i2 + 1;
            System.arraycopy(jArr3, i2, jArr3, i10, i9);
            Object[] objArr4 = this.f1401c;
            System.arraycopy(objArr4, i2, objArr4, i10, this.f1402d - i2);
        }
        this.b[i2] = j2;
        this.f1401c[i2] = obj;
        this.f1402d++;
    }

    public final Object clone() {
        try {
            C0109e eVar = (C0109e) super.clone();
            eVar.b = (long[]) this.b.clone();
            eVar.f1401c = (Object[]) this.f1401c.clone();
            return eVar;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public final String toString() {
        if (this.f1400a) {
            a();
        }
        int i2 = this.f1402d;
        if (i2 <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(i2 * 28);
        sb.append('{');
        for (int i3 = 0; i3 < this.f1402d; i3++) {
            if (i3 > 0) {
                sb.append(", ");
            }
            if (this.f1400a) {
                a();
            }
            sb.append(this.b[i3]);
            sb.append('=');
            if (this.f1400a) {
                a();
            }
            Object obj = this.f1401c[i3];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
