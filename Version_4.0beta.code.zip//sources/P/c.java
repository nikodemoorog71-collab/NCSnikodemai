package P;

public interface c {
}
