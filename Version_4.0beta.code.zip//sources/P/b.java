package P;

import android.os.Parcel;
import android.util.SparseIntArray;
import l.C0106b;
import l.k;

public final class b extends a {

    /* renamed from: d  reason: collision with root package name */
    public final SparseIntArray f125d;

    /* renamed from: e  reason: collision with root package name */
    public final Parcel f126e;
    public final int f;

    /* renamed from: g  reason: collision with root package name */
    public final int f127g;

    /* renamed from: h  reason: collision with root package name */
    public final String f128h;

    /* renamed from: i  reason: collision with root package name */
    public int f129i;

    /* renamed from: j  reason: collision with root package name */
    public int f130j;

    /* renamed from: k  reason: collision with root package name */
    public int f131k;

    /* JADX WARNING: type inference failed for: r5v0, types: [l.b, l.k] */
    /* JADX WARNING: type inference failed for: r6v0, types: [l.b, l.k] */
    /* JADX WARNING: type inference failed for: r7v0, types: [l.b, l.k] */
    public b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new k(), new k(), new k());
    }

    public final b a() {
        Parcel parcel = this.f126e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f130j;
        if (i2 == this.f) {
            i2 = this.f127g;
        }
        return new b(parcel, dataPosition, i2, this.f128h + "  ", this.f123a, this.b, this.f124c);
    }

    public final boolean e(int i2) {
        while (this.f130j < this.f127g) {
            int i3 = this.f131k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            int i4 = this.f130j;
            Parcel parcel = this.f126e;
            parcel.setDataPosition(i4);
            int readInt = parcel.readInt();
            this.f131k = parcel.readInt();
            this.f130j += readInt;
        }
        if (this.f131k == i2) {
            return true;
        }
        return false;
    }

    public final void h(int i2) {
        int i3 = this.f129i;
        SparseIntArray sparseIntArray = this.f125d;
        Parcel parcel = this.f126e;
        if (i3 >= 0) {
            int i4 = sparseIntArray.get(i3);
            int dataPosition = parcel.dataPosition();
            parcel.setDataPosition(i4);
            parcel.writeInt(dataPosition - i4);
            parcel.setDataPosition(dataPosition);
        }
        this.f129i = i2;
        sparseIntArray.put(i2, parcel.dataPosition());
        parcel.writeInt(0);
        parcel.writeInt(i2);
    }

    public b(Parcel parcel, int i2, int i3, String str, C0106b bVar, C0106b bVar2, C0106b bVar3) {
        super(bVar, bVar2, bVar3);
        this.f125d = new SparseIntArray();
        this.f129i = -1;
        this.f131k = -1;
        this.f126e = parcel;
        this.f = i2;
        this.f127g = i3;
        this.f130j = i2;
        this.f128h = str;
    }
}
