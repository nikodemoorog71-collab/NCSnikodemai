package androidx.profileinstaller;

import F.d;
import K.h;
import K.k;
import M.b;
import android.content.Context;
import java.util.Collections;
import java.util.List;

public class ProfileInstallerInitializer implements b {
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    public final Object b(Context context) {
        k.a(new h(this, 0, context.getApplicationContext()));
        return new d(6);
    }
}
