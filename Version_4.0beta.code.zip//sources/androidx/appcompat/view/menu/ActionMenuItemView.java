package androidx.appcompat.view.menu;

import D.g;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import d.C0009a;
import h.C0036A;
import h.C0038b;
import h.C0039c;
import h.m;
import h.n;
import h.p;
import i.C0054d0;
import i.C0071m;

public class ActionMenuItemView extends C0054d0 implements C0036A, View.OnClickListener, C0071m {

    /* renamed from: h  reason: collision with root package name */
    public p f317h;

    /* renamed from: i  reason: collision with root package name */
    public CharSequence f318i;

    /* renamed from: j  reason: collision with root package name */
    public Drawable f319j;

    /* renamed from: k  reason: collision with root package name */
    public m f320k;

    /* renamed from: l  reason: collision with root package name */
    public C0038b f321l;

    /* renamed from: m  reason: collision with root package name */
    public C0039c f322m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f323n = h();

    /* renamed from: o  reason: collision with root package name */
    public boolean f324o;

    /* renamed from: p  reason: collision with root package name */
    public final int f325p;

    /* renamed from: q  reason: collision with root package name */
    public int f326q;

    /* renamed from: r  reason: collision with root package name */
    public final int f327r;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0009a.f696c, 0, 0);
        this.f325p = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        obtainStyledAttributes.recycle();
        this.f327r = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f326q = -1;
        setSaveEnabled(false);
    }

    public final boolean a() {
        if (TextUtils.isEmpty(getText()) || this.f317h.getIcon() != null) {
            return false;
        }
        return true;
    }

    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    public final void c(p pVar) {
        int i2;
        this.f317h = pVar;
        setIcon(pVar.getIcon());
        setTitle(pVar.getTitleCondensed());
        setId(pVar.f1058a);
        if (pVar.isVisible()) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        setVisibility(i2);
        setEnabled(pVar.isEnabled());
        if (pVar.hasSubMenu() && this.f321l == null) {
            this.f321l = new C0038b(this);
        }
    }

    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    public p getItemData() {
        return this.f317h;
    }

    public final boolean h() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        int i3 = configuration.screenHeightDp;
        if (i2 >= 480) {
            return true;
        }
        if ((i2 < 640 || i3 < 480) && configuration.orientation != 2) {
            return false;
        }
        return true;
    }

    public final void i() {
        CharSequence charSequence;
        CharSequence charSequence2;
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f318i);
        if (this.f319j != null && ((this.f317h.f1080y & 4) != 4 || (!this.f323n && !this.f324o))) {
            z2 = false;
        }
        boolean z4 = z3 & z2;
        CharSequence charSequence3 = null;
        if (z4) {
            charSequence = this.f318i;
        } else {
            charSequence = null;
        }
        setText(charSequence);
        CharSequence charSequence4 = this.f317h.f1072q;
        if (TextUtils.isEmpty(charSequence4)) {
            if (z4) {
                charSequence2 = null;
            } else {
                charSequence2 = this.f317h.f1061e;
            }
            setContentDescription(charSequence2);
        } else {
            setContentDescription(charSequence4);
        }
        CharSequence charSequence5 = this.f317h.f1073r;
        if (TextUtils.isEmpty(charSequence5)) {
            if (!z4) {
                charSequence3 = this.f317h.f1061e;
            }
            g.S(this, charSequence3);
            return;
        }
        g.S(this, charSequence5);
    }

    public final void onClick(View view) {
        m mVar = this.f320k;
        if (mVar != null) {
            mVar.b(this.f317h);
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f323n = h();
        i();
    }

    public final void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        boolean isEmpty = TextUtils.isEmpty(getText());
        if (!isEmpty && (i5 = this.f326q) >= 0) {
            super.setPadding(i5, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int measuredWidth = getMeasuredWidth();
        int i6 = this.f325p;
        if (mode == Integer.MIN_VALUE) {
            i4 = Math.min(size, i6);
        } else {
            i4 = i6;
        }
        if (mode != 1073741824 && i6 > 0 && measuredWidth < i4) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
        }
        if (isEmpty && this.f319j != null) {
            super.setPadding((getMeasuredWidth() - this.f319j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState((Parcelable) null);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C0038b bVar;
        if (!this.f317h.hasSubMenu() || (bVar = this.f321l) == null || !bVar.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z2) {
    }

    public void setChecked(boolean z2) {
    }

    public void setExpandedFormat(boolean z2) {
        if (this.f324o != z2) {
            this.f324o = z2;
            p pVar = this.f317h;
            if (pVar != null) {
                n nVar = pVar.f1069n;
                nVar.f1039k = true;
                nVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f319j = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i2 = this.f327r;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i2) / ((float) intrinsicWidth)));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i2) / ((float) intrinsicHeight)));
            } else {
                i2 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
        i();
    }

    public void setItemInvoker(m mVar) {
        this.f320k = mVar;
    }

    public final void setPadding(int i2, int i3, int i4, int i5) {
        this.f326q = i2;
        super.setPadding(i2, i3, i4, i5);
    }

    public void setPopupCallback(C0039c cVar) {
        this.f322m = cVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f318i = charSequence;
        i();
    }
}
