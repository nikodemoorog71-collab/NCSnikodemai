package androidx.appcompat.view.menu;

import C.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import d.C0009a;
import h.C0036A;
import h.p;
import nikodemai.firmware.ncs.R;

public class ListMenuItemView extends LinearLayout implements C0036A, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a  reason: collision with root package name */
    public p f329a;
    public ImageView b;

    /* renamed from: c  reason: collision with root package name */
    public RadioButton f330c;

    /* renamed from: d  reason: collision with root package name */
    public TextView f331d;

    /* renamed from: e  reason: collision with root package name */
    public CheckBox f332e;
    public TextView f;

    /* renamed from: g  reason: collision with root package name */
    public ImageView f333g;

    /* renamed from: h  reason: collision with root package name */
    public ImageView f334h;

    /* renamed from: i  reason: collision with root package name */
    public LinearLayout f335i;

    /* renamed from: j  reason: collision with root package name */
    public final Drawable f336j;

    /* renamed from: k  reason: collision with root package name */
    public final int f337k;

    /* renamed from: l  reason: collision with root package name */
    public final Context f338l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f339m;

    /* renamed from: n  reason: collision with root package name */
    public final Drawable f340n;

    /* renamed from: o  reason: collision with root package name */
    public final boolean f341o;

    /* renamed from: p  reason: collision with root package name */
    public LayoutInflater f342p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f343q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        h p2 = h.p(getContext(), attributeSet, C0009a.f710r, R.attr.listMenuViewStyle);
        this.f336j = p2.k(5);
        TypedArray typedArray = (TypedArray) p2.b;
        this.f337k = typedArray.getResourceId(1, -1);
        this.f339m = typedArray.getBoolean(7, false);
        this.f338l = context;
        this.f340n = p2.k(8);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, R.attr.dropDownListViewStyle, 0);
        this.f341o = obtainStyledAttributes.hasValue(0);
        p2.r();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f342p == null) {
            this.f342p = LayoutInflater.from(getContext());
        }
        return this.f342p;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        int i2;
        ImageView imageView = this.f333g;
        if (imageView != null) {
            if (z2) {
                i2 = 0;
            } else {
                i2 = 8;
            }
            imageView.setVisibility(i2);
        }
    }

    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f334h;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f334h.getLayoutParams();
            rect.top = this.f334h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x005b, code lost:
        if (r0 == false) goto L_0x005e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x003f  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0061  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0125  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(h.p r11) {
        /*
            r10 = this;
            r10.f329a = r11
            boolean r0 = r11.isVisible()
            r1 = 8
            r2 = 0
            if (r0 == 0) goto L_0x000d
            r0 = r2
            goto L_0x000e
        L_0x000d:
            r0 = r1
        L_0x000e:
            r10.setVisibility(r0)
            java.lang.CharSequence r0 = r11.f1061e
            r10.setTitle(r0)
            boolean r0 = r11.isCheckable()
            r10.setCheckable(r0)
            h.n r0 = r11.f1069n
            boolean r0 = r0.o()
            r3 = 1
            if (r0 == 0) goto L_0x0037
            h.n r0 = r11.f1069n
            boolean r0 = r0.n()
            if (r0 == 0) goto L_0x0031
            char r0 = r11.f1065j
            goto L_0x0033
        L_0x0031:
            char r0 = r11.f1063h
        L_0x0033:
            if (r0 == 0) goto L_0x0037
            r0 = r3
            goto L_0x0038
        L_0x0037:
            r0 = r2
        L_0x0038:
            h.n r4 = r11.f1069n
            r4.n()
            if (r0 == 0) goto L_0x005e
            h.p r0 = r10.f329a
            h.n r4 = r0.f1069n
            boolean r4 = r4.o()
            if (r4 == 0) goto L_0x005a
            h.n r4 = r0.f1069n
            boolean r4 = r4.n()
            if (r4 == 0) goto L_0x0054
            char r0 = r0.f1065j
            goto L_0x0056
        L_0x0054:
            char r0 = r0.f1063h
        L_0x0056:
            if (r0 == 0) goto L_0x005a
            r0 = r3
            goto L_0x005b
        L_0x005a:
            r0 = r2
        L_0x005b:
            if (r0 == 0) goto L_0x005e
            goto L_0x005f
        L_0x005e:
            r2 = r1
        L_0x005f:
            if (r2 != 0) goto L_0x011d
            android.widget.TextView r0 = r10.f
            h.p r4 = r10.f329a
            h.n r5 = r4.f1069n
            boolean r5 = r5.n()
            if (r5 == 0) goto L_0x0070
            char r5 = r4.f1065j
            goto L_0x0072
        L_0x0070:
            char r5 = r4.f1063h
        L_0x0072:
            if (r5 != 0) goto L_0x0078
            java.lang.String r1 = ""
            goto L_0x011a
        L_0x0078:
            h.n r6 = r4.f1069n
            android.content.Context r7 = r6.f1031a
            android.content.res.Resources r7 = r7.getResources()
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            android.content.Context r9 = r6.f1031a
            android.view.ViewConfiguration r9 = android.view.ViewConfiguration.get(r9)
            boolean r9 = r9.hasPermanentMenuKey()
            if (r9 == 0) goto L_0x009b
            r9 = 2131623953(0x7f0e0011, float:1.8875072E38)
            java.lang.String r9 = r7.getString(r9)
            r8.append(r9)
        L_0x009b:
            boolean r6 = r6.n()
            if (r6 == 0) goto L_0x00a4
            int r4 = r4.f1066k
            goto L_0x00a6
        L_0x00a4:
            int r4 = r4.f1064i
        L_0x00a6:
            r6 = 2131623949(0x7f0e000d, float:1.8875064E38)
            java.lang.String r6 = r7.getString(r6)
            r9 = 65536(0x10000, float:9.18355E-41)
            h.p.c(r8, r4, r9, r6)
            r6 = 2131623945(0x7f0e0009, float:1.8875056E38)
            java.lang.String r6 = r7.getString(r6)
            r9 = 4096(0x1000, float:5.74E-42)
            h.p.c(r8, r4, r9, r6)
            r6 = 2131623944(0x7f0e0008, float:1.8875054E38)
            java.lang.String r6 = r7.getString(r6)
            r9 = 2
            h.p.c(r8, r4, r9, r6)
            r6 = 2131623950(0x7f0e000e, float:1.8875066E38)
            java.lang.String r6 = r7.getString(r6)
            h.p.c(r8, r4, r3, r6)
            r3 = 2131623952(0x7f0e0010, float:1.887507E38)
            java.lang.String r3 = r7.getString(r3)
            r6 = 4
            h.p.c(r8, r4, r6, r3)
            r3 = 2131623948(0x7f0e000c, float:1.8875062E38)
            java.lang.String r3 = r7.getString(r3)
            h.p.c(r8, r4, r1, r3)
            if (r5 == r1) goto L_0x010c
            r1 = 10
            if (r5 == r1) goto L_0x0101
            r1 = 32
            if (r5 == r1) goto L_0x00f6
            r8.append(r5)
            goto L_0x0116
        L_0x00f6:
            r1 = 2131623951(0x7f0e000f, float:1.8875068E38)
            java.lang.String r1 = r7.getString(r1)
            r8.append(r1)
            goto L_0x0116
        L_0x0101:
            r1 = 2131623947(0x7f0e000b, float:1.887506E38)
            java.lang.String r1 = r7.getString(r1)
            r8.append(r1)
            goto L_0x0116
        L_0x010c:
            r1 = 2131623946(0x7f0e000a, float:1.8875058E38)
            java.lang.String r1 = r7.getString(r1)
            r8.append(r1)
        L_0x0116:
            java.lang.String r1 = r8.toString()
        L_0x011a:
            r0.setText(r1)
        L_0x011d:
            android.widget.TextView r0 = r10.f
            int r0 = r0.getVisibility()
            if (r0 == r2) goto L_0x012a
            android.widget.TextView r0 = r10.f
            r0.setVisibility(r2)
        L_0x012a:
            android.graphics.drawable.Drawable r0 = r11.getIcon()
            r10.setIcon(r0)
            boolean r0 = r11.isEnabled()
            r10.setEnabled(r0)
            boolean r0 = r11.hasSubMenu()
            r10.setSubMenuArrowVisible(r0)
            java.lang.CharSequence r11 = r11.f1072q
            r10.setContentDescription(r11)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ListMenuItemView.c(h.p):void");
    }

    public p getItemData() {
        return this.f329a;
    }

    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f336j);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f331d = textView;
        int i2 = this.f337k;
        if (i2 != -1) {
            textView.setTextAppearance(this.f338l, i2);
        }
        this.f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f333g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f340n);
        }
        this.f334h = (ImageView) findViewById(R.id.group_divider);
        this.f335i = (LinearLayout) findViewById(R.id.content);
    }

    public final void onMeasure(int i2, int i3) {
        if (this.b != null && this.f339m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.b.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        View view;
        CompoundButton compoundButton;
        if (z2 || this.f330c != null || this.f332e != null) {
            if ((this.f329a.f1079x & 4) != 0) {
                if (this.f330c == null) {
                    RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, this, false);
                    this.f330c = radioButton;
                    LinearLayout linearLayout = this.f335i;
                    if (linearLayout != null) {
                        linearLayout.addView(radioButton, -1);
                    } else {
                        addView(radioButton, -1);
                    }
                }
                compoundButton = this.f330c;
                view = this.f332e;
            } else {
                if (this.f332e == null) {
                    CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, this, false);
                    this.f332e = checkBox;
                    LinearLayout linearLayout2 = this.f335i;
                    if (linearLayout2 != null) {
                        linearLayout2.addView(checkBox, -1);
                    } else {
                        addView(checkBox, -1);
                    }
                }
                compoundButton = this.f332e;
                view = this.f330c;
            }
            if (z2) {
                compoundButton.setChecked(this.f329a.isChecked());
                if (compoundButton.getVisibility() != 0) {
                    compoundButton.setVisibility(0);
                }
                if (view != null && view.getVisibility() != 8) {
                    view.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox2 = this.f332e;
            if (checkBox2 != null) {
                checkBox2.setVisibility(8);
            }
            RadioButton radioButton2 = this.f330c;
            if (radioButton2 != null) {
                radioButton2.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if ((this.f329a.f1079x & 4) != 0) {
            if (this.f330c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, this, false);
                this.f330c = radioButton;
                LinearLayout linearLayout = this.f335i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f330c;
        } else {
            if (this.f332e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, this, false);
                this.f332e = checkBox;
                LinearLayout linearLayout2 = this.f335i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f332e;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f343q = z2;
        this.f339m = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        int i2;
        ImageView imageView = this.f334h;
        if (imageView != null) {
            if (this.f341o || !z2) {
                i2 = 8;
            } else {
                i2 = 0;
            }
            imageView.setVisibility(i2);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f329a.f1069n.getClass();
        boolean z2 = this.f343q;
        if (z2 || this.f339m) {
            ImageView imageView = this.b;
            if (imageView != null || drawable != null || this.f339m) {
                if (imageView == null) {
                    ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, this, false);
                    this.b = imageView2;
                    LinearLayout linearLayout = this.f335i;
                    if (linearLayout != null) {
                        linearLayout.addView(imageView2, 0);
                    } else {
                        addView(imageView2, 0);
                    }
                }
                if (drawable != null || this.f339m) {
                    ImageView imageView3 = this.b;
                    if (!z2) {
                        drawable = null;
                    }
                    imageView3.setImageDrawable(drawable);
                    if (this.b.getVisibility() != 0) {
                        this.b.setVisibility(0);
                        return;
                    }
                    return;
                }
                this.b.setVisibility(8);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence != null) {
            this.f331d.setText(charSequence);
            if (this.f331d.getVisibility() != 0) {
                this.f331d.setVisibility(0);
            }
        } else if (this.f331d.getVisibility() != 8) {
            this.f331d.setVisibility(8);
        }
    }
}
