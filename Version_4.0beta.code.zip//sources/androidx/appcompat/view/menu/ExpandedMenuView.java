package androidx.appcompat.view.menu;

import C.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import h.B;
import h.m;
import h.n;
import h.p;
import h.z;

public final class ExpandedMenuView extends ListView implements m, B, AdapterView.OnItemClickListener {
    public static final int[] b = {16842964, 16843049};

    /* renamed from: a  reason: collision with root package name */
    public n f328a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        h p2 = h.p(context, attributeSet, b, 16842868);
        TypedArray typedArray = (TypedArray) p2.b;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(p2.k(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(p2.k(1));
        }
        p2.r();
    }

    public final void a(n nVar) {
        this.f328a = nVar;
    }

    public final boolean b(p pVar) {
        return this.f328a.q(pVar, (z) null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        b((p) getAdapter().getItem(i2));
    }
}
