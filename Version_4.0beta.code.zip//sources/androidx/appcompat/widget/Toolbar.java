package androidx.appcompat.widget;

import C.h;
import D.b;
import D.g;
import G.a;
import S.c;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import d.C0009a;
import g.C0032h;
import h.n;
import h.p;
import i.C0044B;
import i.C0054d0;
import i.C0069l;
import i.C0072m0;
import i.C0096z;
import i.P0;
import i.W0;
import i.X0;
import i.Y0;
import i.Z0;
import i.a1;
import i.b1;
import i.c1;
import i.d1;
import i.e1;
import i.m1;
import java.util.ArrayList;
import nikodemai.firmware.ncs.R;
import y.K;

public class Toolbar extends ViewGroup {

    /* renamed from: A  reason: collision with root package name */
    public ColorStateList f421A;

    /* renamed from: B  reason: collision with root package name */
    public boolean f422B;

    /* renamed from: C  reason: collision with root package name */
    public boolean f423C;

    /* renamed from: D  reason: collision with root package name */
    public final ArrayList f424D = new ArrayList();

    /* renamed from: E  reason: collision with root package name */
    public final ArrayList f425E = new ArrayList();

    /* renamed from: F  reason: collision with root package name */
    public final int[] f426F = new int[2];

    /* renamed from: G  reason: collision with root package name */
    public final a f427G = new a((Runnable) new W0(this, 1));

    /* renamed from: H  reason: collision with root package name */
    public ArrayList f428H = new ArrayList();

    /* renamed from: I  reason: collision with root package name */
    public final X0 f429I = new X0(this);

    /* renamed from: J  reason: collision with root package name */
    public e1 f430J;

    /* renamed from: K  reason: collision with root package name */
    public C0069l f431K;

    /* renamed from: L  reason: collision with root package name */
    public Z0 f432L;

    /* renamed from: M  reason: collision with root package name */
    public boolean f433M;

    /* renamed from: N  reason: collision with root package name */
    public OnBackInvokedCallback f434N;

    /* renamed from: O  reason: collision with root package name */
    public OnBackInvokedDispatcher f435O;

    /* renamed from: P  reason: collision with root package name */
    public boolean f436P;

    /* renamed from: Q  reason: collision with root package name */
    public final b f437Q = new b(7, (Object) this);

    /* renamed from: a  reason: collision with root package name */
    public ActionMenuView f438a;
    public C0054d0 b;

    /* renamed from: c  reason: collision with root package name */
    public C0054d0 f439c;

    /* renamed from: d  reason: collision with root package name */
    public C0096z f440d;

    /* renamed from: e  reason: collision with root package name */
    public C0044B f441e;
    public final Drawable f;

    /* renamed from: g  reason: collision with root package name */
    public final CharSequence f442g;

    /* renamed from: h  reason: collision with root package name */
    public C0096z f443h;

    /* renamed from: i  reason: collision with root package name */
    public View f444i;

    /* renamed from: j  reason: collision with root package name */
    public Context f445j;

    /* renamed from: k  reason: collision with root package name */
    public int f446k;

    /* renamed from: l  reason: collision with root package name */
    public int f447l;

    /* renamed from: m  reason: collision with root package name */
    public int f448m;

    /* renamed from: n  reason: collision with root package name */
    public final int f449n;

    /* renamed from: o  reason: collision with root package name */
    public final int f450o;

    /* renamed from: p  reason: collision with root package name */
    public int f451p;

    /* renamed from: q  reason: collision with root package name */
    public int f452q;

    /* renamed from: r  reason: collision with root package name */
    public int f453r;

    /* renamed from: s  reason: collision with root package name */
    public int f454s;

    /* renamed from: t  reason: collision with root package name */
    public P0 f455t;

    /* renamed from: u  reason: collision with root package name */
    public int f456u;

    /* renamed from: v  reason: collision with root package name */
    public int f457v;

    /* renamed from: w  reason: collision with root package name */
    public final int f458w = 8388627;

    /* renamed from: x  reason: collision with root package name */
    public CharSequence f459x;

    /* renamed from: y  reason: collision with root package name */
    public CharSequence f460y;

    /* renamed from: z  reason: collision with root package name */
    public ColorStateList f461z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.toolbarStyle);
        Context context2 = getContext();
        int[] iArr = C0009a.f715w;
        h p2 = h.p(context2, attributeSet, iArr, R.attr.toolbarStyle);
        K.g(this, context, iArr, attributeSet, (TypedArray) p2.b, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) p2.b;
        this.f447l = typedArray.getResourceId(28, 0);
        this.f448m = typedArray.getResourceId(19, 0);
        this.f458w = typedArray.getInteger(0, 8388627);
        this.f449n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f454s = dimensionPixelOffset;
        this.f453r = dimensionPixelOffset;
        this.f452q = dimensionPixelOffset;
        this.f451p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f451p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f452q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f453r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f454s = dimensionPixelOffset5;
        }
        this.f450o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        P0 p0 = this.f455t;
        p0.f1176h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            p0.f1174e = dimensionPixelSize;
            p0.f1171a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            p0.f = dimensionPixelSize2;
            p0.b = dimensionPixelSize2;
        }
        if (!(dimensionPixelOffset6 == Integer.MIN_VALUE && dimensionPixelOffset7 == Integer.MIN_VALUE)) {
            p0.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f456u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f457v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f = p2.k(4);
        this.f442g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f445j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable k2 = p2.k(16);
        if (k2 != null) {
            setNavigationIcon(k2);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable k3 = p2.k(11);
        if (k3 != null) {
            setLogo(k3);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(p2.j(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(p2.j(20));
        }
        if (typedArray.hasValue(14)) {
            getMenuInflater().inflate(typedArray.getResourceId(14, 0), getMenu());
        }
        p2.r();
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i2 = 0; i2 < menu.size(); i2++) {
            arrayList.add(menu.getItem(i2));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new C0032h(getContext());
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [i.a1, android.view.ViewGroup$MarginLayoutParams] */
    public static a1 h() {
        ? marginLayoutParams = new ViewGroup.MarginLayoutParams(-2, -2);
        marginLayoutParams.b = 0;
        marginLayoutParams.f1215a = 8388627;
        return marginLayoutParams;
    }

    public static a1 i(ViewGroup.LayoutParams layoutParams) {
        boolean z2 = layoutParams instanceof a1;
        if (z2) {
            a1 a1Var = (a1) layoutParams;
            a1 a1Var2 = new a1(a1Var);
            a1Var2.b = 0;
            a1Var2.b = a1Var.b;
            return a1Var2;
        } else if (z2) {
            a1 a1Var3 = new a1((a1) layoutParams);
            a1Var3.b = 0;
            return a1Var3;
        } else if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            a1 a1Var4 = new a1((ViewGroup.LayoutParams) marginLayoutParams);
            a1Var4.b = 0;
            a1Var4.leftMargin = marginLayoutParams.leftMargin;
            a1Var4.topMargin = marginLayoutParams.topMargin;
            a1Var4.rightMargin = marginLayoutParams.rightMargin;
            a1Var4.bottomMargin = marginLayoutParams.bottomMargin;
            return a1Var4;
        } else {
            a1 a1Var5 = new a1(layoutParams);
            a1Var5.b = 0;
            return a1Var5;
        }
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i2) {
        boolean z2;
        if (getLayoutDirection() == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        arrayList.clear();
        if (z2) {
            for (int i3 = childCount - 1; i3 >= 0; i3--) {
                View childAt = getChildAt(i3);
                a1 a1Var = (a1) childAt.getLayoutParams();
                if (a1Var.b == 0 && s(childAt)) {
                    int i4 = a1Var.f1215a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i4, layoutDirection) & 7;
                    if (!(absoluteGravity2 == 1 || absoluteGravity2 == 3 || absoluteGravity2 == 5)) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt2 = getChildAt(i5);
            a1 a1Var2 = (a1) childAt2.getLayoutParams();
            if (a1Var2.b == 0 && s(childAt2)) {
                int i6 = a1Var2.f1215a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i6, layoutDirection2) & 7;
                if (!(absoluteGravity3 == 1 || absoluteGravity3 == 3 || absoluteGravity3 == 5)) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z2) {
        a1 a1Var;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            a1Var = h();
        } else if (!checkLayoutParams(layoutParams)) {
            a1Var = i(layoutParams);
        } else {
            a1Var = (a1) layoutParams;
        }
        a1Var.b = 1;
        if (!z2 || this.f444i == null) {
            addView(view, a1Var);
            return;
        }
        view.setLayoutParams(a1Var);
        this.f425E.add(view);
    }

    public final void c() {
        if (this.f443h == null) {
            C0096z zVar = new C0096z(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            this.f443h = zVar;
            zVar.setImageDrawable(this.f);
            this.f443h.setContentDescription(this.f442g);
            a1 h2 = h();
            h2.f1215a = (this.f449n & 112) | 8388611;
            h2.b = 2;
            this.f443h.setLayoutParams(h2);
            this.f443h.setOnClickListener(new c(3, this));
        }
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (!super.checkLayoutParams(layoutParams) || !(layoutParams instanceof a1)) {
            return false;
        }
        return true;
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [i.P0, java.lang.Object] */
    public final void d() {
        if (this.f455t == null) {
            ? obj = new Object();
            obj.f1171a = 0;
            obj.b = 0;
            obj.f1172c = Integer.MIN_VALUE;
            obj.f1173d = Integer.MIN_VALUE;
            obj.f1174e = 0;
            obj.f = 0;
            obj.f1175g = false;
            obj.f1176h = false;
            this.f455t = obj;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f438a;
        if (actionMenuView.f398p == null) {
            n nVar = (n) actionMenuView.getMenu();
            if (this.f432L == null) {
                this.f432L = new Z0(this);
            }
            this.f438a.setExpandedActionViewsExclusive(true);
            nVar.b(this.f432L, this.f445j);
            t();
        }
    }

    public final void f() {
        if (this.f438a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), (AttributeSet) null);
            this.f438a = actionMenuView;
            actionMenuView.setPopupTheme(this.f446k);
            this.f438a.setOnMenuItemClickListener(this.f429I);
            ActionMenuView actionMenuView2 = this.f438a;
            X0 x0 = new X0(this);
            actionMenuView2.getClass();
            actionMenuView2.f403u = x0;
            a1 h2 = h();
            h2.f1215a = (this.f449n & 112) | 8388613;
            this.f438a.setLayoutParams(h2);
            b(this.f438a, false);
        }
    }

    public final void g() {
        if (this.f440d == null) {
            this.f440d = new C0096z(getContext(), (AttributeSet) null, R.attr.toolbarNavigationButtonStyle);
            a1 h2 = h();
            h2.f1215a = (this.f449n & 112) | 8388611;
            this.f440d.setLayoutParams(h2);
        }
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C0096z zVar = this.f443h;
        if (zVar != null) {
            return zVar.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C0096z zVar = this.f443h;
        if (zVar != null) {
            return zVar.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        P0 p0 = this.f455t;
        if (p0 == null) {
            return 0;
        }
        if (p0.f1175g) {
            return p0.f1171a;
        }
        return p0.b;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.f457v;
        if (i2 != Integer.MIN_VALUE) {
            return i2;
        }
        return getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        P0 p0 = this.f455t;
        if (p0 != null) {
            return p0.f1171a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        P0 p0 = this.f455t;
        if (p0 != null) {
            return p0.b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        P0 p0 = this.f455t;
        if (p0 == null) {
            return 0;
        }
        if (p0.f1175g) {
            return p0.b;
        }
        return p0.f1171a;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.f456u;
        if (i2 != Integer.MIN_VALUE) {
            return i2;
        }
        return getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        n nVar;
        ActionMenuView actionMenuView = this.f438a;
        if (actionMenuView == null || (nVar = actionMenuView.f398p) == null || !nVar.hasVisibleItems()) {
            return getContentInsetEnd();
        }
        return Math.max(getContentInsetEnd(), Math.max(this.f457v, 0));
    }

    public int getCurrentContentInsetLeft() {
        if (getLayoutDirection() == 1) {
            return getCurrentContentInsetEnd();
        }
        return getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        if (getLayoutDirection() == 1) {
            return getCurrentContentInsetStart();
        }
        return getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        if (getNavigationIcon() != null) {
            return Math.max(getContentInsetStart(), Math.max(this.f456u, 0));
        }
        return getContentInsetStart();
    }

    public Drawable getLogo() {
        C0044B b2 = this.f441e;
        if (b2 != null) {
            return b2.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        C0044B b2 = this.f441e;
        if (b2 != null) {
            return b2.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f438a.getMenu();
    }

    public View getNavButtonView() {
        return this.f440d;
    }

    public CharSequence getNavigationContentDescription() {
        C0096z zVar = this.f440d;
        if (zVar != null) {
            return zVar.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C0096z zVar = this.f440d;
        if (zVar != null) {
            return zVar.getDrawable();
        }
        return null;
    }

    public C0069l getOuterActionMenuPresenter() {
        return this.f431K;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f438a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f445j;
    }

    public int getPopupTheme() {
        return this.f446k;
    }

    public CharSequence getSubtitle() {
        return this.f460y;
    }

    public final TextView getSubtitleTextView() {
        return this.f439c;
    }

    public CharSequence getTitle() {
        return this.f459x;
    }

    public int getTitleMarginBottom() {
        return this.f454s;
    }

    public int getTitleMarginEnd() {
        return this.f452q;
    }

    public int getTitleMarginStart() {
        return this.f451p;
    }

    public int getTitleMarginTop() {
        return this.f453r;
    }

    public final TextView getTitleTextView() {
        return this.b;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [i.e1, java.lang.Object] */
    public C0072m0 getWrapper() {
        boolean z2;
        Drawable drawable;
        if (this.f430J == null) {
            ? obj = new Object();
            obj.f1240n = 0;
            obj.f1229a = this;
            obj.f1234h = getTitle();
            obj.f1235i = getSubtitle();
            if (obj.f1234h != null) {
                z2 = true;
            } else {
                z2 = false;
            }
            obj.f1233g = z2;
            obj.f = getNavigationIcon();
            String str = null;
            h p2 = h.p(getContext(), (AttributeSet) null, C0009a.f695a, R.attr.actionBarStyle);
            obj.f1241o = p2.k(15);
            TypedArray typedArray = (TypedArray) p2.b;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                obj.f1233g = true;
                obj.f1234h = text;
                if ((obj.b & 8) != 0) {
                    Toolbar toolbar = obj.f1229a;
                    toolbar.setTitle(text);
                    if (obj.f1233g) {
                        K.i(toolbar.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                obj.f1235i = text2;
                if ((obj.b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable k2 = p2.k(20);
            if (k2 != null) {
                obj.f1232e = k2;
                obj.c();
            }
            Drawable k3 = p2.k(17);
            if (k3 != null) {
                obj.f1231d = k3;
                obj.c();
            }
            if (obj.f == null && (drawable = obj.f1241o) != null) {
                obj.f = drawable;
                int i2 = obj.b & 4;
                Toolbar toolbar2 = obj.f1229a;
                if (i2 != 0) {
                    toolbar2.setNavigationIcon(drawable);
                } else {
                    toolbar2.setNavigationIcon((Drawable) null);
                }
            }
            obj.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View inflate = LayoutInflater.from(getContext()).inflate(resourceId, this, false);
                View view = obj.f1230c;
                if (!(view == null || (obj.b & 16) == 0)) {
                    removeView(view);
                }
                obj.f1230c = inflate;
                if (!(inflate == null || (obj.b & 16) == 0)) {
                    addView(inflate);
                }
                obj.a(obj.b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int max = Math.max(dimensionPixelOffset, 0);
                int max2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f455t.a(max, max2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.f447l = resourceId2;
                C0054d0 d0Var = this.b;
                if (d0Var != null) {
                    d0Var.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f448m = resourceId3;
                C0054d0 d0Var2 = this.f439c;
                if (d0Var2 != null) {
                    d0Var2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            p2.r();
            if (R.string.abc_action_bar_up_description != obj.f1240n) {
                obj.f1240n = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i3 = obj.f1240n;
                    if (i3 != 0) {
                        str = getContext().getString(i3);
                    }
                    obj.f1236j = str;
                    obj.b();
                }
            }
            obj.f1236j = getNavigationContentDescription();
            setNavigationOnClickListener(new d1(obj));
            this.f430J = obj;
        }
        return this.f430J;
    }

    public final int j(View view, int i2) {
        int i3;
        a1 a1Var = (a1) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        if (i2 > 0) {
            i3 = (measuredHeight - i2) / 2;
        } else {
            i3 = 0;
        }
        int i4 = a1Var.f1215a & 112;
        if (!(i4 == 16 || i4 == 48 || i4 == 80)) {
            i4 = this.f458w & 112;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - a1Var.bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i5 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i6 = a1Var.topMargin;
        if (i5 < i6) {
            i5 = i6;
        } else {
            int i7 = (((height - paddingBottom) - measuredHeight) - i5) - paddingTop;
            int i8 = a1Var.bottomMargin;
            if (i7 < i8) {
                i5 = Math.max(0, i5 - (i8 - i7));
            }
        }
        return paddingTop + i5;
    }

    public final void m() {
        ArrayList arrayList = this.f428H;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            getMenu().removeItem(((MenuItem) obj).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        this.f427G.d();
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f428H = currentMenuItems2;
    }

    public final boolean n(View view) {
        if (view.getParent() == this || this.f425E.contains(view)) {
            return true;
        }
        return false;
    }

    public final int o(View view, int i2, int i3, int[] iArr) {
        a1 a1Var = (a1) view.getLayoutParams();
        int i4 = a1Var.leftMargin - iArr[0];
        int max = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int j2 = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, j2, max + measuredWidth, view.getMeasuredHeight() + j2);
        return measuredWidth + a1Var.rightMargin + max;
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        t();
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f437Q);
        t();
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f423C = false;
        }
        if (!this.f423C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f423C = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f423C = false;
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:101:0x028f A[LOOP:0: B:100:0x028d->B:101:0x028f, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x02a7 A[LOOP:1: B:103:0x02a5->B:104:0x02a7, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x02c8 A[LOOP:2: B:106:0x02c6->B:107:0x02c8, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x030b  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x0318 A[LOOP:3: B:114:0x0316->B:115:0x0318, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00cd  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0101  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0106  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x011f  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0127  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x012a  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x012e  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0131  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0164  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x019d  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x01aa  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0218  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onLayout(boolean r19, int r20, int r21, int r22, int r23) {
        /*
            r18 = this;
            r0 = r18
            int r1 = r0.getLayoutDirection()
            r2 = 0
            r3 = 1
            if (r1 != r3) goto L_0x000c
            r1 = r3
            goto L_0x000d
        L_0x000c:
            r1 = r2
        L_0x000d:
            int r4 = r0.getWidth()
            int r5 = r0.getHeight()
            int r6 = r0.getPaddingLeft()
            int r7 = r0.getPaddingRight()
            int r8 = r0.getPaddingTop()
            int r9 = r0.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.f426F
            r11[r3] = r2
            r11[r2] = r2
            java.util.WeakHashMap r12 = y.K.f1547a
            int r12 = r0.getMinimumHeight()
            if (r12 < 0) goto L_0x003c
            int r13 = r23 - r21
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003d
        L_0x003c:
            r12 = r2
        L_0x003d:
            i.z r13 = r0.f440d
            boolean r13 = r0.s(r13)
            if (r13 == 0) goto L_0x0058
            if (r1 == 0) goto L_0x0050
            i.z r13 = r0.f440d
            int r13 = r0.p(r13, r10, r12, r11)
            r14 = r13
            r13 = r6
            goto L_0x005a
        L_0x0050:
            i.z r13 = r0.f440d
            int r13 = r0.o(r13, r6, r12, r11)
        L_0x0056:
            r14 = r10
            goto L_0x005a
        L_0x0058:
            r13 = r6
            goto L_0x0056
        L_0x005a:
            i.z r15 = r0.f443h
            boolean r15 = r0.s(r15)
            if (r15 == 0) goto L_0x0071
            if (r1 == 0) goto L_0x006b
            i.z r15 = r0.f443h
            int r14 = r0.p(r15, r14, r12, r11)
            goto L_0x0071
        L_0x006b:
            i.z r15 = r0.f443h
            int r13 = r0.o(r15, r13, r12, r11)
        L_0x0071:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f438a
            boolean r15 = r0.s(r15)
            if (r15 == 0) goto L_0x0088
            if (r1 == 0) goto L_0x0082
            androidx.appcompat.widget.ActionMenuView r15 = r0.f438a
            int r13 = r0.o(r15, r13, r12, r11)
            goto L_0x0088
        L_0x0082:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f438a
            int r14 = r0.p(r15, r14, r12, r11)
        L_0x0088:
            int r15 = r0.getCurrentContentInsetLeft()
            int r16 = r0.getCurrentContentInsetRight()
            r19 = r3
            int r3 = r15 - r13
            int r3 = java.lang.Math.max(r2, r3)
            r11[r2] = r3
            int r3 = r10 - r14
            int r3 = r16 - r3
            int r3 = java.lang.Math.max(r2, r3)
            r11[r19] = r3
            int r3 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r14, r10)
            android.view.View r13 = r0.f444i
            boolean r13 = r0.s(r13)
            if (r13 == 0) goto L_0x00c5
            if (r1 == 0) goto L_0x00bf
            android.view.View r13 = r0.f444i
            int r10 = r0.p(r13, r10, r12, r11)
            goto L_0x00c5
        L_0x00bf:
            android.view.View r13 = r0.f444i
            int r3 = r0.o(r13, r3, r12, r11)
        L_0x00c5:
            i.B r13 = r0.f441e
            boolean r13 = r0.s(r13)
            if (r13 == 0) goto L_0x00dc
            if (r1 == 0) goto L_0x00d6
            i.B r13 = r0.f441e
            int r10 = r0.p(r13, r10, r12, r11)
            goto L_0x00dc
        L_0x00d6:
            i.B r13 = r0.f441e
            int r3 = r0.o(r13, r3, r12, r11)
        L_0x00dc:
            i.d0 r13 = r0.b
            boolean r13 = r0.s(r13)
            i.d0 r14 = r0.f439c
            boolean r14 = r0.s(r14)
            if (r13 == 0) goto L_0x0101
            i.d0 r15 = r0.b
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            i.a1 r15 = (i.a1) r15
            int r2 = r15.topMargin
            r22 = r1
            i.d0 r1 = r0.b
            int r1 = r1.getMeasuredHeight()
            int r1 = r1 + r2
            int r2 = r15.bottomMargin
            int r1 = r1 + r2
            goto L_0x0104
        L_0x0101:
            r22 = r1
            r1 = 0
        L_0x0104:
            if (r14 == 0) goto L_0x011f
            i.d0 r2 = r0.f439c
            android.view.ViewGroup$LayoutParams r2 = r2.getLayoutParams()
            i.a1 r2 = (i.a1) r2
            int r15 = r2.topMargin
            r21 = r1
            i.d0 r1 = r0.f439c
            int r1 = r1.getMeasuredHeight()
            int r1 = r1 + r15
            int r2 = r2.bottomMargin
            int r1 = r1 + r2
            int r1 = r1 + r21
            goto L_0x0121
        L_0x011f:
            r21 = r1
        L_0x0121:
            if (r13 != 0) goto L_0x0125
            if (r14 == 0) goto L_0x0281
        L_0x0125:
            if (r13 == 0) goto L_0x012a
            i.d0 r2 = r0.b
            goto L_0x012c
        L_0x012a:
            i.d0 r2 = r0.f439c
        L_0x012c:
            if (r14 == 0) goto L_0x0131
            i.d0 r15 = r0.f439c
            goto L_0x0133
        L_0x0131:
            i.d0 r15 = r0.b
        L_0x0133:
            android.view.ViewGroup$LayoutParams r2 = r2.getLayoutParams()
            i.a1 r2 = (i.a1) r2
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            i.a1 r15 = (i.a1) r15
            r21 = r1
            if (r13 == 0) goto L_0x014b
            i.d0 r1 = r0.b
            int r1 = r1.getMeasuredWidth()
            if (r1 > 0) goto L_0x0155
        L_0x014b:
            if (r14 == 0) goto L_0x0158
            i.d0 r1 = r0.f439c
            int r1 = r1.getMeasuredWidth()
            if (r1 <= 0) goto L_0x0158
        L_0x0155:
            r23 = r19
            goto L_0x015a
        L_0x0158:
            r23 = 0
        L_0x015a:
            int r1 = r0.f458w
            r1 = r1 & 112(0x70, float:1.57E-43)
            r16 = r3
            r3 = 48
            if (r1 == r3) goto L_0x019d
            r3 = 80
            if (r1 == r3) goto L_0x0193
            int r1 = r5 - r8
            int r1 = r1 - r9
            int r1 = r1 - r21
            int r1 = r1 / 2
            int r3 = r2.topMargin
            r17 = r3
            int r3 = r0.f453r
            int r3 = r17 + r3
            if (r1 >= r3) goto L_0x017b
            r1 = r3
            goto L_0x0191
        L_0x017b:
            int r5 = r5 - r9
            int r5 = r5 - r21
            int r5 = r5 - r1
            int r5 = r5 - r8
            int r2 = r2.bottomMargin
            int r3 = r0.f454s
            int r2 = r2 + r3
            if (r5 >= r2) goto L_0x0191
            int r2 = r15.bottomMargin
            int r2 = r2 + r3
            int r2 = r2 - r5
            int r1 = r1 - r2
            r2 = 0
            int r1 = java.lang.Math.max(r2, r1)
        L_0x0191:
            int r8 = r8 + r1
            goto L_0x01a8
        L_0x0193:
            int r5 = r5 - r9
            int r1 = r15.bottomMargin
            int r5 = r5 - r1
            int r1 = r0.f454s
            int r5 = r5 - r1
            int r8 = r5 - r21
            goto L_0x01a8
        L_0x019d:
            int r1 = r0.getPaddingTop()
            int r2 = r2.topMargin
            int r1 = r1 + r2
            int r2 = r0.f453r
            int r8 = r1 + r2
        L_0x01a8:
            if (r22 == 0) goto L_0x0218
            if (r23 == 0) goto L_0x01af
            int r1 = r0.f451p
            goto L_0x01b0
        L_0x01af:
            r1 = 0
        L_0x01b0:
            r2 = r11[r19]
            int r1 = r1 - r2
            r2 = 0
            int r3 = java.lang.Math.max(r2, r1)
            int r10 = r10 - r3
            int r1 = -r1
            int r1 = java.lang.Math.max(r2, r1)
            r11[r19] = r1
            if (r13 == 0) goto L_0x01e6
            i.d0 r1 = r0.b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            i.a1 r1 = (i.a1) r1
            i.d0 r2 = r0.b
            int r2 = r2.getMeasuredWidth()
            int r2 = r10 - r2
            i.d0 r3 = r0.b
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            i.d0 r5 = r0.b
            r5.layout(r2, r8, r10, r3)
            int r5 = r0.f452q
            int r2 = r2 - r5
            int r1 = r1.bottomMargin
            int r8 = r3 + r1
            goto L_0x01e7
        L_0x01e6:
            r2 = r10
        L_0x01e7:
            if (r14 == 0) goto L_0x020d
            i.d0 r1 = r0.f439c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            i.a1 r1 = (i.a1) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            i.d0 r1 = r0.f439c
            int r1 = r1.getMeasuredWidth()
            int r1 = r10 - r1
            i.d0 r3 = r0.f439c
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            i.d0 r5 = r0.f439c
            r5.layout(r1, r8, r10, r3)
            int r1 = r0.f452q
            int r1 = r10 - r1
            goto L_0x020e
        L_0x020d:
            r1 = r10
        L_0x020e:
            if (r23 == 0) goto L_0x0215
            int r1 = java.lang.Math.min(r2, r1)
            r10 = r1
        L_0x0215:
            r3 = r16
            goto L_0x0281
        L_0x0218:
            if (r23 == 0) goto L_0x021e
            int r1 = r0.f451p
        L_0x021c:
            r2 = 0
            goto L_0x0220
        L_0x021e:
            r1 = 0
            goto L_0x021c
        L_0x0220:
            r3 = r11[r2]
            int r1 = r1 - r3
            int r3 = java.lang.Math.max(r2, r1)
            int r3 = r3 + r16
            int r1 = -r1
            int r1 = java.lang.Math.max(r2, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x0255
            i.d0 r1 = r0.b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            i.a1 r1 = (i.a1) r1
            i.d0 r2 = r0.b
            int r2 = r2.getMeasuredWidth()
            int r2 = r2 + r3
            i.d0 r5 = r0.b
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            i.d0 r9 = r0.b
            r9.layout(r3, r8, r2, r5)
            int r8 = r0.f452q
            int r2 = r2 + r8
            int r1 = r1.bottomMargin
            int r8 = r5 + r1
            goto L_0x0256
        L_0x0255:
            r2 = r3
        L_0x0256:
            if (r14 == 0) goto L_0x027a
            i.d0 r1 = r0.f439c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            i.a1 r1 = (i.a1) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            i.d0 r1 = r0.f439c
            int r1 = r1.getMeasuredWidth()
            int r1 = r1 + r3
            i.d0 r5 = r0.f439c
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            i.d0 r9 = r0.f439c
            r9.layout(r3, r8, r1, r5)
            int r5 = r0.f452q
            int r1 = r1 + r5
            goto L_0x027b
        L_0x027a:
            r1 = r3
        L_0x027b:
            if (r23 == 0) goto L_0x0281
            int r3 = java.lang.Math.max(r2, r1)
        L_0x0281:
            java.util.ArrayList r1 = r0.f424D
            r2 = 3
            r0.a(r1, r2)
            int r2 = r1.size()
            r5 = r3
            r3 = 0
        L_0x028d:
            if (r3 >= r2) goto L_0x029c
            java.lang.Object r8 = r1.get(r3)
            android.view.View r8 = (android.view.View) r8
            int r5 = r0.o(r8, r5, r12, r11)
            int r3 = r3 + 1
            goto L_0x028d
        L_0x029c:
            r2 = 5
            r0.a(r1, r2)
            int r2 = r1.size()
            r3 = 0
        L_0x02a5:
            if (r3 >= r2) goto L_0x02b4
            java.lang.Object r8 = r1.get(r3)
            android.view.View r8 = (android.view.View) r8
            int r10 = r0.p(r8, r10, r12, r11)
            int r3 = r3 + 1
            goto L_0x02a5
        L_0x02b4:
            r3 = r19
            r0.a(r1, r3)
            r2 = 0
            r8 = r11[r2]
            r2 = r11[r3]
            int r3 = r1.size()
            r9 = r2
            r13 = r8
            r2 = 0
            r8 = 0
        L_0x02c6:
            if (r2 >= r3) goto L_0x02fe
            java.lang.Object r14 = r1.get(r2)
            android.view.View r14 = (android.view.View) r14
            android.view.ViewGroup$LayoutParams r15 = r14.getLayoutParams()
            i.a1 r15 = (i.a1) r15
            r16 = r2
            int r2 = r15.leftMargin
            int r2 = r2 - r13
            int r13 = r15.rightMargin
            int r13 = r13 - r9
            r9 = 0
            int r15 = java.lang.Math.max(r9, r2)
            int r17 = java.lang.Math.max(r9, r13)
            int r2 = -r2
            int r2 = java.lang.Math.max(r9, r2)
            int r13 = -r13
            int r13 = java.lang.Math.max(r9, r13)
            int r14 = r14.getMeasuredWidth()
            int r14 = r14 + r15
            int r14 = r14 + r17
            int r8 = r8 + r14
            r14 = 1
            int r15 = r16 + 1
            r9 = r13
            r13 = r2
            r2 = r15
            goto L_0x02c6
        L_0x02fe:
            r9 = 0
            int r4 = r4 - r6
            int r4 = r4 - r7
            int r4 = r4 / 2
            int r4 = r4 + r6
            int r2 = r8 / 2
            int r4 = r4 - r2
            int r8 = r8 + r4
            if (r4 >= r5) goto L_0x030b
            goto L_0x0312
        L_0x030b:
            if (r8 <= r10) goto L_0x0311
            int r8 = r8 - r10
            int r5 = r4 - r8
            goto L_0x0312
        L_0x0311:
            r5 = r4
        L_0x0312:
            int r2 = r1.size()
        L_0x0316:
            if (r9 >= r2) goto L_0x0325
            java.lang.Object r3 = r1.get(r9)
            android.view.View r3 = (android.view.View) r3
            int r5 = r0.o(r3, r5, r12, r11)
            r14 = 1
            int r9 = r9 + r14
            goto L_0x0316
        L_0x0325:
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    public final void onMeasure(int i2, int i3) {
        char c2;
        boolean z2;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        boolean z3 = m1.f1298a;
        int i12 = 0;
        if (getLayoutDirection() == 1) {
            z2 = true;
            c2 = 0;
        } else {
            c2 = 1;
            z2 = false;
        }
        if (s(this.f440d)) {
            r(this.f440d, i2, 0, i3, this.f450o);
            i6 = k(this.f440d) + this.f440d.getMeasuredWidth();
            i5 = Math.max(0, l(this.f440d) + this.f440d.getMeasuredHeight());
            i4 = View.combineMeasuredStates(0, this.f440d.getMeasuredState());
        } else {
            i6 = 0;
            i5 = 0;
            i4 = 0;
        }
        if (s(this.f443h)) {
            r(this.f443h, i2, 0, i3, this.f450o);
            i6 = k(this.f443h) + this.f443h.getMeasuredWidth();
            i5 = Math.max(i5, l(this.f443h) + this.f443h.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.f443h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i6);
        int max2 = Math.max(0, currentContentInsetStart - i6);
        char c3 = z2;
        int[] iArr = this.f426F;
        iArr[c3] = max2;
        if (s(this.f438a)) {
            r(this.f438a, i2, max, i3, this.f450o);
            i7 = k(this.f438a) + this.f438a.getMeasuredWidth();
            i5 = Math.max(i5, l(this.f438a) + this.f438a.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.f438a.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max3 = max + Math.max(currentContentInsetEnd, i7);
        iArr[c2] = Math.max(0, currentContentInsetEnd - i7);
        if (s(this.f444i)) {
            max3 += q(this.f444i, i2, max3, i3, 0, iArr);
            i5 = Math.max(i5, l(this.f444i) + this.f444i.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.f444i.getMeasuredState());
        }
        if (s(this.f441e)) {
            max3 += q(this.f441e, i2, max3, i3, 0, iArr);
            i5 = Math.max(i5, l(this.f441e) + this.f441e.getMeasuredHeight());
            i4 = View.combineMeasuredStates(i4, this.f441e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (((a1) childAt.getLayoutParams()).b != 0 || !s(childAt)) {
                i8 = i8;
            } else {
                i8 += q(childAt, i2, i8, i3, 0, iArr);
                int max4 = Math.max(i5, l(childAt) + childAt.getMeasuredHeight());
                i4 = View.combineMeasuredStates(i4, childAt.getMeasuredState());
                i5 = max4;
            }
        }
        int i14 = i8;
        int i15 = this.f453r + this.f454s;
        int i16 = this.f451p + this.f452q;
        if (s(this.b)) {
            q(this.b, i2, i14 + i16, i3, i15, iArr);
            int k2 = k(this.b) + this.b.getMeasuredWidth();
            i10 = l(this.b) + this.b.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i4, this.b.getMeasuredState());
            i11 = k2;
        } else {
            i10 = 0;
            i9 = i4;
            i11 = 0;
        }
        if (s(this.f439c)) {
            i11 = Math.max(i11, q(this.f439c, i2, i14 + i16, i3, i15 + i10, iArr));
            i10 += l(this.f439c) + this.f439c.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i9, this.f439c.getMeasuredState());
        }
        int max5 = Math.max(i5, i10);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i14 + i11;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max5;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i2, -16777216 & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, i9 << 16);
        if (this.f433M) {
            int childCount2 = getChildCount();
            int i17 = 0;
            while (true) {
                if (i17 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i17);
                if (s(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i17++;
            }
        }
        i12 = resolveSizeAndState2;
        setMeasuredDimension(resolveSizeAndState, i12);
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        n nVar;
        MenuItem findItem;
        if (!(parcelable instanceof c1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c1 c1Var = (c1) parcelable;
        super.onRestoreInstanceState(c1Var.f52a);
        ActionMenuView actionMenuView = this.f438a;
        if (actionMenuView != null) {
            nVar = actionMenuView.f398p;
        } else {
            nVar = null;
        }
        int i2 = c1Var.f1220c;
        if (!(i2 == 0 || this.f432L == null || nVar == null || (findItem = nVar.findItem(i2)) == null)) {
            findItem.expandActionView();
        }
        if (c1Var.f1221d) {
            b bVar = this.f437Q;
            removeCallbacks(bVar);
            post(bVar);
        }
    }

    public final void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        d();
        P0 p0 = this.f455t;
        boolean z2 = true;
        if (i2 != 1) {
            z2 = false;
        }
        if (z2 != p0.f1175g) {
            p0.f1175g = z2;
            if (!p0.f1176h) {
                p0.f1171a = p0.f1174e;
                p0.b = p0.f;
            } else if (z2) {
                int i3 = p0.f1173d;
                if (i3 == Integer.MIN_VALUE) {
                    i3 = p0.f1174e;
                }
                p0.f1171a = i3;
                int i4 = p0.f1172c;
                if (i4 == Integer.MIN_VALUE) {
                    i4 = p0.f;
                }
                p0.b = i4;
            } else {
                int i5 = p0.f1172c;
                if (i5 == Integer.MIN_VALUE) {
                    i5 = p0.f1174e;
                }
                p0.f1171a = i5;
                int i6 = p0.f1173d;
                if (i6 == Integer.MIN_VALUE) {
                    i6 = p0.f;
                }
                p0.b = i6;
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [i.c1, android.os.Parcelable, E.c] */
    public final Parcelable onSaveInstanceState() {
        boolean z2;
        C0069l lVar;
        p pVar;
        ? cVar = new E.c(super.onSaveInstanceState());
        Z0 z0 = this.f432L;
        if (!(z0 == null || (pVar = z0.b) == null)) {
            cVar.f1220c = pVar.f1058a;
        }
        ActionMenuView actionMenuView = this.f438a;
        if (actionMenuView == null || (lVar = actionMenuView.f402t) == null || !lVar.h()) {
            z2 = false;
        } else {
            z2 = true;
        }
        cVar.f1221d = z2;
        return cVar;
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f422B = false;
        }
        if (!this.f422B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f422B = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f422B = false;
        return true;
    }

    public final int p(View view, int i2, int i3, int[] iArr) {
        a1 a1Var = (a1) view.getLayoutParams();
        int i4 = a1Var.rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int j2 = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, j2, max, view.getMeasuredHeight() + j2);
        return max - (measuredWidth + a1Var.leftMargin);
    }

    public final int q(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final void r(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean s(View view) {
        if (view == null || view.getParent() != this || view.getVisibility() == 8) {
            return false;
        }
        return true;
    }

    public void setBackInvokedCallbackEnabled(boolean z2) {
        if (this.f436P != z2) {
            this.f436P = z2;
            t();
        }
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(g.s(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.f433M = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f457v) {
            this.f457v = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f456u) {
            this.f456u = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(g.s(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(g.s(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f440d.setOnClickListener(onClickListener);
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f438a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.f446k != i2) {
            this.f446k = i2;
            if (i2 == 0) {
                this.f445j = getContext();
            } else {
                this.f445j = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.f454s = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.f452q = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.f451p = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.f453r = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public final void t() {
        boolean z2;
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher a2 = Y0.a(this);
            Z0 z0 = this.f432L;
            if (z0 == null || z0.b == null || a2 == null || !isAttachedToWindow() || !this.f436P) {
                z2 = false;
            } else {
                z2 = true;
            }
            if (z2 && this.f435O == null) {
                if (this.f434N == null) {
                    this.f434N = Y0.b(new W0(this, 0));
                }
                Y0.c(a2, this.f434N);
                this.f435O = a2;
            } else if (!z2 && (onBackInvokedDispatcher = this.f435O) != null) {
                Y0.d(onBackInvokedDispatcher, this.f434N);
                this.f435O = null;
            }
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [i.a1, android.view.ViewGroup$LayoutParams, android.view.ViewGroup$MarginLayoutParams] */
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        ? marginLayoutParams = new ViewGroup.MarginLayoutParams(context, attributeSet);
        marginLayoutParams.f1215a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0009a.b);
        marginLayoutParams.f1215a = obtainStyledAttributes.getInt(0, 0);
        obtainStyledAttributes.recycle();
        marginLayoutParams.b = 0;
        return marginLayoutParams;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C0096z zVar = this.f443h;
        if (zVar != null) {
            zVar.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f443h.setImageDrawable(drawable);
            return;
        }
        C0096z zVar = this.f443h;
        if (zVar != null) {
            zVar.setImageDrawable(this.f);
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f441e == null) {
                this.f441e = new C0044B(getContext(), (AttributeSet) null, 0);
            }
            if (!n(this.f441e)) {
                b(this.f441e, true);
            }
        } else {
            C0044B b2 = this.f441e;
            if (b2 != null && n(b2)) {
                removeView(this.f441e);
                this.f425E.remove(this.f441e);
            }
        }
        C0044B b3 = this.f441e;
        if (b3 != null) {
            b3.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f441e == null) {
            this.f441e = new C0044B(getContext(), (AttributeSet) null, 0);
        }
        C0044B b2 = this.f441e;
        if (b2 != null) {
            b2.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        C0096z zVar = this.f440d;
        if (zVar != null) {
            zVar.setContentDescription(charSequence);
            g.S(this.f440d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!n(this.f440d)) {
                b(this.f440d, true);
            }
        } else {
            C0096z zVar = this.f440d;
            if (zVar != null && n(zVar)) {
                removeView(this.f440d);
                this.f425E.remove(this.f440d);
            }
        }
        C0096z zVar2 = this.f440d;
        if (zVar2 != null) {
            zVar2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f439c == null) {
                Context context = getContext();
                C0054d0 d0Var = new C0054d0(context, (AttributeSet) null);
                this.f439c = d0Var;
                d0Var.setSingleLine();
                this.f439c.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f448m;
                if (i2 != 0) {
                    this.f439c.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f421A;
                if (colorStateList != null) {
                    this.f439c.setTextColor(colorStateList);
                }
            }
            if (!n(this.f439c)) {
                b(this.f439c, true);
            }
        } else {
            C0054d0 d0Var2 = this.f439c;
            if (d0Var2 != null && n(d0Var2)) {
                removeView(this.f439c);
                this.f425E.remove(this.f439c);
            }
        }
        C0054d0 d0Var3 = this.f439c;
        if (d0Var3 != null) {
            d0Var3.setText(charSequence);
        }
        this.f460y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f421A = colorStateList;
        C0054d0 d0Var = this.f439c;
        if (d0Var != null) {
            d0Var.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.b == null) {
                Context context = getContext();
                C0054d0 d0Var = new C0054d0(context, (AttributeSet) null);
                this.b = d0Var;
                d0Var.setSingleLine();
                this.b.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f447l;
                if (i2 != 0) {
                    this.b.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f461z;
                if (colorStateList != null) {
                    this.b.setTextColor(colorStateList);
                }
            }
            if (!n(this.b)) {
                b(this.b, true);
            }
        } else {
            C0054d0 d0Var2 = this.b;
            if (d0Var2 != null && n(d0Var2)) {
                removeView(this.b);
                this.f425E.remove(this.b);
            }
        }
        C0054d0 d0Var3 = this.b;
        if (d0Var3 != null) {
            d0Var3.setText(charSequence);
        }
        this.f459x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f461z = colorStateList;
        C0054d0 d0Var = this.b;
        if (d0Var != null) {
            d0Var.setTextColor(colorStateList);
        }
    }

    public void setOnMenuItemClickListener(b1 b1Var) {
    }
}
