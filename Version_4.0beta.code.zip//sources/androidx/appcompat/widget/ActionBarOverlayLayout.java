package androidx.appcompat.widget;

import D.g;
import Q.f;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.core.widget.NestedScrollView;
import e.L;
import h.n;
import h.y;
import i.C0051c;
import i.C0053d;
import i.C0055e;
import i.C0057f;
import i.C0059g;
import i.C0069l;
import i.C0070l0;
import i.C0072m0;
import i.Z0;
import i.e1;
import java.util.WeakHashMap;
import nikodemai.firmware.ncs.R;
import r.C0136c;
import y.A;
import y.C0170n;
import y.C0171o;
import y.C0180y;
import y.K;
import y.U;
import y.V;
import y.W;
import y.X;
import y.d0;
import y.f0;

public class ActionBarOverlayLayout extends ViewGroup implements C0070l0, C0170n, C0171o {

    /* renamed from: C  reason: collision with root package name */
    public static final int[] f369C = {R.attr.actionBarSize, 16842841};

    /* renamed from: D  reason: collision with root package name */
    public static final f0 f370D;

    /* renamed from: E  reason: collision with root package name */
    public static final Rect f371E = new Rect();

    /* renamed from: A  reason: collision with root package name */
    public final f f372A;

    /* renamed from: B  reason: collision with root package name */
    public final C0059g f373B;

    /* renamed from: a  reason: collision with root package name */
    public int f374a;
    public int b = 0;

    /* renamed from: c  reason: collision with root package name */
    public ContentFrameLayout f375c;

    /* renamed from: d  reason: collision with root package name */
    public ActionBarContainer f376d;

    /* renamed from: e  reason: collision with root package name */
    public C0072m0 f377e;
    public Drawable f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f378g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f379h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f380i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f381j;

    /* renamed from: k  reason: collision with root package name */
    public int f382k;

    /* renamed from: l  reason: collision with root package name */
    public int f383l;

    /* renamed from: m  reason: collision with root package name */
    public final Rect f384m = new Rect();

    /* renamed from: n  reason: collision with root package name */
    public final Rect f385n = new Rect();

    /* renamed from: o  reason: collision with root package name */
    public final Rect f386o = new Rect();

    /* renamed from: p  reason: collision with root package name */
    public final Rect f387p = new Rect();

    /* renamed from: q  reason: collision with root package name */
    public f0 f388q;

    /* renamed from: r  reason: collision with root package name */
    public f0 f389r;

    /* renamed from: s  reason: collision with root package name */
    public f0 f390s;

    /* renamed from: t  reason: collision with root package name */
    public f0 f391t;

    /* renamed from: u  reason: collision with root package name */
    public C0055e f392u;

    /* renamed from: v  reason: collision with root package name */
    public OverScroller f393v;

    /* renamed from: w  reason: collision with root package name */
    public ViewPropertyAnimator f394w;

    /* renamed from: x  reason: collision with root package name */
    public final C0051c f395x;

    /* renamed from: y  reason: collision with root package name */
    public final C0053d f396y;

    /* renamed from: z  reason: collision with root package name */
    public final C0053d f397z;

    static {
        X x2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            x2 = new W();
        } else if (i2 >= 29) {
            x2 = new V();
        } else {
            x2 = new U();
        }
        x2.d(C0136c.a(0, 1, 0, 1));
        f370D = x2.b();
    }

    /* JADX WARNING: type inference failed for: r3v14, types: [Q.f, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r3v15, types: [i.g, android.view.View] */
    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        f0 f0Var = f0.b;
        this.f388q = f0Var;
        this.f389r = f0Var;
        this.f390s = f0Var;
        this.f391t = f0Var;
        this.f395x = new C0051c(this);
        this.f396y = new C0053d(this, 0);
        this.f397z = new C0053d(this, 1);
        i(context);
        this.f372A = new Object();
        ? view = new View(context);
        view.setWillNotDraw(true);
        this.f373B = view;
        addView(view);
    }

    public static boolean g(View view, Rect rect, boolean z2) {
        boolean z3;
        int i2;
        C0057f fVar = (C0057f) view.getLayoutParams();
        int i3 = fVar.leftMargin;
        int i4 = rect.left;
        if (i3 != i4) {
            fVar.leftMargin = i4;
            z3 = true;
        } else {
            z3 = false;
        }
        int i5 = fVar.topMargin;
        int i6 = rect.top;
        if (i5 != i6) {
            fVar.topMargin = i6;
            z3 = true;
        }
        int i7 = fVar.rightMargin;
        int i8 = rect.right;
        if (i7 != i8) {
            fVar.rightMargin = i8;
            z3 = true;
        }
        if (!z2 || fVar.bottomMargin == (i2 = rect.bottom)) {
            return z3;
        }
        fVar.bottomMargin = i2;
        return true;
    }

    public final void b(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    public final void c(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0057f;
    }

    public final void d(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        e(nestedScrollView, i2, i3, i4, i5, i6);
    }

    public final void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        if (this.f != null) {
            if (this.f376d.getVisibility() == 0) {
                i2 = (int) (this.f376d.getTranslationY() + ((float) this.f376d.getBottom()) + 0.5f);
            } else {
                i2 = 0;
            }
            this.f.setBounds(0, i2, getWidth(), this.f.getIntrinsicHeight() + i2);
            this.f.draw(canvas);
        }
    }

    public final void e(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(nestedScrollView, i2, i3, i4, i5);
        }
    }

    public final boolean f(View view, View view2, int i2, int i3) {
        if (i3 != 0 || !onStartNestedScroll(view, view2, i2)) {
            return false;
        }
        return true;
    }

    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -1);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f376d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        f fVar = this.f372A;
        return fVar.b | fVar.f145a;
    }

    public CharSequence getTitle() {
        k();
        return ((e1) this.f377e).f1229a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f396y);
        removeCallbacks(this.f397z);
        ViewPropertyAnimator viewPropertyAnimator = this.f394w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f369C);
        boolean z2 = false;
        this.f374a = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f = drawable;
        if (drawable == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        obtainStyledAttributes.recycle();
        this.f393v = new OverScroller(context);
    }

    public final void j(int i2) {
        k();
        if (i2 == 2) {
            ((e1) this.f377e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i2 == 5) {
            ((e1) this.f377e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i2 == 109) {
            setOverlayMode(true);
        }
    }

    public final void k() {
        C0072m0 m0Var;
        if (this.f375c == null) {
            this.f375c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f376d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            View findViewById = findViewById(R.id.action_bar);
            if (findViewById instanceof C0072m0) {
                m0Var = (C0072m0) findViewById;
            } else if (findViewById instanceof Toolbar) {
                m0Var = ((Toolbar) findViewById).getWrapper();
            } else {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(findViewById.getClass().getSimpleName()));
            }
            this.f377e = m0Var;
        }
    }

    public final void l(n nVar, y yVar) {
        k();
        e1 e1Var = (e1) this.f377e;
        C0069l lVar = e1Var.f1239m;
        Toolbar toolbar = e1Var.f1229a;
        if (lVar == null) {
            e1Var.f1239m = new C0069l(toolbar.getContext());
        }
        C0069l lVar2 = e1Var.f1239m;
        lVar2.f1280e = yVar;
        if (nVar != null || toolbar.f438a != null) {
            toolbar.f();
            n nVar2 = toolbar.f438a.f398p;
            if (nVar2 != nVar) {
                if (nVar2 != null) {
                    nVar2.r(toolbar.f431K);
                    nVar2.r(toolbar.f432L);
                }
                if (toolbar.f432L == null) {
                    toolbar.f432L = new Z0(toolbar);
                }
                lVar2.f1291q = true;
                if (nVar != null) {
                    nVar.b(lVar2, toolbar.f445j);
                    nVar.b(toolbar.f432L, toolbar.f445j);
                } else {
                    lVar2.g(toolbar.f445j, (n) null);
                    toolbar.f432L.g(toolbar.f445j, (n) null);
                    lVar2.c();
                    toolbar.f432L.c();
                }
                toolbar.f438a.setPopupTheme(toolbar.f446k);
                toolbar.f438a.setPresenter(lVar2);
                toolbar.f431K = lVar2;
                toolbar.t();
            }
        }
    }

    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        f0 c2 = f0.c(windowInsets, this);
        d0 d0Var = c2.f1584a;
        boolean g2 = g(this.f376d, new Rect(d0Var.j().f1500a, d0Var.j().b, d0Var.j().f1501c, d0Var.j().f1502d), false);
        WeakHashMap weakHashMap = K.f1547a;
        Rect rect = this.f384m;
        A.b(this, c2, rect);
        f0 l2 = d0Var.l(rect.left, rect.top, rect.right, rect.bottom);
        this.f388q = l2;
        boolean z2 = true;
        if (!this.f389r.equals(l2)) {
            this.f389r = this.f388q;
            g2 = true;
        }
        Rect rect2 = this.f385n;
        if (!rect2.equals(rect)) {
            rect2.set(rect);
        } else {
            z2 = g2;
        }
        if (z2) {
            requestLayout();
        }
        return d0Var.a().f1584a.c().f1584a.b().b();
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = K.f1547a;
        C0180y.c(this);
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                C0057f fVar = (C0057f) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = fVar.leftMargin + paddingLeft;
                int i8 = fVar.topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x010c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onMeasure(int r13, int r14) {
        /*
            r12 = this;
            r12.k()
            androidx.appcompat.widget.ActionBarContainer r1 = r12.f376d
            r3 = 0
            r5 = 0
            r0 = r12
            r2 = r13
            r4 = r14
            r0.measureChildWithMargins(r1, r2, r3, r4, r5)
            androidx.appcompat.widget.ActionBarContainer r13 = r0.f376d
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            i.f r13 = (i.C0057f) r13
            androidx.appcompat.widget.ActionBarContainer r14 = r0.f376d
            int r14 = r14.getMeasuredWidth()
            int r1 = r13.leftMargin
            int r14 = r14 + r1
            int r1 = r13.rightMargin
            int r14 = r14 + r1
            r1 = 0
            int r14 = java.lang.Math.max(r1, r14)
            androidx.appcompat.widget.ActionBarContainer r3 = r0.f376d
            int r3 = r3.getMeasuredHeight()
            int r5 = r13.topMargin
            int r3 = r3 + r5
            int r13 = r13.bottomMargin
            int r3 = r3 + r13
            int r13 = java.lang.Math.max(r1, r3)
            androidx.appcompat.widget.ActionBarContainer r3 = r0.f376d
            int r3 = r3.getMeasuredState()
            int r3 = android.view.View.combineMeasuredStates(r1, r3)
            java.util.WeakHashMap r5 = y.K.f1547a
            int r5 = r12.getWindowSystemUiVisibility()
            r5 = r5 & 256(0x100, float:3.59E-43)
            r6 = 1
            if (r5 == 0) goto L_0x004d
            r5 = r6
            goto L_0x004e
        L_0x004d:
            r5 = r1
        L_0x004e:
            if (r5 == 0) goto L_0x0062
            int r7 = r0.f374a
            boolean r8 = r0.f379h
            if (r8 == 0) goto L_0x0074
            androidx.appcompat.widget.ActionBarContainer r8 = r0.f376d
            android.view.View r8 = r8.getTabContainer()
            if (r8 == 0) goto L_0x0074
            int r8 = r0.f374a
            int r7 = r7 + r8
            goto L_0x0074
        L_0x0062:
            androidx.appcompat.widget.ActionBarContainer r7 = r0.f376d
            int r7 = r7.getVisibility()
            r8 = 8
            if (r7 == r8) goto L_0x0073
            androidx.appcompat.widget.ActionBarContainer r7 = r0.f376d
            int r7 = r7.getMeasuredHeight()
            goto L_0x0074
        L_0x0073:
            r7 = r1
        L_0x0074:
            android.graphics.Rect r8 = r0.f384m
            android.graphics.Rect r9 = r0.f386o
            r9.set(r8)
            y.f0 r8 = r0.f388q
            r0.f390s = r8
            boolean r8 = r0.f378g
            if (r8 != 0) goto L_0x00aa
            if (r5 != 0) goto L_0x00aa
            i.g r5 = r0.f373B
            y.f0 r8 = f370D
            android.graphics.Rect r10 = r0.f387p
            y.A.b(r5, r8, r10)
            android.graphics.Rect r5 = f371E
            boolean r5 = r10.equals(r5)
            if (r5 != 0) goto L_0x00aa
            int r5 = r9.top
            int r5 = r5 + r7
            r9.top = r5
            int r5 = r9.bottom
            r9.bottom = r5
            y.f0 r5 = r0.f390s
            y.d0 r5 = r5.f1584a
            y.f0 r1 = r5.l(r1, r7, r1, r1)
            r0.f390s = r1
            goto L_0x00fd
        L_0x00aa:
            y.f0 r1 = r0.f390s
            y.d0 r1 = r1.f1584a
            r.c r1 = r1.j()
            int r1 = r1.f1500a
            y.f0 r5 = r0.f390s
            y.d0 r5 = r5.f1584a
            r.c r5 = r5.j()
            int r5 = r5.b
            int r5 = r5 + r7
            y.f0 r7 = r0.f390s
            y.d0 r7 = r7.f1584a
            r.c r7 = r7.j()
            int r7 = r7.f1501c
            y.f0 r8 = r0.f390s
            y.d0 r8 = r8.f1584a
            r.c r8 = r8.j()
            int r8 = r8.f1502d
            r.c r1 = r.C0136c.a(r1, r5, r7, r8)
            y.f0 r5 = r0.f390s
            int r7 = android.os.Build.VERSION.SDK_INT
            r8 = 30
            if (r7 < r8) goto L_0x00e5
            y.W r7 = new y.W
            r7.<init>(r5)
            goto L_0x00f4
        L_0x00e5:
            r8 = 29
            if (r7 < r8) goto L_0x00ef
            y.V r7 = new y.V
            r7.<init>(r5)
            goto L_0x00f4
        L_0x00ef:
            y.U r7 = new y.U
            r7.<init>(r5)
        L_0x00f4:
            r7.d(r1)
            y.f0 r1 = r7.b()
            r0.f390s = r1
        L_0x00fd:
            androidx.appcompat.widget.ContentFrameLayout r1 = r0.f375c
            g(r1, r9, r6)
            y.f0 r1 = r0.f391t
            y.f0 r5 = r0.f390s
            boolean r1 = r1.equals(r5)
            if (r1 != 0) goto L_0x0125
            y.f0 r1 = r0.f390s
            r0.f391t = r1
            androidx.appcompat.widget.ContentFrameLayout r5 = r0.f375c
            android.view.WindowInsets r1 = r1.b()
            if (r1 == 0) goto L_0x0125
            android.view.WindowInsets r6 = y.C0180y.a(r5, r1)
            boolean r1 = r6.equals(r1)
            if (r1 != 0) goto L_0x0125
            y.f0.c(r6, r5)
        L_0x0125:
            androidx.appcompat.widget.ContentFrameLayout r7 = r0.f375c
            r9 = 0
            r11 = 0
            r6 = r0
            r8 = r2
            r10 = r4
            r6.measureChildWithMargins(r7, r8, r9, r10, r11)
            androidx.appcompat.widget.ContentFrameLayout r1 = r0.f375c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            i.f r1 = (i.C0057f) r1
            androidx.appcompat.widget.ContentFrameLayout r5 = r0.f375c
            int r5 = r5.getMeasuredWidth()
            int r6 = r1.leftMargin
            int r5 = r5 + r6
            int r6 = r1.rightMargin
            int r5 = r5 + r6
            int r14 = java.lang.Math.max(r14, r5)
            androidx.appcompat.widget.ContentFrameLayout r5 = r0.f375c
            int r5 = r5.getMeasuredHeight()
            int r6 = r1.topMargin
            int r5 = r5 + r6
            int r1 = r1.bottomMargin
            int r5 = r5 + r1
            int r13 = java.lang.Math.max(r13, r5)
            androidx.appcompat.widget.ContentFrameLayout r1 = r0.f375c
            int r1 = r1.getMeasuredState()
            int r1 = android.view.View.combineMeasuredStates(r3, r1)
            int r3 = r12.getPaddingLeft()
            int r5 = r12.getPaddingRight()
            int r5 = r5 + r3
            int r5 = r5 + r14
            int r14 = r12.getPaddingTop()
            int r3 = r12.getPaddingBottom()
            int r3 = r3 + r14
            int r3 = r3 + r13
            int r13 = r12.getSuggestedMinimumHeight()
            int r13 = java.lang.Math.max(r3, r13)
            int r14 = r12.getSuggestedMinimumWidth()
            int r14 = java.lang.Math.max(r5, r14)
            int r14 = android.view.View.resolveSizeAndState(r14, r2, r1)
            int r1 = r1 << 16
            int r13 = android.view.View.resolveSizeAndState(r13, r4, r1)
            r12.setMeasuredDimension(r14, r13)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onMeasure(int, int):void");
    }

    public final boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (!this.f380i || !z2) {
            return false;
        }
        this.f393v.fling(0, 0, 0, (int) f3, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f393v.getFinalY() > this.f376d.getHeight()) {
            h();
            this.f397z.run();
        } else {
            h();
            this.f396y.run();
        }
        this.f381j = true;
        return true;
    }

    public final boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f382k + i3;
        this.f382k = i6;
        setActionBarHideOffset(i6);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r1 = (e.L) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onNestedScrollAccepted(android.view.View r1, android.view.View r2, int r3) {
        /*
            r0 = this;
            Q.f r1 = r0.f372A
            r1.f145a = r3
            int r1 = r0.getActionBarHideOffset()
            r0.f382k = r1
            r0.h()
            i.e r1 = r0.f392u
            if (r1 == 0) goto L_0x001d
            e.L r1 = (e.L) r1
            g.j r2 = r1.f807G
            if (r2 == 0) goto L_0x001d
            r2.a()
            r2 = 0
            r1.f807G = r2
        L_0x001d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onNestedScrollAccepted(android.view.View, android.view.View, int):void");
    }

    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f376d.getVisibility() != 0) {
            return false;
        }
        return this.f380i;
    }

    public final void onStopNestedScroll(View view) {
        if (this.f380i && !this.f381j) {
            if (this.f382k <= this.f376d.getHeight()) {
                h();
                postDelayed(this.f396y, 600);
                return;
            }
            h();
            postDelayed(this.f397z, 600);
        }
    }

    public final void onWindowSystemUiVisibilityChanged(int i2) {
        boolean z2;
        boolean z3;
        super.onWindowSystemUiVisibilityChanged(i2);
        k();
        int i3 = this.f383l ^ i2;
        this.f383l = i2;
        if ((i2 & 4) == 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        if ((i2 & 256) != 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        C0055e eVar = this.f392u;
        if (eVar != null) {
            L l2 = (L) eVar;
            l2.f803C = !z3;
            if (z2 || !z3) {
                if (l2.f804D) {
                    l2.f804D = false;
                    l2.a0(true);
                }
            } else if (!l2.f804D) {
                l2.f804D = true;
                l2.a0(true);
            }
        }
        if ((i3 & 256) != 0 && this.f392u != null) {
            WeakHashMap weakHashMap = K.f1547a;
            C0180y.c(this);
        }
    }

    public final void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.b = i2;
        C0055e eVar = this.f392u;
        if (eVar != null) {
            ((L) eVar).f802B = i2;
        }
    }

    public void setActionBarHideOffset(int i2) {
        h();
        this.f376d.setTranslationY((float) (-Math.max(0, Math.min(i2, this.f376d.getHeight()))));
    }

    public void setActionBarVisibilityCallback(C0055e eVar) {
        this.f392u = eVar;
        if (getWindowToken() != null) {
            ((L) this.f392u).f802B = this.b;
            int i2 = this.f383l;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                WeakHashMap weakHashMap = K.f1547a;
                C0180y.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f379h = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f380i) {
            this.f380i = z2;
            if (!z2) {
                h();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i2) {
        k();
        e1 e1Var = (e1) this.f377e;
        e1Var.f1231d = i2 != 0 ? g.s(e1Var.f1229a.getContext(), i2) : null;
        e1Var.c();
    }

    public void setLogo(int i2) {
        Drawable drawable;
        k();
        e1 e1Var = (e1) this.f377e;
        if (i2 != 0) {
            drawable = g.s(e1Var.f1229a.getContext(), i2);
        } else {
            drawable = null;
        }
        e1Var.f1232e = drawable;
        e1Var.c();
    }

    public void setOverlayMode(boolean z2) {
        this.f378g = z2;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    public void setWindowCallback(Window.Callback callback) {
        k();
        ((e1) this.f377e).f1237k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        k();
        e1 e1Var = (e1) this.f377e;
        if (!e1Var.f1233g) {
            e1Var.f1234h = charSequence;
            if ((e1Var.b & 8) != 0) {
                Toolbar toolbar = e1Var.f1229a;
                toolbar.setTitle(charSequence);
                if (e1Var.f1233g) {
                    K.i(toolbar.getRootView(), charSequence);
                }
            }
        }
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ViewGroup.MarginLayoutParams(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        e1 e1Var = (e1) this.f377e;
        e1Var.f1231d = drawable;
        e1Var.c();
    }

    public final void a(int i2, int i3, int[] iArr, int i4) {
    }
}
