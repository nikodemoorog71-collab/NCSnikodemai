package androidx.appcompat.widget;

import C.j;
import F.d;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import h.B;
import h.m;
import h.n;
import h.p;
import h.z;
import i.C0061h;
import i.C0067k;
import i.C0069l;
import i.C0071m;
import i.C0073n;
import i.C0075o;
import i.C0093x0;
import i.C0095y0;
import i.X0;
import i.m1;

public class ActionMenuView extends C0095y0 implements m, B {

    /* renamed from: p  reason: collision with root package name */
    public n f398p;

    /* renamed from: q  reason: collision with root package name */
    public Context f399q;

    /* renamed from: r  reason: collision with root package name */
    public int f400r = 0;

    /* renamed from: s  reason: collision with root package name */
    public boolean f401s;

    /* renamed from: t  reason: collision with root package name */
    public C0069l f402t;

    /* renamed from: u  reason: collision with root package name */
    public X0 f403u;

    /* renamed from: v  reason: collision with root package name */
    public boolean f404v;

    /* renamed from: w  reason: collision with root package name */
    public int f405w;

    /* renamed from: x  reason: collision with root package name */
    public final int f406x;

    /* renamed from: y  reason: collision with root package name */
    public final int f407y;

    /* renamed from: z  reason: collision with root package name */
    public C0075o f408z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f406x = (int) (56.0f * f);
        this.f407y = (int) (f * 4.0f);
        this.f399q = context;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [i.n, android.widget.LinearLayout$LayoutParams] */
    public static C0073n i() {
        ? layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.f1300a = false;
        layoutParams.gravity = 16;
        return layoutParams;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [android.widget.LinearLayout$LayoutParams] */
    /* JADX WARNING: type inference failed for: r0v3, types: [i.n, android.widget.LinearLayout$LayoutParams] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static i.C0073n j(android.view.ViewGroup.LayoutParams r1) {
        /*
            if (r1 == 0) goto L_0x0020
            boolean r0 = r1 instanceof i.C0073n
            if (r0 == 0) goto L_0x0012
            i.n r0 = new i.n
            i.n r1 = (i.C0073n) r1
            r0.<init>(r1)
            boolean r1 = r1.f1300a
            r0.f1300a = r1
            goto L_0x0017
        L_0x0012:
            i.n r0 = new i.n
            r0.<init>(r1)
        L_0x0017:
            int r1 = r0.gravity
            if (r1 > 0) goto L_0x001f
            r1 = 16
            r0.gravity = r1
        L_0x001f:
            return r0
        L_0x0020:
            i.n r1 = i()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionMenuView.j(android.view.ViewGroup$LayoutParams):i.n");
    }

    public final void a(n nVar) {
        this.f398p = nVar;
    }

    public final boolean b(p pVar) {
        return this.f398p.q(pVar, (z) null, 0);
    }

    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0073n;
    }

    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public final /* bridge */ /* synthetic */ C0093x0 e() {
        return i();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [android.widget.LinearLayout$LayoutParams, i.x0] */
    public final C0093x0 f(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }

    public final /* bridge */ /* synthetic */ C0093x0 g(ViewGroup.LayoutParams layoutParams) {
        return j(layoutParams);
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return i();
    }

    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return j(layoutParams);
    }

    public Menu getMenu() {
        if (this.f398p == null) {
            Context context = getContext();
            n nVar = new n(context);
            this.f398p = nVar;
            nVar.f1034e = new j(18, (Object) this);
            C0069l lVar = new C0069l(context);
            this.f402t = lVar;
            lVar.f1286l = true;
            lVar.f1287m = true;
            lVar.f1280e = new d(20);
            this.f398p.b(lVar, this.f399q);
            C0069l lVar2 = this.f402t;
            lVar2.f1282h = this;
            this.f398p = lVar2.f1278c;
        }
        return this.f398p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0069l lVar = this.f402t;
        C0067k kVar = lVar.f1283i;
        if (kVar != null) {
            return kVar.getDrawable();
        }
        if (lVar.f1285k) {
            return lVar.f1284j;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f400r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final boolean k(int i2) {
        boolean z2 = false;
        if (i2 == 0) {
            return false;
        }
        View childAt = getChildAt(i2 - 1);
        View childAt2 = getChildAt(i2);
        if (i2 < getChildCount() && (childAt instanceof C0071m)) {
            z2 = ((C0071m) childAt).b();
        }
        if (i2 <= 0 || !(childAt2 instanceof C0071m)) {
            return z2;
        }
        return ((C0071m) childAt2).a() | z2;
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0069l lVar = this.f402t;
        if (lVar != null) {
            lVar.c();
            if (this.f402t.h()) {
                this.f402t.f();
                this.f402t.l();
            }
        }
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0069l lVar = this.f402t;
        if (lVar != null) {
            lVar.f();
            C0061h hVar = lVar.f1294t;
            if (hVar != null && hVar.b()) {
                hVar.f1097i.dismiss();
            }
        }
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        boolean z3;
        int i6;
        int i7;
        int i8;
        if (!this.f404v) {
            super.onLayout(z2, i2, i3, i4, i5);
            return;
        }
        int childCount = getChildCount();
        int i9 = (i5 - i3) / 2;
        int dividerWidth = getDividerWidth();
        int i10 = i4 - i2;
        int paddingRight = (i10 - getPaddingRight()) - getPaddingLeft();
        boolean z4 = m1.f1298a;
        if (getLayoutDirection() == 1) {
            z3 = true;
        } else {
            z3 = false;
        }
        int i11 = 0;
        int i12 = 0;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                C0073n nVar = (C0073n) childAt.getLayoutParams();
                if (nVar.f1300a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (k(i13)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z3) {
                        i7 = getPaddingLeft() + nVar.leftMargin;
                        i8 = i7 + measuredWidth;
                    } else {
                        i8 = (getWidth() - getPaddingRight()) - nVar.rightMargin;
                        i7 = i8 - measuredWidth;
                    }
                    int i14 = i9 - (measuredHeight / 2);
                    childAt.layout(i7, i14, i8, measuredHeight + i14);
                    paddingRight -= measuredWidth;
                    i11 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + nVar.leftMargin) + nVar.rightMargin;
                    k(i13);
                    i12++;
                }
            }
        }
        if (childCount == 1 && i11 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i15 = (i10 / 2) - (measuredWidth2 / 2);
            int i16 = i9 - (measuredHeight2 / 2);
            childAt2.layout(i15, i16, measuredWidth2 + i15, measuredHeight2 + i16);
            return;
        }
        int i17 = i12 - (i11 ^ 1);
        if (i17 > 0) {
            i6 = paddingRight / i17;
        } else {
            i6 = 0;
        }
        int max = Math.max(0, i6);
        if (z3) {
            int width = getWidth() - getPaddingRight();
            for (int i18 = 0; i18 < childCount; i18++) {
                View childAt3 = getChildAt(i18);
                C0073n nVar2 = (C0073n) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !nVar2.f1300a) {
                    int i19 = width - nVar2.rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i20 = i9 - (measuredHeight3 / 2);
                    childAt3.layout(i19 - measuredWidth3, i20, i19, measuredHeight3 + i20);
                    width = i19 - ((measuredWidth3 + nVar2.leftMargin) + max);
                }
            }
            return;
        }
        int paddingLeft = getPaddingLeft();
        for (int i21 = 0; i21 < childCount; i21++) {
            View childAt4 = getChildAt(i21);
            C0073n nVar3 = (C0073n) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !nVar3.f1300a) {
                int i22 = paddingLeft + nVar3.leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i23 = i9 - (measuredHeight4 / 2);
                childAt4.layout(i22, i23, i22 + measuredWidth4, measuredHeight4 + i23);
                paddingLeft = measuredWidth4 + nVar3.rightMargin + max + i22;
            }
        }
    }

    public final void onMeasure(int i2, int i3) {
        boolean z2;
        int i4;
        boolean z3;
        int i5;
        boolean z4;
        int i6;
        int i7;
        boolean z5;
        int i8;
        boolean z6;
        int i9;
        ActionMenuItemView actionMenuItemView;
        boolean z7;
        int i10;
        boolean z8;
        n nVar;
        boolean z9 = this.f404v;
        if (View.MeasureSpec.getMode(i2) == 1073741824) {
            z2 = true;
        } else {
            z2 = false;
        }
        this.f404v = z2;
        if (z9 != z2) {
            this.f405w = 0;
        }
        int size = View.MeasureSpec.getSize(i2);
        if (!(!this.f404v || (nVar = this.f398p) == null || size == this.f405w)) {
            this.f405w = size;
            nVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f404v || childCount <= 0) {
            int i11 = i3;
            for (int i12 = 0; i12 < childCount; i12++) {
                C0073n nVar2 = (C0073n) getChildAt(i12).getLayoutParams();
                nVar2.rightMargin = 0;
                nVar2.leftMargin = 0;
            }
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i2);
        int size3 = View.MeasureSpec.getSize(i3);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i3, paddingBottom, -2);
        int i13 = size2 - paddingRight;
        int i14 = this.f406x;
        int i15 = i13 / i14;
        int i16 = i13 % i14;
        if (i15 == 0) {
            setMeasuredDimension(i13, 0);
            return;
        }
        int i17 = (i16 / i15) + i14;
        int childCount2 = getChildCount();
        int i18 = 0;
        int i19 = 0;
        int i20 = 0;
        int i21 = 0;
        boolean z10 = false;
        int i22 = 0;
        long j2 = 0;
        while (true) {
            i4 = this.f407y;
            if (i21 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i21);
            int i23 = size3;
            int i24 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i8 = i17;
            } else {
                boolean z11 = childAt instanceof ActionMenuItemView;
                i19++;
                if (z11) {
                    childAt.setPadding(i4, 0, i4, 0);
                }
                C0073n nVar3 = (C0073n) childAt.getLayoutParams();
                nVar3.f = false;
                nVar3.f1301c = 0;
                nVar3.b = 0;
                nVar3.f1302d = false;
                nVar3.leftMargin = 0;
                nVar3.rightMargin = 0;
                if (!z11 || TextUtils.isEmpty(((ActionMenuItemView) childAt).getText())) {
                    z6 = false;
                } else {
                    z6 = true;
                }
                nVar3.f1303e = z6;
                if (nVar3.f1300a) {
                    i9 = 1;
                } else {
                    i9 = i15;
                }
                boolean z12 = z11;
                C0073n nVar4 = (C0073n) childAt.getLayoutParams();
                int i25 = i15;
                i8 = i17;
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i24, View.MeasureSpec.getMode(childMeasureSpec));
                if (z12) {
                    actionMenuItemView = (ActionMenuItemView) childAt;
                } else {
                    actionMenuItemView = null;
                }
                if (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) {
                    z7 = false;
                } else {
                    z7 = true;
                }
                boolean z13 = z7;
                if (i9 <= 0 || (z7 && i9 < 2)) {
                    i10 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i8 * i9, Integer.MIN_VALUE), makeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i10 = measuredWidth / i8;
                    if (measuredWidth % i8 != 0) {
                        i10++;
                    }
                    if (z13 && i10 < 2) {
                        i10 = 2;
                    }
                }
                if (nVar4.f1300a || !z13) {
                    z8 = false;
                } else {
                    z8 = true;
                }
                nVar4.f1302d = z8;
                nVar4.b = i10;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i10 * i8, 1073741824), makeMeasureSpec);
                i20 = Math.max(i20, i10);
                if (nVar3.f1302d) {
                    i22++;
                }
                if (nVar3.f1300a) {
                    z10 = true;
                }
                i15 = i25 - i10;
                i18 = Math.max(i18, childAt.getMeasuredHeight());
                if (i10 == 1) {
                    j2 |= (long) (1 << i21);
                }
            }
            i21++;
            size3 = i23;
            paddingBottom = i24;
            i17 = i8;
        }
        int i26 = size3;
        int i27 = i15;
        int i28 = i17;
        if (!z10 || i19 != 2) {
            z3 = false;
        } else {
            z3 = true;
        }
        int i29 = i27;
        boolean z14 = false;
        while (true) {
            if (i22 <= 0 || i29 <= 0) {
                i5 = i18;
            } else {
                int i30 = Integer.MAX_VALUE;
                long j3 = 0;
                int i31 = 0;
                int i32 = 0;
                while (i32 < childCount2) {
                    boolean z15 = z3;
                    C0073n nVar5 = (C0073n) getChildAt(i32).getLayoutParams();
                    int i33 = i18;
                    if (nVar5.f1302d) {
                        int i34 = nVar5.b;
                        if (i34 < i30) {
                            j3 = 1 << i32;
                            i30 = i34;
                            i31 = 1;
                        } else if (i34 == i30) {
                            j3 |= 1 << i32;
                            i31++;
                        }
                    }
                    i32++;
                    i18 = i33;
                    z3 = z15;
                }
                boolean z16 = z3;
                i5 = i18;
                j2 |= j3;
                if (i31 > i29) {
                    break;
                }
                int i35 = i30 + 1;
                int i36 = 0;
                while (i36 < childCount2) {
                    View childAt2 = getChildAt(i36);
                    C0073n nVar6 = (C0073n) childAt2.getLayoutParams();
                    boolean z17 = z10;
                    long j4 = (long) (1 << i36);
                    if ((j3 & j4) != 0) {
                        if (!z16 || !nVar6.f1303e) {
                            z5 = true;
                        } else {
                            z5 = true;
                            if (i29 == 1) {
                                childAt2.setPadding(i4 + i28, 0, i4, 0);
                            }
                        }
                        nVar6.b += z5 ? 1 : 0;
                        nVar6.f = z5;
                        i29--;
                    } else if (nVar6.b == i35) {
                        j2 |= j4;
                    }
                    i36++;
                    z10 = z17;
                }
                i18 = i5;
                z3 = z16;
                z14 = true;
            }
        }
        i5 = i18;
        if (z10 || i19 != 1) {
            z4 = false;
        } else {
            z4 = true;
        }
        if (i29 > 0 && j2 != 0 && (i29 < i19 - 1 || z4 || i20 > 1)) {
            float bitCount = (float) Long.bitCount(j2);
            if (!z4) {
                if ((j2 & 1) != 0 && !((C0073n) getChildAt(0).getLayoutParams()).f1303e) {
                    bitCount -= 0.5f;
                }
                int i37 = childCount2 - 1;
                if ((j2 & ((long) (1 << i37))) != 0 && !((C0073n) getChildAt(i37).getLayoutParams()).f1303e) {
                    bitCount -= 0.5f;
                }
            }
            if (bitCount > 0.0f) {
                i7 = (int) (((float) (i29 * i28)) / bitCount);
            } else {
                i7 = 0;
            }
            boolean z18 = z14;
            for (int i38 = 0; i38 < childCount2; i38++) {
                if ((j2 & ((long) (1 << i38))) != 0) {
                    View childAt3 = getChildAt(i38);
                    C0073n nVar7 = (C0073n) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        nVar7.f1301c = i7;
                        nVar7.f = true;
                        if (i38 == 0 && !nVar7.f1303e) {
                            nVar7.leftMargin = (-i7) / 2;
                        }
                        z18 = true;
                    } else if (nVar7.f1300a) {
                        nVar7.f1301c = i7;
                        nVar7.f = true;
                        nVar7.rightMargin = (-i7) / 2;
                        z18 = true;
                    } else {
                        if (i38 != 0) {
                            nVar7.leftMargin = i7 / 2;
                        }
                        if (i38 != childCount2 - 1) {
                            nVar7.rightMargin = i7 / 2;
                        }
                    }
                }
            }
            z14 = z18;
        }
        if (z14) {
            for (int i39 = 0; i39 < childCount2; i39++) {
                View childAt4 = getChildAt(i39);
                C0073n nVar8 = (C0073n) childAt4.getLayoutParams();
                if (nVar8.f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((nVar8.b * i28) + nVar8.f1301c, 1073741824), childMeasureSpec);
                }
            }
        }
        if (mode != 1073741824) {
            i6 = i5;
        } else {
            i6 = i26;
        }
        setMeasuredDimension(i13, i6);
    }

    public void setExpandedActionViewsExclusive(boolean z2) {
        this.f402t.f1291q = z2;
    }

    public void setOnMenuItemClickListener(C0075o oVar) {
        this.f408z = oVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0069l lVar = this.f402t;
        C0067k kVar = lVar.f1283i;
        if (kVar != null) {
            kVar.setImageDrawable(drawable);
            return;
        }
        lVar.f1285k = true;
        lVar.f1284j = drawable;
    }

    public void setOverflowReserved(boolean z2) {
        this.f401s = z2;
    }

    public void setPopupTheme(int i2) {
        if (this.f400r != i2) {
            this.f400r = i2;
            if (i2 == 0) {
                this.f399q = getContext();
            } else {
                this.f399q = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setPresenter(C0069l lVar) {
        this.f402t = lVar;
        lVar.f1282h = this;
        this.f398p = lVar.f1278c;
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LinearLayout.LayoutParams(getContext(), attributeSet);
    }
}
