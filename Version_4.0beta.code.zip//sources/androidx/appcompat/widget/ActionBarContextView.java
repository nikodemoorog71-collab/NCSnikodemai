package androidx.appcompat.widget;

import D.g;
import S.c;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import d.C0009a;
import g.C0025a;
import h.B;
import h.n;
import i.C0047a;
import i.C0061h;
import i.C0069l;
import i.m1;
import nikodemai.firmware.ncs.R;
import y.K;
import y.Q;

public class ActionBarContextView extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public final C0047a f351a = new C0047a(this);
    public final Context b;

    /* renamed from: c  reason: collision with root package name */
    public ActionMenuView f352c;

    /* renamed from: d  reason: collision with root package name */
    public C0069l f353d;

    /* renamed from: e  reason: collision with root package name */
    public int f354e;
    public Q f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f355g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f356h;

    /* renamed from: i  reason: collision with root package name */
    public CharSequence f357i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f358j;

    /* renamed from: k  reason: collision with root package name */
    public View f359k;

    /* renamed from: l  reason: collision with root package name */
    public View f360l;

    /* renamed from: m  reason: collision with root package name */
    public View f361m;

    /* renamed from: n  reason: collision with root package name */
    public LinearLayout f362n;

    /* renamed from: o  reason: collision with root package name */
    public TextView f363o;

    /* renamed from: p  reason: collision with root package name */
    public TextView f364p;

    /* renamed from: q  reason: collision with root package name */
    public final int f365q;

    /* renamed from: r  reason: collision with root package name */
    public final int f366r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f367s;

    /* renamed from: t  reason: collision with root package name */
    public final int f368t;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.actionModeStyle);
        Drawable drawable;
        int resourceId;
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.b = context;
        } else {
            this.b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0009a.f697d, R.attr.actionModeStyle, 0);
        if (!obtainStyledAttributes.hasValue(0) || (resourceId = obtainStyledAttributes.getResourceId(0, 0)) == 0) {
            drawable = obtainStyledAttributes.getDrawable(0);
        } else {
            drawable = g.s(context, resourceId);
        }
        setBackground(drawable);
        this.f365q = obtainStyledAttributes.getResourceId(5, 0);
        this.f366r = obtainStyledAttributes.getResourceId(4, 0);
        this.f354e = obtainStyledAttributes.getLayoutDimension(3, 0);
        this.f368t = obtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        obtainStyledAttributes.recycle();
    }

    public static int f(View view, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE), i3);
        return Math.max(0, i2 - view.getMeasuredWidth());
    }

    public static int g(View view, int i2, int i3, int i4, boolean z2) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = ((i4 - measuredHeight) / 2) + i3;
        if (z2) {
            view.layout(i2 - measuredWidth, i5, i2, measuredHeight + i5);
        } else {
            view.layout(i2, i5, i2 + measuredWidth, measuredHeight + i5);
        }
        if (z2) {
            return -measuredWidth;
        }
        return measuredWidth;
    }

    public final void c(C0025a aVar) {
        View view = this.f359k;
        if (view == null) {
            View inflate = LayoutInflater.from(getContext()).inflate(this.f368t, this, false);
            this.f359k = inflate;
            addView(inflate);
        } else if (view.getParent() == null) {
            addView(this.f359k);
        }
        View findViewById = this.f359k.findViewById(R.id.action_mode_close_button);
        this.f360l = findViewById;
        findViewById.setOnClickListener(new c(2, aVar));
        n c2 = aVar.c();
        C0069l lVar = this.f353d;
        if (lVar != null) {
            lVar.f();
            C0061h hVar = lVar.f1294t;
            if (hVar != null && hVar.b()) {
                hVar.f1097i.dismiss();
            }
        }
        C0069l lVar2 = new C0069l(getContext());
        this.f353d = lVar2;
        lVar2.f1286l = true;
        lVar2.f1287m = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        c2.b(this.f353d, this.b);
        C0069l lVar3 = this.f353d;
        B b2 = lVar3.f1282h;
        if (b2 == null) {
            B b3 = (B) lVar3.f1279d.inflate(lVar3.f, this, false);
            lVar3.f1282h = b3;
            b3.a(lVar3.f1278c);
            lVar3.c();
        }
        B b4 = lVar3.f1282h;
        if (b2 != b4) {
            ((ActionMenuView) b4).setPresenter(lVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) b4;
        this.f352c = actionMenuView;
        actionMenuView.setBackground((Drawable) null);
        addView(this.f352c, layoutParams);
    }

    public final void d() {
        int i2;
        if (this.f362n == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f362n = linearLayout;
            this.f363o = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f364p = (TextView) this.f362n.findViewById(R.id.action_bar_subtitle);
            int i3 = this.f365q;
            if (i3 != 0) {
                this.f363o.setTextAppearance(getContext(), i3);
            }
            int i4 = this.f366r;
            if (i4 != 0) {
                this.f364p.setTextAppearance(getContext(), i4);
            }
        }
        this.f363o.setText(this.f357i);
        this.f364p.setText(this.f358j);
        boolean isEmpty = TextUtils.isEmpty(this.f357i);
        boolean isEmpty2 = TextUtils.isEmpty(this.f358j);
        TextView textView = this.f364p;
        int i5 = 8;
        if (!isEmpty2) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        textView.setVisibility(i2);
        LinearLayout linearLayout2 = this.f362n;
        if (!isEmpty || !isEmpty2) {
            i5 = 0;
        }
        linearLayout2.setVisibility(i5);
        if (this.f362n.getParent() == null) {
            addView(this.f362n);
        }
    }

    public final void e() {
        removeAllViews();
        this.f361m = null;
        this.f352c = null;
        this.f353d = null;
        View view = this.f360l;
        if (view != null) {
            view.setOnClickListener((View.OnClickListener) null);
        }
    }

    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        if (this.f != null) {
            return this.f351a.b;
        }
        return getVisibility();
    }

    public int getContentHeight() {
        return this.f354e;
    }

    public CharSequence getSubtitle() {
        return this.f358j;
    }

    public CharSequence getTitle() {
        return this.f357i;
    }

    /* renamed from: h */
    public final void setVisibility(int i2) {
        if (i2 != getVisibility()) {
            Q q2 = this.f;
            if (q2 != null) {
                q2.b();
            }
            super.setVisibility(i2);
        }
    }

    public final Q i(int i2, long j2) {
        Q q2 = this.f;
        if (q2 != null) {
            q2.b();
        }
        C0047a aVar = this.f351a;
        if (i2 == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            Q a2 = K.a(this);
            a2.a(1.0f);
            a2.c(j2);
            aVar.f1214c.f = a2;
            aVar.b = i2;
            a2.d(aVar);
            return a2;
        }
        Q a3 = K.a(this);
        a3.a(0.0f);
        a3.c(j2);
        aVar.f1214c.f = a3;
        aVar.b = i2;
        a3.d(aVar);
        return a3;
    }

    public final void onConfigurationChanged(Configuration configuration) {
        int i2;
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes((AttributeSet) null, C0009a.f695a, R.attr.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(13, 0));
        obtainStyledAttributes.recycle();
        C0069l lVar = this.f353d;
        if (lVar != null) {
            Configuration configuration2 = lVar.b.getResources().getConfiguration();
            int i3 = configuration2.screenWidthDp;
            int i4 = configuration2.screenHeightDp;
            if (configuration2.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
                i2 = 5;
            } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
                i2 = 4;
            } else if (i3 >= 360) {
                i2 = 3;
            } else {
                i2 = 2;
            }
            lVar.f1290p = i2;
            n nVar = lVar.f1278c;
            if (nVar != null) {
                nVar.p(true);
            }
        }
    }

    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0069l lVar = this.f353d;
        if (lVar != null) {
            lVar.f();
            C0061h hVar = this.f353d.f1294t;
            if (hVar != null && hVar.b()) {
                hVar.f1097i.dismiss();
            }
        }
    }

    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f356h = false;
        }
        if (!this.f356h) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f356h = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f356h = false;
        return true;
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        boolean z3;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        boolean z4 = m1.f1298a;
        if (getLayoutDirection() == 1) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (z3) {
            i6 = (i4 - i2) - getPaddingRight();
        } else {
            i6 = getPaddingLeft();
        }
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
        View view = this.f359k;
        if (!(view == null || view.getVisibility() == 8)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f359k.getLayoutParams();
            if (z3) {
                i8 = marginLayoutParams.rightMargin;
            } else {
                i8 = marginLayoutParams.leftMargin;
            }
            if (z3) {
                i9 = marginLayoutParams.leftMargin;
            } else {
                i9 = marginLayoutParams.rightMargin;
            }
            if (z3) {
                i10 = i6 - i8;
            } else {
                i10 = i6 + i8;
            }
            int g2 = g(this.f359k, i10, paddingTop, paddingTop2, z3) + i10;
            if (z3) {
                i11 = g2 - i9;
            } else {
                i11 = g2 + i9;
            }
            i6 = i11;
        }
        LinearLayout linearLayout = this.f362n;
        if (!(linearLayout == null || this.f361m != null || linearLayout.getVisibility() == 8)) {
            i6 += g(this.f362n, i6, paddingTop, paddingTop2, z3);
        }
        View view2 = this.f361m;
        if (view2 != null) {
            g(view2, i6, paddingTop, paddingTop2, z3);
        }
        if (z3) {
            i7 = getPaddingLeft();
        } else {
            i7 = (i4 - i2) - getPaddingRight();
        }
        ActionMenuView actionMenuView = this.f352c;
        if (actionMenuView != null) {
            g(actionMenuView, i7, paddingTop, paddingTop2, !z3);
        }
    }

    public final void onMeasure(int i2, int i3) {
        int i4;
        boolean z2;
        int i5;
        int i6 = 1073741824;
        if (View.MeasureSpec.getMode(i2) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        } else if (View.MeasureSpec.getMode(i3) != 0) {
            int size = View.MeasureSpec.getSize(i2);
            int i7 = this.f354e;
            if (i7 <= 0) {
                i7 = View.MeasureSpec.getSize(i3);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i8 = i7 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i8, Integer.MIN_VALUE);
            View view = this.f359k;
            if (view != null) {
                int f2 = f(view, paddingLeft, makeMeasureSpec);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f359k.getLayoutParams();
                paddingLeft = f2 - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.f352c;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = f(this.f352c, paddingLeft, makeMeasureSpec);
            }
            LinearLayout linearLayout = this.f362n;
            if (linearLayout != null && this.f361m == null) {
                if (this.f367s) {
                    this.f362n.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f362n.getMeasuredWidth();
                    if (measuredWidth <= paddingLeft) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    if (z2) {
                        paddingLeft -= measuredWidth;
                    }
                    LinearLayout linearLayout2 = this.f362n;
                    if (z2) {
                        i5 = 0;
                    } else {
                        i5 = 8;
                    }
                    linearLayout2.setVisibility(i5);
                } else {
                    paddingLeft = f(linearLayout, paddingLeft, makeMeasureSpec);
                }
            }
            View view2 = this.f361m;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i9 = layoutParams.width;
                if (i9 != -2) {
                    i4 = 1073741824;
                } else {
                    i4 = Integer.MIN_VALUE;
                }
                if (i9 >= 0) {
                    paddingLeft = Math.min(i9, paddingLeft);
                }
                int i10 = layoutParams.height;
                if (i10 == -2) {
                    i6 = Integer.MIN_VALUE;
                }
                if (i10 >= 0) {
                    i8 = Math.min(i10, i8);
                }
                this.f361m.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i4), View.MeasureSpec.makeMeasureSpec(i8, i6));
            }
            if (this.f354e <= 0) {
                int childCount = getChildCount();
                int i11 = 0;
                for (int i12 = 0; i12 < childCount; i12++) {
                    int measuredHeight = getChildAt(i12).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i11) {
                        i11 = measuredHeight;
                    }
                }
                setMeasuredDimension(size, i11);
                return;
            }
            setMeasuredDimension(size, i7);
        } else {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f355g = false;
        }
        if (!this.f355g) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f355g = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f355g = false;
        return true;
    }

    public void setContentHeight(int i2) {
        this.f354e = i2;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f361m;
        if (view2 != null) {
            removeView(view2);
        }
        this.f361m = view;
        if (!(view == null || (linearLayout = this.f362n) == null)) {
            removeView(linearLayout);
            this.f362n = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f358j = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f357i = charSequence;
        d();
        K.i(this, charSequence);
    }

    public void setTitleOptional(boolean z2) {
        if (z2 != this.f367s) {
            requestLayout();
        }
        this.f367s = z2;
    }

    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
