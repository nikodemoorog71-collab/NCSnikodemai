package androidx.versionedparcelable;

import P.c;

public abstract class CustomVersionedParcelable implements c {
}
