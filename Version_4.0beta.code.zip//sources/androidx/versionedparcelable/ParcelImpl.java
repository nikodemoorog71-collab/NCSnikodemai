package androidx.versionedparcelable;

import D.m;
import P.b;
import P.c;
import android.os.Parcel;
import android.os.Parcelable;

public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new m(1);

    /* renamed from: a  reason: collision with root package name */
    public final c f693a;

    public ParcelImpl(Parcel parcel) {
        this.f693a = new b(parcel).g();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        new b(parcel).i(this.f693a);
    }
}
