package androidx.activity;

import T.c;
import Z.a;
import a0.b;
import a0.f;
import java.io.Serializable;

public final /* synthetic */ class s implements a, Serializable {

    /* renamed from: a  reason: collision with root package name */
    public transient s f307a;
    public final Object b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f308c = false;

    /* renamed from: d  reason: collision with root package name */
    public final int f309d = 0;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ int f310e;

    public s(int i2, Object obj) {
        this.f310e = i2;
        this.b = obj;
    }

    public final Object a() {
        switch (this.f310e) {
            case 0:
                ((t) this.b).c();
                return c.f244c;
            default:
                ((t) this.b).c();
                return c.f244c;
        }
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [java.lang.Object, a0.a] */
    public final a0.a b() {
        if (this.f308c) {
            f.f258a.getClass();
            return new Object();
        }
        f.f258a.getClass();
        return new b(t.class);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof s) {
            s sVar = (s) obj;
            sVar.getClass();
            if (this.f309d != sVar.f309d || !a0.c.a(this.b, sVar.b) || !b().equals(sVar.b())) {
                return false;
            }
            return true;
        } else if (!(obj instanceof s)) {
            return false;
        } else {
            s sVar2 = this.f307a;
            if (sVar2 == null) {
                f.f258a.getClass();
                this.f307a = this;
                sVar2 = this;
            }
            return obj.equals(sVar2);
        }
    }

    public final int hashCode() {
        b();
        return (((b().hashCode() * 31) + 986734966) * 31) + 1065238079;
    }

    public final String toString() {
        s sVar = this.f307a;
        if (sVar == null) {
            f.f258a.getClass();
            this.f307a = this;
            sVar = this;
        }
        if (sVar != this) {
            return sVar.toString();
        }
        return "function updateEnabledCallbacks (Kotlin reflection is not available)";
    }
}
