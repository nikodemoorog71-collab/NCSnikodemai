package androidx.activity;

import android.window.BackEvent;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final float f268a;
    public final float b;

    /* renamed from: c  reason: collision with root package name */
    public final float f269c;

    /* renamed from: d  reason: collision with root package name */
    public final int f270d;

    public b(BackEvent backEvent) {
        a aVar = a.f267a;
        float d2 = aVar.d(backEvent);
        float e2 = aVar.e(backEvent);
        float b2 = aVar.b(backEvent);
        int c2 = aVar.c(backEvent);
        this.f268a = d2;
        this.b = e2;
        this.f269c = b2;
        this.f270d = c2;
    }

    public final String toString() {
        return "BackEventCompat{touchX=" + this.f268a + ", touchY=" + this.b + ", progress=" + this.f269c + ", swipeEdge=" + this.f270d + '}';
    }
}
