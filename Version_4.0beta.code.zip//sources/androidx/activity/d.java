package androidx.activity;

import Z.a;
import e.C0021i;

public final /* synthetic */ class d implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0021i f272a;

    public /* synthetic */ d(C0021i iVar) {
        this.f272a = iVar;
    }

    public final Object a() {
        this.f272a.reportFullyDrawn();
        return null;
    }
}
