package androidx.activity;

import Z.a;
import a0.c;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

public final class p {

    /* renamed from: a  reason: collision with root package name */
    public static final p f300a = new Object();

    public final OnBackInvokedCallback a(a aVar) {
        c.e(aVar, "onBackInvoked");
        return new o(0, aVar);
    }

    public final void b(Object obj, int i2, Object obj2) {
        c.e(obj, "dispatcher");
        c.e(obj2, "callback");
        ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i2, (OnBackInvokedCallback) obj2);
    }

    public final void c(Object obj, Object obj2) {
        c.e(obj, "dispatcher");
        c.e(obj2, "callback");
        ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
    }
}
