package androidx.activity;

import C.j;
import T.c;
import Z.a;
import a0.b;
import a0.d;
import a0.f;
import androidx.fragment.app.k;
import androidx.lifecycle.B;
import androidx.lifecycle.D;
import androidx.lifecycle.E;
import androidx.lifecycle.F;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.ListIterator;

public final class n extends d implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f298a;
    public final /* synthetic */ Object b;

    public /* synthetic */ n(int i2, Object obj) {
        this.f298a = i2;
        this.b = obj;
    }

    public final Object a() {
        Object obj;
        switch (this.f298a) {
            case 0:
                ((t) this.b).a();
                return c.f244c;
            case 1:
                t tVar = (t) this.b;
                U.a aVar = tVar.b;
                ListIterator listIterator = aVar.listIterator(aVar.size());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        obj = listIterator.previous();
                        if (((k) obj).f592a) {
                        }
                    } else {
                        obj = null;
                    }
                }
                k kVar = (k) obj;
                tVar.f312c = null;
                return c.f244c;
            case 2:
                ((t) this.b).a();
                return c.f244c;
            default:
                k kVar2 = (k) this.b;
                ArrayList arrayList = new ArrayList();
                f.f258a.getClass();
                Class<D> cls = D.class;
                Class a2 = new b(cls).a();
                a0.c.c(a2, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>");
                arrayList.add(new I.d(a2));
                I.d[] dVarArr = (I.d[]) arrayList.toArray(new I.d[0]);
                I.d[] dVarArr2 = (I.d[]) Arrays.copyOf(dVarArr, dVarArr.length);
                a0.c.e(dVarArr2, "initializers");
                j b2 = kVar2.b();
                I.a aVar2 = I.a.b;
                a0.c.e(aVar2, "initialExtras");
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                linkedHashMap.putAll(aVar2.f73a);
                if (kVar2.getApplication() != null) {
                    linkedHashMap.put(F.f662a, kVar2.getApplication());
                }
                linkedHashMap.put(B.f653a, kVar2);
                linkedHashMap.put(B.b, kVar2);
                if (!(kVar2.getIntent() == null || kVar2.getIntent().getExtras() == null)) {
                    linkedHashMap.put(B.f654c, kVar2.getIntent().getExtras());
                }
                a0.c.e(b2, "store");
                LinkedHashMap linkedHashMap2 = (LinkedHashMap) b2.b;
                E e2 = (E) linkedHashMap2.get("androidx.lifecycle.internal.SavedStateHandlesVM");
                if (cls.isInstance(e2)) {
                    a0.c.c(e2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
                } else {
                    LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                    linkedHashMap3.putAll(linkedHashMap);
                    linkedHashMap3.put(F.b, "androidx.lifecycle.internal.SavedStateHandlesVM");
                    try {
                        D d2 = null;
                        for (I.d dVar : dVarArr2) {
                            if (dVar.f74a.equals(cls)) {
                                d2 = new D();
                            }
                        }
                        if (d2 != null) {
                            E e3 = (E) linkedHashMap2.put("androidx.lifecycle.internal.SavedStateHandlesVM", d2);
                            if (e3 != null) {
                                e3.a();
                            }
                            e2 = d2;
                        } else {
                            throw new IllegalArgumentException("No initializer set for given class ".concat(cls.getName()));
                        }
                    } catch (AbstractMethodError unused) {
                        throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
                    }
                }
                return (D) e2;
        }
    }
}
