package androidx.activity;

import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;

final class ImmLeaksCleaner implements o {

    /* renamed from: a  reason: collision with root package name */
    public static int f263a;

    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_DESTROY) {
            if (f263a == 0) {
                Class<InputMethodManager> cls = InputMethodManager.class;
                try {
                    f263a = 2;
                    cls.getDeclaredField("mServedView").setAccessible(true);
                    cls.getDeclaredField("mNextServedView").setAccessible(true);
                    cls.getDeclaredField("mH").setAccessible(true);
                    f263a = 1;
                } catch (NoSuchFieldException unused) {
                }
            }
            if (f263a == 1) {
                throw null;
            }
        }
    }
}
