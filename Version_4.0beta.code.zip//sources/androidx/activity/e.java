package androidx.activity;

import C.h;
import L.d;
import android.os.Bundle;
import android.util.Log;
import androidx.fragment.app.a;
import androidx.fragment.app.b;
import androidx.fragment.app.f;
import androidx.fragment.app.p;
import androidx.fragment.app.s;
import androidx.fragment.app.v;
import androidx.lifecycle.k;
import e.C0021i;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public final /* synthetic */ class e implements d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f273a;
    public final /* synthetic */ Object b;

    public /* synthetic */ e(int i2, Object obj) {
        this.f273a = i2;
        this.b = obj;
    }

    /* JADX WARNING: type inference failed for: r2v24, types: [android.os.Parcelable, androidx.fragment.app.q, java.lang.Object] */
    public final Bundle a() {
        ArrayList arrayList;
        b[] bVarArr;
        int size;
        switch (this.f273a) {
            case 0:
                Bundle bundle = new Bundle();
                g gVar = ((C0021i) this.b).f289j;
                gVar.getClass();
                HashMap hashMap = gVar.b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(hashMap.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(hashMap.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(gVar.f276c));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) gVar.f.clone());
                return bundle;
            case 1:
                C0021i iVar = (C0021i) this.b;
                for (Object obj : ((f) iVar.f862r.b).f584c.f602c.n()) {
                    if (obj != null) {
                        throw new ClassCastException();
                    }
                }
                iVar.f863s.d(k.ON_STOP);
                return new Bundle();
            default:
                p pVar = (p) this.b;
                pVar.getClass();
                Bundle bundle2 = new Bundle();
                Iterator it = pVar.b().iterator();
                while (it.hasNext()) {
                    ((v) it.next()).getClass();
                }
                Iterator it2 = pVar.b().iterator();
                if (!it2.hasNext()) {
                    pVar.e(true);
                    pVar.f620v = true;
                    pVar.f599A.getClass();
                    h hVar = pVar.f602c;
                    hVar.getClass();
                    HashMap hashMap2 = (HashMap) hVar.b;
                    ArrayList arrayList2 = new ArrayList(hashMap2.size());
                    for (Object obj2 : hashMap2.values()) {
                        if (obj2 != null) {
                            throw new ClassCastException();
                        }
                    }
                    h hVar2 = pVar.f602c;
                    hVar2.getClass();
                    ArrayList arrayList3 = new ArrayList(((HashMap) hVar2.f7c).values());
                    if (!arrayList3.isEmpty()) {
                        h hVar3 = pVar.f602c;
                        synchronized (((ArrayList) hVar3.f6a)) {
                            try {
                                if (((ArrayList) hVar3.f6a).isEmpty()) {
                                    arrayList = null;
                                } else {
                                    arrayList = new ArrayList(((ArrayList) hVar3.f6a).size());
                                    Iterator it3 = ((ArrayList) hVar3.f6a).iterator();
                                    if (it3.hasNext()) {
                                        if (it3.next() == null) {
                                            throw null;
                                        }
                                        throw new ClassCastException();
                                    }
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                        }
                        ArrayList arrayList4 = pVar.f603d;
                        int i2 = 0;
                        if (arrayList4 == null || (size = arrayList4.size()) <= 0) {
                            bVarArr = null;
                        } else {
                            bVarArr = new b[size];
                            for (int i3 = 0; i3 < size; i3++) {
                                bVarArr[i3] = new b((a) pVar.f603d.get(i3));
                                if (p.h(2)) {
                                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i3 + ": " + pVar.f603d.get(i3));
                                }
                            }
                        }
                        ? obj3 = new Object();
                        obj3.f628e = null;
                        ArrayList arrayList5 = new ArrayList();
                        obj3.f = arrayList5;
                        ArrayList arrayList6 = new ArrayList();
                        obj3.f629g = arrayList6;
                        obj3.f625a = arrayList2;
                        obj3.b = arrayList;
                        obj3.f626c = bVarArr;
                        obj3.f627d = pVar.f606h.get();
                        arrayList5.addAll(pVar.f607i.keySet());
                        arrayList6.addAll(pVar.f607i.values());
                        obj3.f630h = new ArrayList(pVar.f619u);
                        bundle2.putParcelable("state", obj3);
                        for (String str : pVar.f608j.keySet()) {
                            bundle2.putBundle("result_" + str, (Bundle) pVar.f608j.get(str));
                        }
                        int size2 = arrayList3.size();
                        while (i2 < size2) {
                            Object obj4 = arrayList3.get(i2);
                            i2++;
                            s sVar = (s) obj4;
                            Bundle bundle3 = new Bundle();
                            bundle3.putParcelable("state", sVar);
                            bundle2.putBundle("fragment_" + sVar.b, bundle3);
                        }
                    } else if (p.h(2)) {
                        Log.v("FragmentManager", "saveAllState: no fragments!");
                    }
                    return bundle2;
                }
                ((v) it2.next()).a();
                throw null;
        }
    }
}
