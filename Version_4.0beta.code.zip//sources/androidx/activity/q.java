package androidx.activity;

import Z.a;
import Z.l;
import a0.c;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

public final class q implements OnBackAnimationCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l f301a;
    public final /* synthetic */ l b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ a f302c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ a f303d;

    public q(l lVar, l lVar2, a aVar, a aVar2) {
        this.f301a = lVar;
        this.b = lVar2;
        this.f302c = aVar;
        this.f303d = aVar2;
    }

    public final void onBackCancelled() {
        this.f303d.a();
    }

    public final void onBackInvoked() {
        this.f302c.a();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        c.e(backEvent, "backEvent");
        this.b.b(new b(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        c.e(backEvent, "backEvent");
        this.f301a.b(new b(backEvent));
    }
}
