package androidx.activity;

import Z.a;
import a0.c;
import android.window.OnBackInvokedCallback;
import e.C0012C;

public final /* synthetic */ class o implements OnBackInvokedCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f299a;
    public final /* synthetic */ Object b;

    public /* synthetic */ o(int i2, Object obj) {
        this.f299a = i2;
        this.b = obj;
    }

    public final void onBackInvoked() {
        switch (this.f299a) {
            case 0:
                a aVar = (a) this.b;
                c.e(aVar, "$onBackInvoked");
                aVar.a();
                return;
            case 1:
                ((C0012C) this.b).C();
                return;
            default:
                ((Runnable) this.b).run();
                return;
        }
    }
}
