package androidx.activity.result;

import D.g;
import androidx.fragment.app.j;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final j f306a;
    public final g b;

    public b(j jVar, g gVar) {
        this.f306a = jVar;
        this.b = gVar;
    }
}
