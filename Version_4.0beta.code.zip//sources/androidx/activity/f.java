package androidx.activity;

import C.h;
import K.d;
import L.e;
import a.b;
import a0.c;
import android.os.Bundle;
import android.util.Log;
import androidx.fragment.app.a;
import androidx.fragment.app.j;
import androidx.fragment.app.k;
import androidx.fragment.app.n;
import androidx.fragment.app.p;
import androidx.fragment.app.q;
import androidx.fragment.app.r;
import androidx.fragment.app.t;
import androidx.fragment.app.u;
import androidx.lifecycle.l;
import androidx.lifecycle.s;
import e.C0021i;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public final /* synthetic */ class f implements b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f274a;
    public final /* synthetic */ C0021i b;

    public /* synthetic */ f(C0021i iVar, int i2) {
        this.f274a = i2;
        this.b = iVar;
    }

    /* JADX WARNING: type inference failed for: r11v1, types: [androidx.fragment.app.t, java.lang.Object] */
    public final void a() {
        int i2;
        Bundle bundle;
        Bundle bundle2;
        switch (this.f274a) {
            case 0:
                C0021i iVar = this.b;
                Bundle c2 = ((e) iVar.f285e.f118c).c("android:support:activity-result");
                if (c2 != null) {
                    g gVar = iVar.f289j;
                    gVar.getClass();
                    ArrayList<Integer> integerArrayList = c2.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
                    ArrayList<String> stringArrayList = c2.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
                    if (stringArrayList != null && integerArrayList != null) {
                        gVar.f276c = c2.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                        Bundle bundle3 = c2.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                        Bundle bundle4 = gVar.f;
                        bundle4.putAll(bundle3);
                        for (int i3 = 0; i3 < stringArrayList.size(); i3++) {
                            String str = stringArrayList.get(i3);
                            HashMap hashMap = gVar.b;
                            boolean containsKey = hashMap.containsKey(str);
                            HashMap hashMap2 = gVar.f275a;
                            if (containsKey) {
                                Integer num = (Integer) hashMap.remove(str);
                                if (!bundle4.containsKey(str)) {
                                    hashMap2.remove(num);
                                }
                            }
                            Integer num2 = integerArrayList.get(i3);
                            num2.intValue();
                            String str2 = stringArrayList.get(i3);
                            hashMap2.put(num2, str2);
                            hashMap.put(str2, num2);
                        }
                        return;
                    }
                    return;
                }
                return;
            default:
                androidx.fragment.app.f fVar = (androidx.fragment.app.f) this.b.f862r.b;
                p pVar = fVar.f584c;
                if (pVar.f616r == null) {
                    pVar.f616r = fVar;
                    pVar.f617s = fVar;
                    pVar.f609k.add(fVar);
                    C0021i iVar2 = fVar.f585d;
                    t g2 = iVar2.g();
                    pVar.f = g2;
                    k kVar = pVar.f605g;
                    g2.getClass();
                    c.e(kVar, "onBackPressedCallback");
                    s c3 = fVar.c();
                    if (c3.f679c != l.f672a) {
                        kVar.b.add(new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(g2, c3, kVar));
                        g2.c();
                        kVar.f593c = new s(0, g2);
                    }
                    pVar.f599A = (r) new h(iVar2.b(), r.f).h(r.class);
                    h hVar = pVar.f602c;
                    hVar.getClass();
                    androidx.fragment.app.f fVar2 = pVar.f616r;
                    if (fVar2 != null) {
                        e a2 = fVar2.a();
                        a2.e("android:support:fragments", new e(2, pVar));
                        Bundle c4 = a2.c("android:support:fragments");
                        if (c4 != null) {
                            for (String next : c4.keySet()) {
                                if (next.startsWith("result_") && (bundle2 = c4.getBundle(next)) != null) {
                                    bundle2.setClassLoader(pVar.f616r.f583a.getClassLoader());
                                    pVar.f608j.put(next.substring(7), bundle2);
                                }
                            }
                            ArrayList arrayList = new ArrayList();
                            for (String next2 : c4.keySet()) {
                                if (next2.startsWith("fragment_") && (bundle = c4.getBundle(next2)) != null) {
                                    bundle.setClassLoader(pVar.f616r.f583a.getClassLoader());
                                    arrayList.add((androidx.fragment.app.s) bundle.getParcelable("state"));
                                }
                            }
                            HashMap hashMap3 = (HashMap) hVar.f7c;
                            hashMap3.clear();
                            int size = arrayList.size();
                            int i4 = 0;
                            while (i4 < size) {
                                Object obj = arrayList.get(i4);
                                i4++;
                                androidx.fragment.app.s sVar = (androidx.fragment.app.s) obj;
                                hashMap3.put(sVar.b, sVar);
                            }
                            q qVar = (q) c4.getParcelable("state");
                            if (qVar != null) {
                                HashMap hashMap4 = (HashMap) hVar.b;
                                hashMap4.clear();
                                ArrayList arrayList2 = qVar.f625a;
                                int size2 = arrayList2.size();
                                int i5 = 0;
                                while (i5 < size2) {
                                    Object obj2 = arrayList2.get(i5);
                                    i5++;
                                    androidx.fragment.app.s sVar2 = (androidx.fragment.app.s) hashMap3.remove((String) obj2);
                                    if (sVar2 != null) {
                                        if (pVar.f599A.f631c.get(sVar2.b) == null) {
                                            ClassLoader classLoader = pVar.f616r.f583a.getClassLoader();
                                            pVar.f618t.a(sVar2.f634a);
                                            Bundle bundle5 = sVar2.f641j;
                                            if (bundle5 != null) {
                                                bundle5.setClassLoader(classLoader);
                                            }
                                            throw null;
                                        }
                                        throw new ClassCastException();
                                    }
                                }
                                r rVar = pVar.f599A;
                                rVar.getClass();
                                Iterator it = new ArrayList(rVar.f631c.values()).iterator();
                                if (!it.hasNext()) {
                                    ArrayList arrayList3 = qVar.b;
                                    ((ArrayList) hVar.f6a).clear();
                                    if (arrayList3 != null) {
                                        Iterator it2 = arrayList3.iterator();
                                        if (it2.hasNext()) {
                                            String str3 = (String) it2.next();
                                            d.a(hashMap4.get(str3));
                                            throw new IllegalStateException("No instantiated fragment for (" + str3 + ")");
                                        }
                                    }
                                    if (qVar.f626c != null) {
                                        pVar.f603d = new ArrayList(qVar.f626c.length);
                                        int i6 = 0;
                                        while (true) {
                                            androidx.fragment.app.b[] bVarArr = qVar.f626c;
                                            if (i6 < bVarArr.length) {
                                                androidx.fragment.app.b bVar = bVarArr[i6];
                                                bVar.getClass();
                                                a aVar = new a(pVar);
                                                int i7 = 0;
                                                int i8 = 0;
                                                while (true) {
                                                    int[] iArr = bVar.f569a;
                                                    boolean z2 = true;
                                                    if (i7 < iArr.length) {
                                                        ? obj3 = new Object();
                                                        int i9 = i7 + 1;
                                                        obj3.f645a = iArr[i7];
                                                        if (p.h(2)) {
                                                            Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i8 + " base fragment #" + iArr[i9]);
                                                        }
                                                        obj3.f649g = l.values()[bVar.f570c[i8]];
                                                        obj3.f650h = l.values()[bVar.f571d[i8]];
                                                        int i10 = i7 + 2;
                                                        if (iArr[i9] == 0) {
                                                            z2 = false;
                                                        }
                                                        obj3.b = z2;
                                                        int i11 = iArr[i10];
                                                        obj3.f646c = i11;
                                                        int i12 = iArr[i7 + 3];
                                                        obj3.f647d = i12;
                                                        int i13 = i7 + 5;
                                                        int i14 = iArr[i7 + 4];
                                                        obj3.f648e = i14;
                                                        i7 += 6;
                                                        int i15 = iArr[i13];
                                                        obj3.f = i15;
                                                        aVar.b = i11;
                                                        aVar.f555c = i12;
                                                        aVar.f556d = i14;
                                                        aVar.f557e = i15;
                                                        aVar.f554a.add(obj3);
                                                        obj3.f646c = aVar.b;
                                                        obj3.f647d = aVar.f555c;
                                                        obj3.f648e = aVar.f556d;
                                                        obj3.f = aVar.f557e;
                                                        i8++;
                                                    } else {
                                                        aVar.f = bVar.f572e;
                                                        aVar.f559h = bVar.f;
                                                        aVar.f558g = true;
                                                        aVar.f560i = bVar.f574h;
                                                        aVar.f561j = bVar.f575i;
                                                        aVar.f562k = bVar.f576j;
                                                        aVar.f563l = bVar.f577k;
                                                        aVar.f564m = bVar.f578l;
                                                        aVar.f565n = bVar.f579m;
                                                        aVar.f566o = bVar.f580n;
                                                        aVar.f568q = bVar.f573g;
                                                        int i16 = 0;
                                                        while (true) {
                                                            ArrayList arrayList4 = bVar.b;
                                                            if (i16 < arrayList4.size()) {
                                                                String str4 = (String) arrayList4.get(i16);
                                                                if (str4 != null) {
                                                                    d.a(((HashMap) hVar.b).get(str4));
                                                                    ((t) aVar.f554a.get(i16)).getClass();
                                                                }
                                                                i16++;
                                                            } else {
                                                                aVar.a(1);
                                                                if (p.h(2)) {
                                                                    Log.v("FragmentManager", "restoreAllState: back stack #" + i6 + " (index " + aVar.f568q + "): " + aVar);
                                                                    PrintWriter printWriter = new PrintWriter(new u());
                                                                    aVar.b("  ", printWriter, false);
                                                                    printWriter.close();
                                                                }
                                                                pVar.f603d.add(aVar);
                                                                i6++;
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                                i2 = 0;
                                            }
                                        }
                                    } else {
                                        i2 = 0;
                                        pVar.f603d = null;
                                    }
                                    pVar.f606h.set(qVar.f627d);
                                    String str5 = qVar.f628e;
                                    if (str5 != null) {
                                        d.a(((HashMap) hVar.b).get(str5));
                                    }
                                    ArrayList arrayList5 = qVar.f;
                                    if (arrayList5 != null) {
                                        while (i2 < arrayList5.size()) {
                                            pVar.f607i.put((String) arrayList5.get(i2), (androidx.fragment.app.c) qVar.f629g.get(i2));
                                            i2++;
                                        }
                                    }
                                    pVar.f619u = new ArrayDeque(qVar.f630h);
                                } else {
                                    it.next().getClass();
                                    throw new ClassCastException();
                                }
                            }
                        }
                    }
                    androidx.fragment.app.f fVar3 = pVar.f616r;
                    if (fVar3 != null) {
                        C0021i iVar3 = fVar3.f585d;
                        n nVar = new n(2);
                        j jVar = new j(pVar, 1);
                        g gVar2 = iVar3.f289j;
                        gVar2.b("FragmentManager:StartActivityForResult", nVar, jVar);
                        gVar2.b("FragmentManager:StartIntentSenderForResult", new n(0), new j(pVar, 2));
                        gVar2.b("FragmentManager:RequestPermissions", new n(1), new j(pVar, 0));
                    }
                    androidx.fragment.app.f fVar4 = pVar.f616r;
                    if (fVar4 != null) {
                        fVar4.f585d.f290k.add(pVar.f610l);
                    }
                    androidx.fragment.app.f fVar5 = pVar.f616r;
                    if (fVar5 != null) {
                        fVar5.f585d.f291l.add(pVar.f611m);
                    }
                    androidx.fragment.app.f fVar6 = pVar.f616r;
                    if (fVar6 != null) {
                        fVar6.f585d.f293n.add(pVar.f612n);
                    }
                    androidx.fragment.app.f fVar7 = pVar.f616r;
                    if (fVar7 != null) {
                        fVar7.f585d.f294o.add(pVar.f613o);
                    }
                    androidx.fragment.app.f fVar8 = pVar.f616r;
                    if (fVar8 != null) {
                        G.a aVar2 = fVar8.f585d.f283c;
                        ((CopyOnWriteArrayList) aVar2.b).add(pVar.f614p);
                        ((Runnable) aVar2.f57a).run();
                        return;
                    }
                    return;
                }
                throw new IllegalStateException("Already attached");
        }
    }
}
