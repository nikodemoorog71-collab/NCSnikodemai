package androidx.activity;

import android.view.View;
import android.view.Window;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import e.C0021i;

class ComponentActivity$2 implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0021i f259a;

    public ComponentActivity$2(C0021i iVar) {
        this.f259a = iVar;
    }

    public final void b(q qVar, k kVar) {
        View view;
        if (kVar == k.ON_STOP) {
            Window window = this.f259a.getWindow();
            if (window != null) {
                view = window.peekDecorView();
            } else {
                view = null;
            }
            if (view != null) {
                view.cancelPendingInputEvents();
            }
        }
    }
}
