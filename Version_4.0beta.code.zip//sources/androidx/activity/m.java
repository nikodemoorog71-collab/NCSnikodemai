package androidx.activity;

import T.c;
import U.a;
import Z.l;
import a0.d;
import androidx.fragment.app.k;
import java.util.ListIterator;

public final class m extends d implements l {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f297a;
    public final /* synthetic */ t b;

    public /* synthetic */ m(t tVar, int i2) {
        this.f297a = i2;
        this.b = tVar;
    }

    public final Object b(Object obj) {
        Object obj2;
        Object obj3;
        switch (this.f297a) {
            case 0:
                b bVar = (b) obj;
                t tVar = this.b;
                a aVar = tVar.b;
                aVar.getClass();
                ListIterator listIterator = aVar.listIterator(aVar.f248c);
                while (true) {
                    if (listIterator.hasPrevious()) {
                        obj2 = listIterator.previous();
                        if (((k) obj2).f592a) {
                        }
                    } else {
                        obj2 = null;
                    }
                }
                tVar.f312c = (k) obj2;
                return c.f244c;
            default:
                b bVar2 = (b) obj;
                a aVar2 = this.b.b;
                aVar2.getClass();
                ListIterator listIterator2 = aVar2.listIterator(aVar2.f248c);
                while (true) {
                    if (listIterator2.hasPrevious()) {
                        obj3 = listIterator2.previous();
                        if (((k) obj3).f592a) {
                        }
                    } else {
                        obj3 = null;
                    }
                }
                k kVar = (k) obj3;
                return c.f244c;
        }
    }
}
