package androidx.activity;

import a0.c;
import android.os.Build;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;

class ComponentActivity$6 implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k f262a;

    public ComponentActivity$6(k kVar) {
        this.f262a = kVar;
    }

    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_CREATE && Build.VERSION.SDK_INT >= 33) {
            t tVar = this.f262a.f286g;
            OnBackInvokedDispatcher a2 = h.a((k) qVar);
            tVar.getClass();
            c.e(a2, "invoker");
            tVar.f314e = a2;
            tVar.b(tVar.f315g);
        }
    }
}
