package androidx.activity;

import L.f;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import e.C0021i;
import java.util.concurrent.Executor;

public final class j implements Executor, ViewTreeObserver.OnDrawListener, Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final long f280a = (SystemClock.uptimeMillis() + 10000);
    public Runnable b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f281c = false;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0021i f282d;

    public j(C0021i iVar) {
        this.f282d = iVar;
    }

    public final void execute(Runnable runnable) {
        this.b = runnable;
        View decorView = this.f282d.getWindow().getDecorView();
        if (!this.f281c) {
            decorView.postOnAnimation(new c(1, this));
        } else if (Looper.myLooper() == Looper.getMainLooper()) {
            decorView.invalidate();
        } else {
            decorView.postInvalidate();
        }
    }

    public final void onDraw() {
        boolean z2;
        Runnable runnable = this.b;
        if (runnable != null) {
            runnable.run();
            this.b = null;
            f fVar = this.f282d.f288i;
            synchronized (fVar.f117a) {
                z2 = fVar.b;
            }
            if (z2) {
                this.f281c = false;
                this.f282d.getWindow().getDecorView().post(this);
            }
        } else if (SystemClock.uptimeMillis() > this.f280a) {
            this.f281c = false;
            this.f282d.getWindow().getDecorView().post(this);
        }
    }

    public final void run() {
        this.f282d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
}
