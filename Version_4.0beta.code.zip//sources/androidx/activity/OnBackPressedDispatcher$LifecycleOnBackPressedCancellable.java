package androidx.activity;

import G.a;
import a0.c;
import androidx.fragment.app.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;

final class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements o {

    /* renamed from: a  reason: collision with root package name */
    public final s f264a;
    public final k b;

    /* renamed from: c  reason: collision with root package name */
    public a f265c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ t f266d;

    public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(t tVar, s sVar, k kVar) {
        c.e(kVar, "onBackPressedCallback");
        this.f266d = tVar;
        this.f264a = sVar;
        this.b = kVar;
        sVar.a(this);
    }

    public final void b(q qVar, androidx.lifecycle.k kVar) {
        if (kVar == androidx.lifecycle.k.ON_START) {
            t tVar = this.f266d;
            tVar.getClass();
            k kVar2 = this.b;
            c.e(kVar2, "onBackPressedCallback");
            tVar.b.addLast(kVar2);
            a aVar = new a(tVar, kVar2);
            kVar2.b.add(aVar);
            tVar.c();
            kVar2.f593c = new s(1, tVar);
            this.f265c = aVar;
        } else if (kVar == androidx.lifecycle.k.ON_STOP) {
            a aVar2 = this.f265c;
            if (aVar2 != null) {
                aVar2.a();
            }
        } else if (kVar == androidx.lifecycle.k.ON_DESTROY) {
            this.f264a.f(this);
            this.b.b.remove(this);
            a aVar3 = this.f265c;
            if (aVar3 != null) {
                aVar3.a();
            }
            this.f265c = null;
        }
    }
}
