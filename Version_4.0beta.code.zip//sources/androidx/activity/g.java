package androidx.activity;

import F.d;
import android.content.Intent;
import android.os.Bundle;
import androidx.activity.result.a;
import androidx.activity.result.b;
import androidx.fragment.app.j;
import java.util.ArrayList;
import java.util.HashMap;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final HashMap f275a = new HashMap();
    public final HashMap b = new HashMap();

    /* renamed from: c  reason: collision with root package name */
    public ArrayList f276c;

    /* renamed from: d  reason: collision with root package name */
    public final transient HashMap f277d;

    /* renamed from: e  reason: collision with root package name */
    public final HashMap f278e;
    public final Bundle f;

    public g() {
        new HashMap();
        this.f276c = new ArrayList();
        this.f277d = new HashMap();
        this.f278e = new HashMap();
        this.f = new Bundle();
    }

    public final boolean a(int i2, int i3, Intent intent) {
        String str = (String) this.f275a.get(Integer.valueOf(i2));
        if (str == null) {
            return false;
        }
        b bVar = (b) this.f277d.get(str);
        if (bVar != null) {
            j jVar = bVar.f306a;
            if (this.f276c.contains(str)) {
                jVar.a(bVar.b.J(i3, intent));
                this.f276c.remove(str);
                return true;
            }
        }
        this.f278e.remove(str);
        this.f.putParcelable(str, new a(i3, intent));
        return true;
    }

    public final d b(String str, D.g gVar, j jVar) {
        int i2;
        HashMap hashMap;
        HashMap hashMap2 = this.b;
        if (((Integer) hashMap2.get(str)) == null) {
            int b2 = b0.a.f694a.b();
            while (true) {
                i2 = b2 + 65536;
                hashMap = this.f275a;
                if (!hashMap.containsKey(Integer.valueOf(i2))) {
                    break;
                }
                b2 = b0.a.f694a.b();
            }
            hashMap.put(Integer.valueOf(i2), str);
            hashMap2.put(str, Integer.valueOf(i2));
        }
        this.f277d.put(str, new b(jVar, gVar));
        HashMap hashMap3 = this.f278e;
        if (hashMap3.containsKey(str)) {
            Object obj = hashMap3.get(str);
            hashMap3.remove(str);
            jVar.a(obj);
        }
        Bundle bundle = this.f;
        a aVar = (a) bundle.getParcelable(str);
        if (aVar != null) {
            bundle.remove(str);
            jVar.a(gVar.J(aVar.f305a, aVar.b));
        }
        return new d(this, str);
    }
}
