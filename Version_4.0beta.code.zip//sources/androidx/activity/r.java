package androidx.activity;

import Z.a;
import Z.l;
import a0.c;
import android.window.OnBackInvokedCallback;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public static final r f304a = new Object();

    public final OnBackInvokedCallback a(l lVar, l lVar2, a aVar, a aVar2) {
        c.e(lVar, "onBackStarted");
        c.e(lVar2, "onBackProgressed");
        c.e(aVar, "onBackInvoked");
        c.e(aVar2, "onBackCancelled");
        return new q(lVar, lVar2, aVar, aVar2);
    }
}
