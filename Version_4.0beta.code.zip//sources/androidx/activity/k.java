package androidx.activity;

import C.j;
import G.a;
import L.d;
import L.e;
import L.f;
import L.g;
import a.C0000a;
import a.b;
import a0.c;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import androidx.fragment.app.p;
import androidx.lifecycle.A;
import androidx.lifecycle.C;
import androidx.lifecycle.G;
import androidx.lifecycle.SavedStateHandleAttacher;
import androidx.lifecycle.l;
import androidx.lifecycle.s;
import androidx.lifecycle.y;
import e.C0021i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import k.C0100b;
import k.C0104f;
import nikodemai.firmware.ncs.R;
import o.h;
import o.i;
import o.r;
import x.C0156a;

public abstract class k extends h implements G, g {
    public final C0000a b = new C0000a();

    /* renamed from: c  reason: collision with root package name */
    public final a f283c;

    /* renamed from: d  reason: collision with root package name */
    public final s f284d;

    /* renamed from: e  reason: collision with root package name */
    public final f f285e;
    public j f;

    /* renamed from: g  reason: collision with root package name */
    public t f286g;

    /* renamed from: h  reason: collision with root package name */
    public final j f287h;

    /* renamed from: i  reason: collision with root package name */
    public final f f288i;

    /* renamed from: j  reason: collision with root package name */
    public final g f289j;

    /* renamed from: k  reason: collision with root package name */
    public final CopyOnWriteArrayList f290k;

    /* renamed from: l  reason: collision with root package name */
    public final CopyOnWriteArrayList f291l;

    /* renamed from: m  reason: collision with root package name */
    public final CopyOnWriteArrayList f292m;

    /* renamed from: n  reason: collision with root package name */
    public final CopyOnWriteArrayList f293n;

    /* renamed from: o  reason: collision with root package name */
    public final CopyOnWriteArrayList f294o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f295p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f296q;

    public k() {
        C0021i iVar = (C0021i) this;
        this.f283c = new a((Runnable) new c(0, iVar));
        s sVar = new s(this);
        this.f284d = sVar;
        f fVar = new f(this);
        this.f285e = fVar;
        d dVar = null;
        this.f286g = null;
        j jVar = new j(iVar);
        this.f287h = jVar;
        this.f288i = new f(jVar, new d(iVar));
        new AtomicInteger();
        this.f289j = new g();
        this.f290k = new CopyOnWriteArrayList();
        this.f291l = new CopyOnWriteArrayList();
        this.f292m = new CopyOnWriteArrayList();
        this.f293n = new CopyOnWriteArrayList();
        this.f294o = new CopyOnWriteArrayList();
        this.f295p = false;
        this.f296q = false;
        sVar.a(new ComponentActivity$2(iVar));
        sVar.a(new ComponentActivity$3(iVar));
        sVar.a(new ComponentActivity$4(iVar));
        fVar.a();
        l lVar = sVar.f679c;
        if (lVar == l.b || lVar == l.f673c) {
            e eVar = (e) fVar.f118c;
            eVar.getClass();
            Iterator it = ((C0104f) eVar.f115d).iterator();
            while (true) {
                C0100b bVar = (C0100b) it;
                if (!bVar.hasNext()) {
                    break;
                }
                Map.Entry entry = (Map.Entry) bVar.next();
                c.d(entry, "components");
                d dVar2 = (d) entry.getValue();
                if (c.a((String) entry.getKey(), "androidx.lifecycle.internal.SavedStateHandlesProvider")) {
                    dVar = dVar2;
                    break;
                }
            }
            if (dVar == null) {
                C c2 = new C((e) this.f285e.f118c, this);
                ((e) this.f285e.f118c).e("androidx.lifecycle.internal.SavedStateHandlesProvider", c2);
                this.f284d.a(new SavedStateHandleAttacher(c2));
            }
            ((e) this.f285e.f118c).e("android:support:activity-result", new e(0, iVar));
            f(new f(iVar, 0));
            return;
        }
        throw new IllegalArgumentException("Failed requirement.");
    }

    public final e a() {
        return (e) this.f285e.f118c;
    }

    public final j b() {
        if (getApplication() != null) {
            if (this.f == null) {
                i iVar = (i) getLastNonConfigurationInstance();
                if (iVar != null) {
                    this.f = iVar.f279a;
                }
                if (this.f == null) {
                    this.f = new j();
                }
            }
            return this.f;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public final s c() {
        return this.f284d;
    }

    public final void f(b bVar) {
        C0000a aVar = this.b;
        aVar.getClass();
        if (aVar.b != null) {
            bVar.a();
        }
        aVar.f255a.add(bVar);
    }

    public final t g() {
        if (this.f286g == null) {
            this.f286g = new t(new D.b(1, (Object) this));
            this.f284d.a(new ComponentActivity$6(this));
        }
        return this.f286g;
    }

    public final void h() {
        View decorView = getWindow().getDecorView();
        c.e(decorView, "<this>");
        decorView.setTag(R.id.view_tree_lifecycle_owner, this);
        View decorView2 = getWindow().getDecorView();
        c.e(decorView2, "<this>");
        decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        View decorView3 = getWindow().getDecorView();
        c.e(decorView3, "<this>");
        decorView3.setTag(R.id.view_tree_saved_state_registry_owner, this);
        View decorView4 = getWindow().getDecorView();
        c.e(decorView4, "<this>");
        decorView4.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView5 = getWindow().getDecorView();
        c.e(decorView5, "<this>");
        decorView5.setTag(R.id.report_drawn, this);
    }

    public void onActivityResult(int i2, int i3, Intent intent) {
        if (!this.f289j.a(i2, i3, intent)) {
            super.onActivityResult(i2, i3, intent);
        }
    }

    public final void onBackPressed() {
        g().a();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.f290k.iterator();
        while (it.hasNext()) {
            ((C0156a) it.next()).a(configuration);
        }
    }

    public void onCreate(Bundle bundle) {
        this.f285e.b(bundle);
        C0000a aVar = this.b;
        aVar.getClass();
        aVar.b = this;
        Iterator it = aVar.f255a.iterator();
        while (it.hasNext()) {
            ((b) it.next()).a();
        }
        super.onCreate(bundle);
        int i2 = A.b;
        y.b(this);
    }

    public final boolean onCreatePanelMenu(int i2, Menu menu) {
        if (i2 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i2, menu);
        getMenuInflater();
        this.f283c.d();
        return true;
    }

    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 0) {
            this.f283c.f();
        }
        return false;
    }

    public final void onMultiWindowModeChanged(boolean z2) {
        if (!this.f295p) {
            Iterator it = this.f293n.iterator();
            while (it.hasNext()) {
                ((C0156a) it.next()).a(new i(z2));
            }
        }
    }

    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.f292m.iterator();
        while (it.hasNext()) {
            ((C0156a) it.next()).a(intent);
        }
    }

    public void onPanelClosed(int i2, Menu menu) {
        Iterator it = ((CopyOnWriteArrayList) this.f283c.b).iterator();
        while (it.hasNext()) {
            p pVar = ((androidx.fragment.app.l) it.next()).f595a;
            if (pVar.f615q >= 1) {
                for (Object obj : pVar.f602c.n()) {
                    if (obj != null) {
                        throw new ClassCastException();
                    }
                }
                continue;
            }
        }
        super.onPanelClosed(i2, menu);
    }

    public final void onPictureInPictureModeChanged(boolean z2) {
        if (!this.f296q) {
            Iterator it = this.f294o.iterator();
            while (it.hasNext()) {
                ((C0156a) it.next()).a(new r(z2));
            }
        }
    }

    public final boolean onPreparePanel(int i2, View view, Menu menu) {
        if (i2 != 0) {
            return true;
        }
        super.onPreparePanel(i2, view, menu);
        this.f283c.h();
        return true;
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (!this.f289j.a(i2, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            super.onRequestPermissionsResult(i2, strArr, iArr);
        }
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [java.lang.Object, androidx.activity.i] */
    public final Object onRetainNonConfigurationInstance() {
        i iVar;
        j jVar = this.f;
        if (jVar == null && (iVar = (i) getLastNonConfigurationInstance()) != null) {
            jVar = iVar.f279a;
        }
        if (jVar == null) {
            return null;
        }
        ? obj = new Object();
        obj.f279a = jVar;
        return obj;
    }

    public final void onSaveInstanceState(Bundle bundle) {
        s sVar = this.f284d;
        if (sVar != null) {
            l lVar = l.f673c;
            sVar.c("setCurrentState");
            sVar.e(lVar);
        }
        super.onSaveInstanceState(bundle);
        this.f285e.c(bundle);
    }

    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        Iterator it = this.f291l.iterator();
        while (it.hasNext()) {
            ((C0156a) it.next()).a(Integer.valueOf(i2));
        }
    }

    public final void reportFullyDrawn() {
        try {
            if (D.g.A()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            f fVar = this.f288i;
            synchronized (fVar.f117a) {
                fVar.b = true;
                ArrayList arrayList = (ArrayList) fVar.f118c;
                int size = arrayList.size();
                int i2 = 0;
                while (i2 < size) {
                    Object obj = arrayList.get(i2);
                    i2++;
                    ((Z.a) obj).a();
                }
                ((ArrayList) fVar.f118c).clear();
            }
            Trace.endSection();
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    public void setContentView(View view) {
        h();
        View decorView = getWindow().getDecorView();
        j jVar = this.f287h;
        if (!jVar.f281c) {
            jVar.f281c = true;
            decorView.getViewTreeObserver().addOnDrawListener(jVar);
        }
        super.setContentView(view);
    }

    /* JADX INFO: finally extract failed */
    public final void onMultiWindowModeChanged(boolean z2, Configuration configuration) {
        this.f295p = true;
        try {
            super.onMultiWindowModeChanged(z2, configuration);
            this.f295p = false;
            Iterator it = this.f293n.iterator();
            while (it.hasNext()) {
                c.e(configuration, "newConfig");
                ((C0156a) it.next()).a(new i(z2));
            }
        } catch (Throwable th) {
            this.f295p = false;
            throw th;
        }
    }

    /* JADX INFO: finally extract failed */
    public final void onPictureInPictureModeChanged(boolean z2, Configuration configuration) {
        this.f296q = true;
        try {
            super.onPictureInPictureModeChanged(z2, configuration);
            this.f296q = false;
            Iterator it = this.f294o.iterator();
            while (it.hasNext()) {
                c.e(configuration, "newConfig");
                ((C0156a) it.next()).a(new r(z2));
            }
        } catch (Throwable th) {
            this.f296q = false;
            throw th;
        }
    }
}
