package androidx.activity;

import C.j;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import e.C0021i;

class ComponentActivity$4 implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0021i f261a;

    public ComponentActivity$4(C0021i iVar) {
        this.f261a = iVar;
    }

    public final void b(q qVar, k kVar) {
        C0021i iVar = this.f261a;
        if (iVar.f == null) {
            i iVar2 = (i) iVar.getLastNonConfigurationInstance();
            if (iVar2 != null) {
                iVar.f = iVar2.f279a;
            }
            if (iVar.f == null) {
                iVar.f = new j();
            }
        }
        iVar.f284d.f(this);
    }
}
