package androidx.activity;

import U.a;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.fragment.app.k;
import androidx.fragment.app.p;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public final Runnable f311a;
    public final a b = new a();

    /* renamed from: c  reason: collision with root package name */
    public k f312c;

    /* renamed from: d  reason: collision with root package name */
    public final OnBackInvokedCallback f313d;

    /* renamed from: e  reason: collision with root package name */
    public OnBackInvokedDispatcher f314e;
    public boolean f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f315g;

    public t(Runnable runnable) {
        OnBackInvokedCallback onBackInvokedCallback;
        this.f311a = runnable;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 33) {
            if (i2 >= 34) {
                onBackInvokedCallback = r.f304a.a(new m(this, 0), new m(this, 1), new n(0, this), new n(1, this));
            } else {
                onBackInvokedCallback = p.f300a.a(new n(2, this));
            }
            this.f313d = onBackInvokedCallback;
        }
    }

    public final void a() {
        Object obj;
        int i2;
        a aVar = this.b;
        aVar.getClass();
        ListIterator listIterator = aVar.listIterator(aVar.f248c);
        while (true) {
            if (!listIterator.hasPrevious()) {
                obj = null;
                break;
            }
            obj = listIterator.previous();
            if (((k) obj).f592a) {
                break;
            }
        }
        k kVar = (k) obj;
        this.f312c = null;
        if (kVar != null) {
            p pVar = kVar.f594d;
            pVar.e(true);
            if (pVar.f605g.f592a) {
                pVar.e(false);
                pVar.d(true);
                ArrayList arrayList = pVar.f622x;
                ArrayList arrayList2 = pVar.f623y;
                ArrayList arrayList3 = pVar.f603d;
                if (arrayList3 == null || arrayList3.isEmpty()) {
                    i2 = -1;
                } else {
                    i2 = pVar.f603d.size() - 1;
                }
                if (i2 >= 0) {
                    for (int size = pVar.f603d.size() - 1; size >= i2; size--) {
                        arrayList.add((androidx.fragment.app.a) pVar.f603d.remove(size));
                        arrayList2.add(Boolean.TRUE);
                    }
                    pVar.b = true;
                    try {
                        pVar.j(pVar.f622x, pVar.f623y);
                    } finally {
                        pVar.a();
                    }
                }
                pVar.k();
                ((HashMap) pVar.f602c.b).values().removeAll(Collections.singleton((Object) null));
                return;
            }
            pVar.f.a();
            return;
        }
        this.f311a.run();
    }

    public final void b(boolean z2) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f314e;
        OnBackInvokedCallback onBackInvokedCallback = this.f313d;
        if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
            p pVar = p.f300a;
            if (z2 && !this.f) {
                pVar.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
                this.f = true;
            } else if (!z2 && this.f) {
                pVar.c(onBackInvokedDispatcher, onBackInvokedCallback);
                this.f = false;
            }
        }
    }

    public final void c() {
        boolean z2 = this.f315g;
        boolean z3 = false;
        a aVar = this.b;
        if (aVar == null || !aVar.isEmpty()) {
            Iterator it = aVar.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (((k) it.next()).f592a) {
                        z3 = true;
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        this.f315g = z3;
        if (z3 != z2 && Build.VERSION.SDK_INT >= 33) {
            b(z3);
        }
    }
}
