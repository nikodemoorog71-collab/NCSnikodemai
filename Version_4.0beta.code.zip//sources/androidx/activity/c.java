package androidx.activity;

public final /* synthetic */ class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f271a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(int i2, Object obj) {
        this.f271a = i2;
        this.b = obj;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v6, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v7, resolved type: android.app.Application} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v8, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v10, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v12, resolved type: android.app.Application} */
    /* JADX WARNING: type inference failed for: r6v5 */
    /* JADX WARNING: type inference failed for: r6v10 */
    /* JADX WARNING: type inference failed for: r5v11 */
    /* JADX WARNING: type inference failed for: r6v13 */
    /* JADX WARNING: Code restructure failed: missing block: B:100:0x0142, code lost:
        if (r0 == null) goto L_0x014a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x0144, code lost:
        r0.F(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x0148, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x014a, code lost:
        monitor-exit(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:?, code lost:
        r3.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:?, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x0151, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:113:?, code lost:
        r2 = u.C0152e.f1524a;
        android.os.Trace.endSection();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:114:0x0157, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x015f, code lost:
        throw new java.lang.RuntimeException("Unable to open file.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0160, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:119:?, code lost:
        r2 = u.C0152e.f1524a;
        android.os.Trace.endSection();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x0166, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x017d, code lost:
        throw new java.lang.RuntimeException("fetchFonts result is not OK. (" + r6 + ")");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:124:0x0180, code lost:
        monitor-enter(r3.f536d);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:?, code lost:
        r4 = r3.f539h;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x0183, code lost:
        if (r4 != null) goto L_0x0185;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:128:0x0185, code lost:
        r4.E(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x0189, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:132:0x018c, code lost:
        r3.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x0191, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:161:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:163:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:?, code lost:
        r5 = r3.b();
        r6 = r5.f1538e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x00f6, code lost:
        if (r6 != 2) goto L_0x0103;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x00f8, code lost:
        r2 = r3.f536d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x00fa, code lost:
        monitor-enter(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:?, code lost:
        monitor-exit(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x0100, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x0103, code lost:
        if (r6 != 0) goto L_0x0167;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:?, code lost:
        r4 = u.C0152e.f1524a;
        android.os.Trace.beginSection("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
        r2 = r3.f535c;
        r4 = r3.f534a;
        r2.getClass();
        r0 = r.C0139f.f1504a.k(r4, new v.g[]{r5}, 0);
        r2 = D.g.B(r3.f534a, r5.f1535a);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x0125, code lost:
        if (r2 == null) goto L_0x0158;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x0127, code lost:
        if (r0 == null) goto L_0x0158;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:92:?, code lost:
        android.os.Trace.beginSection("EmojiCompat.MetadataRepo.create");
        r4 = new Q.t(r0, D.g.M(r2));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:?, code lost:
        android.os.Trace.endSection();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:?, code lost:
        android.os.Trace.endSection();
        r2 = r3.f536d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:97:0x013f, code lost:
        monitor-enter(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:?, code lost:
        r0 = r3.f539h;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r19 = this;
            r1 = r19
            r0 = 0
            r2 = 2
            r3 = 1
            int r4 = r1.f271a
            switch(r4) {
                case 0: goto L_0x01ab;
                case 1: goto L_0x019c;
                case 2: goto L_0x0194;
                case 3: goto L_0x00dc;
                case 4: goto L_0x00b6;
                case 5: goto L_0x0012;
                default: goto L_0x000a;
            }
        L_0x000a:
            java.lang.Object r0 = r1.b
            i.U r0 = (i.U) r0
            r0.getClass()
            return
        L_0x0012:
            java.lang.Object r4 = r1.b
            android.app.Activity r4 = (android.app.Activity) r4
            boolean r5 = r4.isFinishing()
            if (r5 != 0) goto L_0x00b5
            int r5 = android.os.Build.VERSION.SDK_INT
            r6 = 28
            if (r5 < r6) goto L_0x0029
            java.lang.Class r0 = o.d.f1455a
            r4.recreate()
            goto L_0x00b5
        L_0x0029:
            java.lang.Class r6 = o.d.f1455a
            r6 = 27
            r7 = 26
            if (r5 == r7) goto L_0x0036
            if (r5 != r6) goto L_0x0034
            goto L_0x0036
        L_0x0034:
            r8 = r0
            goto L_0x0037
        L_0x0036:
            r8 = r3
        L_0x0037:
            java.lang.reflect.Method r9 = o.d.f
            if (r8 == 0) goto L_0x003f
            if (r9 != 0) goto L_0x003f
            goto L_0x00b2
        L_0x003f:
            java.lang.reflect.Method r8 = o.d.f1458e
            if (r8 != 0) goto L_0x0049
            java.lang.reflect.Method r8 = o.d.f1457d
            if (r8 != 0) goto L_0x0049
            goto L_0x00b2
        L_0x0049:
            java.lang.reflect.Field r8 = o.d.f1456c     // Catch:{ all -> 0x00b2 }
            java.lang.Object r10 = r8.get(r4)     // Catch:{ all -> 0x00b2 }
            if (r10 != 0) goto L_0x0053
            goto L_0x00b2
        L_0x0053:
            java.lang.reflect.Field r8 = o.d.b     // Catch:{ all -> 0x00b2 }
            java.lang.Object r8 = r8.get(r4)     // Catch:{ all -> 0x00b2 }
            if (r8 != 0) goto L_0x005c
            goto L_0x00b2
        L_0x005c:
            android.app.Application r11 = r4.getApplication()     // Catch:{ all -> 0x00b2 }
            o.c r12 = new o.c     // Catch:{ all -> 0x00b2 }
            r12.<init>(r4)     // Catch:{ all -> 0x00b2 }
            r11.registerActivityLifecycleCallbacks(r12)     // Catch:{ all -> 0x00b2 }
            android.os.Handler r13 = o.d.f1459g
            Q.c r14 = new Q.c     // Catch:{ all -> 0x00b2 }
            r14.<init>(r12, r3, r10)     // Catch:{ all -> 0x00b2 }
            r13.post(r14)     // Catch:{ all -> 0x00b2 }
            if (r5 == r7) goto L_0x0078
            if (r5 != r6) goto L_0x0077
            goto L_0x0078
        L_0x0077:
            r3 = r0
        L_0x0078:
            if (r3 == 0) goto L_0x009a
            r3 = r13
            java.lang.Integer r13 = java.lang.Integer.valueOf(r0)     // Catch:{ all -> 0x0096 }
            java.lang.Boolean r14 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x0096 }
            r5 = r11
            r11 = 0
            r6 = r12
            r12 = 0
            r15 = 0
            r16 = 0
            r17 = r14
            r18 = r14
            java.lang.Object[] r0 = new java.lang.Object[]{r10, r11, r12, r13, r14, r15, r16, r17, r18}     // Catch:{ all -> 0x0094 }
            r9.invoke(r8, r0)     // Catch:{ all -> 0x0094 }
            goto L_0x00a0
        L_0x0094:
            r0 = move-exception
            goto L_0x00a9
        L_0x0096:
            r0 = move-exception
            r5 = r11
            r6 = r12
            goto L_0x00a9
        L_0x009a:
            r5 = r11
            r6 = r12
            r3 = r13
            r4.recreate()     // Catch:{ all -> 0x0094 }
        L_0x00a0:
            Q.c r0 = new Q.c     // Catch:{ all -> 0x00b2 }
            r0.<init>(r5, r2, r6)     // Catch:{ all -> 0x00b2 }
            r3.post(r0)     // Catch:{ all -> 0x00b2 }
            goto L_0x00b5
        L_0x00a9:
            Q.c r7 = new Q.c     // Catch:{ all -> 0x00b2 }
            r7.<init>(r5, r2, r6)     // Catch:{ all -> 0x00b2 }
            r3.post(r7)     // Catch:{ all -> 0x00b2 }
            throw r0     // Catch:{ all -> 0x00b2 }
        L_0x00b2:
            r4.recreate()
        L_0x00b5:
            return
        L_0x00b6:
            java.lang.Object r0 = r1.b
            androidx.lifecycle.x r0 = (androidx.lifecycle.x) r0
            java.lang.String r2 = "this$0"
            a0.c.e(r0, r2)
            int r2 = r0.b
            androidx.lifecycle.s r4 = r0.f
            if (r2 != 0) goto L_0x00cc
            r0.f687c = r3
            androidx.lifecycle.k r2 = androidx.lifecycle.k.ON_PAUSE
            r4.d(r2)
        L_0x00cc:
            int r2 = r0.f686a
            if (r2 != 0) goto L_0x00db
            boolean r2 = r0.f687c
            if (r2 == 0) goto L_0x00db
            androidx.lifecycle.k r2 = androidx.lifecycle.k.ON_STOP
            r4.d(r2)
            r0.f688d = r3
        L_0x00db:
            return
        L_0x00dc:
            java.lang.Object r3 = r1.b
            androidx.emoji2.text.r r3 = (androidx.emoji2.text.r) r3
            java.lang.String r4 = "fetchFonts result is not OK. ("
            java.lang.Object r5 = r3.f536d
            monitor-enter(r5)
            D.g r6 = r3.f539h     // Catch:{ all -> 0x00ec }
            if (r6 != 0) goto L_0x00ef
            monitor-exit(r5)     // Catch:{ all -> 0x00ec }
            goto L_0x018f
        L_0x00ec:
            r0 = move-exception
            goto L_0x0192
        L_0x00ef:
            monitor-exit(r5)     // Catch:{ all -> 0x00ec }
            v.g r5 = r3.b()     // Catch:{ all -> 0x0100 }
            int r6 = r5.f1538e     // Catch:{ all -> 0x0100 }
            if (r6 != r2) goto L_0x0103
            java.lang.Object r2 = r3.f536d     // Catch:{ all -> 0x0100 }
            monitor-enter(r2)     // Catch:{ all -> 0x0100 }
            monitor-exit(r2)     // Catch:{ all -> 0x00fd }
            goto L_0x0103
        L_0x00fd:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x00fd }
            throw r0     // Catch:{ all -> 0x0100 }
        L_0x0100:
            r0 = move-exception
            goto L_0x017e
        L_0x0103:
            if (r6 != 0) goto L_0x0167
            java.lang.String r2 = "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"
            int r4 = u.C0152e.f1524a     // Catch:{ all -> 0x0160 }
            android.os.Trace.beginSection(r2)     // Catch:{ all -> 0x0160 }
            F.d r2 = r3.f535c     // Catch:{ all -> 0x0160 }
            android.content.Context r4 = r3.f534a     // Catch:{ all -> 0x0160 }
            r2.getClass()     // Catch:{ all -> 0x0160 }
            v.g[] r2 = new v.g[]{r5}     // Catch:{ all -> 0x0160 }
            D.g r6 = r.C0139f.f1504a     // Catch:{ all -> 0x0160 }
            android.graphics.Typeface r0 = r6.k(r4, r2, r0)     // Catch:{ all -> 0x0160 }
            android.content.Context r2 = r3.f534a     // Catch:{ all -> 0x0160 }
            android.net.Uri r4 = r5.f1535a     // Catch:{ all -> 0x0160 }
            java.nio.MappedByteBuffer r2 = D.g.B(r2, r4)     // Catch:{ all -> 0x0160 }
            if (r2 == 0) goto L_0x0158
            if (r0 == 0) goto L_0x0158
            java.lang.String r4 = "EmojiCompat.MetadataRepo.create"
            android.os.Trace.beginSection(r4)     // Catch:{ all -> 0x0151 }
            Q.t r4 = new Q.t     // Catch:{ all -> 0x0151 }
            F.b r2 = D.g.M(r2)     // Catch:{ all -> 0x0151 }
            r4.<init>((android.graphics.Typeface) r0, (F.b) r2)     // Catch:{ all -> 0x0151 }
            android.os.Trace.endSection()     // Catch:{ all -> 0x0160 }
            android.os.Trace.endSection()     // Catch:{ all -> 0x0100 }
            java.lang.Object r2 = r3.f536d     // Catch:{ all -> 0x0100 }
            monitor-enter(r2)     // Catch:{ all -> 0x0100 }
            D.g r0 = r3.f539h     // Catch:{ all -> 0x0148 }
            if (r0 == 0) goto L_0x014a
            r0.F(r4)     // Catch:{ all -> 0x0148 }
            goto L_0x014a
        L_0x0148:
            r0 = move-exception
            goto L_0x014f
        L_0x014a:
            monitor-exit(r2)     // Catch:{ all -> 0x0148 }
            r3.a()     // Catch:{ all -> 0x0100 }
            goto L_0x018f
        L_0x014f:
            monitor-exit(r2)     // Catch:{ all -> 0x0148 }
            throw r0     // Catch:{ all -> 0x0100 }
        L_0x0151:
            r0 = move-exception
            int r2 = u.C0152e.f1524a     // Catch:{ all -> 0x0160 }
            android.os.Trace.endSection()     // Catch:{ all -> 0x0160 }
            throw r0     // Catch:{ all -> 0x0160 }
        L_0x0158:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException     // Catch:{ all -> 0x0160 }
            java.lang.String r2 = "Unable to open file."
            r0.<init>(r2)     // Catch:{ all -> 0x0160 }
            throw r0     // Catch:{ all -> 0x0160 }
        L_0x0160:
            r0 = move-exception
            int r2 = u.C0152e.f1524a     // Catch:{ all -> 0x0100 }
            android.os.Trace.endSection()     // Catch:{ all -> 0x0100 }
            throw r0     // Catch:{ all -> 0x0100 }
        L_0x0167:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException     // Catch:{ all -> 0x0100 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0100 }
            r2.<init>(r4)     // Catch:{ all -> 0x0100 }
            r2.append(r6)     // Catch:{ all -> 0x0100 }
            java.lang.String r4 = ")"
            r2.append(r4)     // Catch:{ all -> 0x0100 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0100 }
            r0.<init>(r2)     // Catch:{ all -> 0x0100 }
            throw r0     // Catch:{ all -> 0x0100 }
        L_0x017e:
            java.lang.Object r2 = r3.f536d
            monitor-enter(r2)
            D.g r4 = r3.f539h     // Catch:{ all -> 0x0189 }
            if (r4 == 0) goto L_0x018b
            r4.E(r0)     // Catch:{ all -> 0x0189 }
            goto L_0x018b
        L_0x0189:
            r0 = move-exception
            goto L_0x0190
        L_0x018b:
            monitor-exit(r2)     // Catch:{ all -> 0x0189 }
            r3.a()
        L_0x018f:
            return
        L_0x0190:
            monitor-exit(r2)     // Catch:{ all -> 0x0189 }
            throw r0
        L_0x0192:
            monitor-exit(r5)     // Catch:{ all -> 0x00ec }
            throw r0
        L_0x0194:
            java.lang.Object r0 = r1.b
            e.g r0 = (e.C0019g) r0
            e.C0019g.b(r0)
            return
        L_0x019c:
            java.lang.Object r0 = r1.b
            androidx.activity.j r0 = (androidx.activity.j) r0
            java.lang.Runnable r2 = r0.b
            if (r2 == 0) goto L_0x01aa
            r2.run()
            r2 = 0
            r0.b = r2
        L_0x01aa:
            return
        L_0x01ab:
            java.lang.Object r0 = r1.b
            e.i r0 = (e.C0021i) r0
            r0.invalidateOptionsMenu()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.c.run():void");
    }
}
