package androidx.activity;

import C.j;
import androidx.lifecycle.E;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import e.C0021i;
import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

class ComponentActivity$3 implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0021i f260a;

    public ComponentActivity$3(C0021i iVar) {
        this.f260a = iVar;
    }

    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_DESTROY) {
            this.f260a.b.b = null;
            if (!this.f260a.isChangingConfigurations()) {
                j b = this.f260a.b();
                for (E e2 : ((LinkedHashMap) b.b).values()) {
                    HashMap hashMap = e2.f661a;
                    if (hashMap != null) {
                        synchronized (hashMap) {
                            try {
                                for (Object next : e2.f661a.values()) {
                                    if (next instanceof Closeable) {
                                        ((Closeable) next).close();
                                    }
                                }
                            } catch (IOException e3) {
                                throw new RuntimeException(e3);
                            } catch (Throwable th) {
                                throw th;
                            }
                        }
                    }
                    LinkedHashSet linkedHashSet = e2.b;
                    if (linkedHashSet != null) {
                        synchronized (linkedHashSet) {
                            try {
                                for (Closeable closeable : e2.b) {
                                    if (closeable != null) {
                                        closeable.close();
                                    }
                                }
                            } catch (IOException e4) {
                                throw new RuntimeException(e4);
                            } catch (Throwable th2) {
                                throw th2;
                            }
                        }
                    }
                    e2.a();
                }
                ((LinkedHashMap) b.b).clear();
            }
            j jVar = this.f260a.f287h;
            C0021i iVar = jVar.f282d;
            iVar.getWindow().getDecorView().removeCallbacks(jVar);
            iVar.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(jVar);
        }
    }
}
