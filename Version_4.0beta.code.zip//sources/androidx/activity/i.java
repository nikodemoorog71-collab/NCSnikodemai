package androidx.activity;

import C.j;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public j f279a;
}
