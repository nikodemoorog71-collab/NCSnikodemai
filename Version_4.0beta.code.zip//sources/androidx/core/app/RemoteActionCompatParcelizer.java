package androidx.core.app;

import P.a;
import P.b;
import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f465a;
        boolean z2 = true;
        if (aVar.e(1)) {
            obj = aVar.g();
        }
        remoteActionCompat.f465a = (IconCompat) obj;
        CharSequence charSequence = remoteActionCompat.b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f126e);
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f466c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f126e);
        }
        remoteActionCompat.f466c = charSequence2;
        remoteActionCompat.f467d = (PendingIntent) aVar.f(remoteActionCompat.f467d, 4);
        boolean z3 = remoteActionCompat.f468e;
        if (aVar.e(5)) {
            if (((b) aVar).f126e.readInt() != 0) {
                z3 = true;
            } else {
                z3 = false;
            }
        }
        remoteActionCompat.f468e = z3;
        boolean z4 = remoteActionCompat.f;
        if (!aVar.e(6)) {
            z2 = z4;
        } else if (((b) aVar).f126e.readInt() == 0) {
            z2 = false;
        }
        remoteActionCompat.f = z2;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f465a;
        aVar.h(1);
        aVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        aVar.h(2);
        Parcel parcel = ((b) aVar).f126e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f466c;
        aVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f467d;
        aVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z2 = remoteActionCompat.f468e;
        aVar.h(5);
        parcel.writeInt(z2 ? 1 : 0);
        boolean z3 = remoteActionCompat.f;
        aVar.h(6);
        parcel.writeInt(z3 ? 1 : 0);
    }
}
