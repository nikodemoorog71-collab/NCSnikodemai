package androidx.core.app;

import P.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat implements c {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f465a;
    public CharSequence b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f466c;

    /* renamed from: d  reason: collision with root package name */
    public PendingIntent f467d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f468e;
    public boolean f;
}
