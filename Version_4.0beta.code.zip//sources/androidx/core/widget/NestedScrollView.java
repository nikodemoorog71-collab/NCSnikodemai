package androidx.core.widget;

import D.g;
import D.j;
import D.k;
import D.l;
import D.n;
import Q.f;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.util.ArrayList;
import java.util.WeakHashMap;
import nikodemai.firmware.ncs.R;
import y.A;
import y.C0158b;
import y.C0164h;
import y.C0169m;
import y.C0170n;
import y.C0171o;
import y.K;
import y.O;

public class NestedScrollView extends FrameLayout implements C0171o {

    /* renamed from: B  reason: collision with root package name */
    public static final float f482B = ((float) (Math.log(0.78d) / Math.log(0.9d)));

    /* renamed from: C  reason: collision with root package name */
    public static final j f483C = new C0158b();

    /* renamed from: D  reason: collision with root package name */
    public static final int[] f484D = {16843130};

    /* renamed from: A  reason: collision with root package name */
    public final C0164h f485A = new C0164h(getContext(), new C.j(1, (Object) this));

    /* renamed from: a  reason: collision with root package name */
    public final float f486a;
    public long b;

    /* renamed from: c  reason: collision with root package name */
    public final Rect f487c = new Rect();

    /* renamed from: d  reason: collision with root package name */
    public final OverScroller f488d;

    /* renamed from: e  reason: collision with root package name */
    public final EdgeEffect f489e;
    public final EdgeEffect f;

    /* renamed from: g  reason: collision with root package name */
    public int f490g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f491h = true;

    /* renamed from: i  reason: collision with root package name */
    public boolean f492i = false;

    /* renamed from: j  reason: collision with root package name */
    public View f493j = null;

    /* renamed from: k  reason: collision with root package name */
    public boolean f494k = false;

    /* renamed from: l  reason: collision with root package name */
    public VelocityTracker f495l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f496m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f497n = true;

    /* renamed from: o  reason: collision with root package name */
    public final int f498o;

    /* renamed from: p  reason: collision with root package name */
    public final int f499p;

    /* renamed from: q  reason: collision with root package name */
    public final int f500q;

    /* renamed from: r  reason: collision with root package name */
    public int f501r = -1;

    /* renamed from: s  reason: collision with root package name */
    public final int[] f502s = new int[2];

    /* renamed from: t  reason: collision with root package name */
    public final int[] f503t = new int[2];

    /* renamed from: u  reason: collision with root package name */
    public int f504u;

    /* renamed from: v  reason: collision with root package name */
    public int f505v;

    /* renamed from: w  reason: collision with root package name */
    public n f506w;

    /* renamed from: x  reason: collision with root package name */
    public final f f507x;

    /* renamed from: y  reason: collision with root package name */
    public final C0169m f508y;

    /* renamed from: z  reason: collision with root package name */
    public float f509z;

    /* JADX WARNING: type inference failed for: r7v2, types: [Q.f, java.lang.Object] */
    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.nestedScrollViewStyle);
        EdgeEffect edgeEffect;
        EdgeEffect edgeEffect2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31) {
            edgeEffect = D.f.a(context, attributeSet);
        } else {
            edgeEffect = new EdgeEffect(context);
        }
        this.f489e = edgeEffect;
        if (i2 >= 31) {
            edgeEffect2 = D.f.a(context, attributeSet);
        } else {
            edgeEffect2 = new EdgeEffect(context);
        }
        this.f = edgeEffect2;
        this.f486a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f488d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f498o = viewConfiguration.getScaledTouchSlop();
        this.f499p = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f500q = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f484D, R.attr.nestedScrollViewStyle, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f507x = new Object();
        this.f508y = new C0169m(this);
        setNestedScrollingEnabled(true);
        K.h(this, f483C);
    }

    public static boolean m(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        ViewParent parent = view.getParent();
        if (!(parent instanceof ViewGroup) || !m((View) parent, nestedScrollView)) {
            return false;
        }
        return true;
    }

    public final void a(int i2, int i3, int[] iArr, int i4) {
        i(i2, i3, iArr, (int[]) null, i4);
    }

    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void b(View view, View view2, int i2, int i3) {
        f fVar = this.f507x;
        if (i3 == 1) {
            fVar.b = i2;
        } else {
            fVar.f145a = i2;
        }
        w(2, i3);
    }

    public final void c(View view, int i2) {
        f fVar = this.f507x;
        if (i2 == 1) {
            fVar.b = 0;
        } else {
            fVar.f145a = 0;
        }
        y(i2);
    }

    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x007f  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x00a5  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x00a8  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00e5  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00e9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void computeScroll() {
        /*
            r16 = this;
            r0 = r16
            android.widget.OverScroller r1 = r0.f488d
            boolean r1 = r1.isFinished()
            if (r1 == 0) goto L_0x000b
            return
        L_0x000b:
            android.widget.OverScroller r1 = r0.f488d
            r1.computeScrollOffset()
            android.widget.OverScroller r1 = r0.f488d
            int r1 = r1.getCurrY()
            int r2 = r0.f505v
            int r2 = r1 - r2
            int r3 = r0.getHeight()
            android.widget.EdgeEffect r6 = r0.f
            android.widget.EdgeEffect r7 = r0.f489e
            r4 = 1056964608(0x3f000000, float:0.5)
            r5 = 0
            r8 = 1082130432(0x40800000, float:4.0)
            if (r2 <= 0) goto L_0x0049
            float r9 = D.g.r(r7)
            int r9 = (r9 > r5 ? 1 : (r9 == r5 ? 0 : -1))
            if (r9 == 0) goto L_0x0049
            int r5 = -r2
            float r5 = (float) r5
            float r5 = r5 * r8
            float r9 = (float) r3
            float r5 = r5 / r9
            int r3 = -r3
            float r3 = (float) r3
            float r3 = r3 / r8
            float r4 = D.g.G(r7, r5, r4)
            float r4 = r4 * r3
            int r3 = java.lang.Math.round(r4)
            if (r3 == r2) goto L_0x0047
            r7.finish()
        L_0x0047:
            int r2 = r2 - r3
            goto L_0x0067
        L_0x0049:
            if (r2 >= 0) goto L_0x0067
            float r9 = D.g.r(r6)
            int r5 = (r9 > r5 ? 1 : (r9 == r5 ? 0 : -1))
            if (r5 == 0) goto L_0x0067
            float r5 = (float) r2
            float r5 = r5 * r8
            float r3 = (float) r3
            float r5 = r5 / r3
            float r3 = r3 / r8
            float r4 = D.g.G(r6, r5, r4)
            float r4 = r4 * r3
            int r3 = java.lang.Math.round(r4)
            if (r3 == r2) goto L_0x0047
            r6.finish()
            goto L_0x0047
        L_0x0067:
            r0.f505v = r1
            int[] r15 = r0.f503t
            r8 = 1
            r9 = 0
            r15[r8] = r9
            r5 = 1
            r1 = 0
            r4 = 0
            r3 = r15
            r0.i(r1, r2, r3, r4, r5)
            r1 = r15[r8]
            int r2 = r2 - r1
            int r1 = r0.getScrollRange()
            if (r2 == 0) goto L_0x00a5
            int r3 = r0.getScrollY()
            int r4 = r0.getScrollX()
            r0.q(r2, r4, r3, r1)
            int r4 = r0.getScrollY()
            int r10 = r4 - r3
            int r12 = r2 - r10
            r15[r8] = r9
            r9 = 0
            r11 = 0
            r2 = r8
            y.m r8 = r0.f508y
            int[] r13 = r0.f502s
            r14 = 1
            r3 = r2
            r8.b(r9, r10, r11, r12, r13, r14, r15)
            r2 = r15[r3]
            int r2 = r12 - r2
            goto L_0x00a6
        L_0x00a5:
            r3 = r8
        L_0x00a6:
            if (r2 == 0) goto L_0x00dd
            int r4 = r0.getOverScrollMode()
            if (r4 == 0) goto L_0x00b2
            if (r4 != r3) goto L_0x00d5
            if (r1 <= 0) goto L_0x00d5
        L_0x00b2:
            if (r2 >= 0) goto L_0x00c5
            boolean r1 = r7.isFinished()
            if (r1 == 0) goto L_0x00d5
            android.widget.OverScroller r1 = r0.f488d
            float r1 = r1.getCurrVelocity()
            int r1 = (int) r1
            r7.onAbsorb(r1)
            goto L_0x00d5
        L_0x00c5:
            boolean r1 = r6.isFinished()
            if (r1 == 0) goto L_0x00d5
            android.widget.OverScroller r1 = r0.f488d
            float r1 = r1.getCurrVelocity()
            int r1 = (int) r1
            r6.onAbsorb(r1)
        L_0x00d5:
            android.widget.OverScroller r1 = r0.f488d
            r1.abortAnimation()
            r0.y(r3)
        L_0x00dd:
            android.widget.OverScroller r1 = r0.f488d
            boolean r1 = r1.isFinished()
            if (r1 != 0) goto L_0x00e9
            r0.postInvalidateOnAnimation()
            return
        L_0x00e9:
            r0.y(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.computeScroll():void");
    }

    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        if (scrollY > max) {
            return (scrollY - max) + bottom;
        }
        return bottom;
    }

    public final void d(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        o(i5, i6, iArr);
    }

    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (super.dispatchKeyEvent(keyEvent) || j(keyEvent)) {
            return true;
        }
        return false;
    }

    public final boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        ViewParent c2;
        C0169m mVar = this.f508y;
        if (mVar.f1595d && (c2 = mVar.c(0)) != null) {
            try {
                return O.a(c2, mVar.f1594c, f2, f3, z2);
            } catch (AbstractMethodError e2) {
                Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedFling", e2);
            }
        }
        return false;
    }

    public final boolean dispatchNestedPreFling(float f2, float f3) {
        return this.f508y.a(f2, f3);
    }

    public final boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return i(i2, i3, iArr, iArr2, 0);
    }

    public final boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.f508y.b(i2, i3, i4, i5, iArr, 0, (int[]) null);
    }

    public final void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f489e;
        int i3 = 0;
        if (!edgeEffect.isFinished()) {
            int save = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int min = Math.min(0, scrollY);
            if (k.a(this)) {
                width -= getPaddingRight() + getPaddingLeft();
                i2 = getPaddingLeft();
            } else {
                i2 = 0;
            }
            if (k.a(this)) {
                height -= getPaddingBottom() + getPaddingTop();
                min += getPaddingTop();
            }
            canvas.translate((float) i2, (float) min);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect2 = this.f;
        if (!edgeEffect2.isFinished()) {
            int save2 = canvas.save();
            int width2 = getWidth();
            int height2 = getHeight();
            int max = Math.max(getScrollRange(), scrollY) + height2;
            if (k.a(this)) {
                width2 -= getPaddingRight() + getPaddingLeft();
                i3 = getPaddingLeft();
            }
            if (k.a(this)) {
                height2 -= getPaddingBottom() + getPaddingTop();
                max -= getPaddingBottom();
            }
            canvas.translate((float) (i3 - width2), (float) max);
            canvas.rotate(180.0f, (float) width2, 0.0f);
            edgeEffect2.setSize(width2, height2);
            if (edgeEffect2.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save2);
        }
    }

    public final void e(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5, int i6) {
        o(i5, i6, (int[]) null);
    }

    public final boolean f(View view, View view2, int i2, int i3) {
        return (i2 & 2) != 0;
    }

    public final boolean g(int i2) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !n(findNextFocus, maxScrollAmount, getHeight())) {
            if (i2 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i2 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            t(maxScrollAmount, 0, 1, true);
        } else {
            Rect rect = this.f487c;
            findNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(findNextFocus, rect);
            t(h(rect), 0, 1, true);
            findNextFocus.requestFocus(i2);
        }
        if (findFocus != null && findFocus.isFocused() && !n(findFocus, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        f fVar = this.f507x;
        return fVar.b | fVar.f145a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.f509z == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f509z = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f509z;
    }

    public final int h(Rect rect) {
        int i2;
        int i3;
        int i4;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        if (rect.bottom < childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
            i2 = i5 - verticalFadingEdgeLength;
        } else {
            i2 = i5;
        }
        int i6 = rect.bottom;
        if (i6 > i2 && rect.top > scrollY) {
            if (rect.height() > height) {
                i4 = rect.top - scrollY;
            } else {
                i4 = rect.bottom - i2;
            }
            return Math.min(i4, (childAt.getBottom() + layoutParams.bottomMargin) - i5);
        } else if (rect.top >= scrollY || i6 >= i2) {
            return 0;
        } else {
            if (rect.height() > height) {
                i3 = 0 - (i2 - rect.bottom);
            } else {
                i3 = 0 - (scrollY - rect.top);
            }
            return Math.max(i3, -getScrollY());
        }
    }

    public final boolean hasNestedScrollingParent() {
        if (this.f508y.c(0) != null) {
            return true;
        }
        return false;
    }

    public final boolean i(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        ViewParent c2;
        int i5;
        int i6;
        C0169m mVar = this.f508y;
        if (!mVar.f1595d || (c2 = mVar.c(i4)) == null) {
            return false;
        }
        if (i2 != 0 || i3 != 0) {
            NestedScrollView nestedScrollView = mVar.f1594c;
            if (iArr2 != null) {
                nestedScrollView.getLocationInWindow(iArr2);
                i6 = iArr2[0];
                i5 = iArr2[1];
            } else {
                i6 = 0;
                i5 = 0;
            }
            if (iArr == null) {
                if (mVar.f1596e == null) {
                    mVar.f1596e = new int[2];
                }
                iArr = mVar.f1596e;
            }
            iArr[0] = 0;
            iArr[1] = 0;
            if (c2 instanceof C0170n) {
                ((C0170n) c2).a(i2, i3, iArr, i4);
            } else if (i4 == 0) {
                try {
                    O.c(c2, nestedScrollView, i2, i3, iArr);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedPreScroll", e2);
                }
            }
            if (iArr2 != null) {
                nestedScrollView.getLocationInWindow(iArr2);
                iArr2[0] = iArr2[0] - i6;
                iArr2[1] = iArr2[1] - i5;
            }
            if (iArr[0] == 0 && iArr[1] == 0) {
                return false;
            }
            return true;
        } else if (iArr2 == null) {
            return false;
        } else {
            iArr2[0] = 0;
            iArr2[1] = 0;
            return false;
        }
    }

    public final boolean isNestedScrollingEnabled() {
        return this.f508y.f1595d;
    }

    public final boolean j(KeyEvent keyEvent) {
        this.f487c.setEmpty();
        int i2 = 130;
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() == 0) {
                    int keyCode = keyEvent.getKeyCode();
                    if (keyCode != 19) {
                        if (keyCode != 20) {
                            if (keyCode == 62) {
                                if (keyEvent.isShiftPressed()) {
                                    i2 = 33;
                                }
                                r(i2);
                                return false;
                            } else if (keyCode == 92) {
                                return l(33);
                            } else {
                                if (keyCode == 93) {
                                    return l(130);
                                }
                                if (keyCode == 122) {
                                    r(33);
                                    return false;
                                } else if (keyCode == 123) {
                                    r(130);
                                    return false;
                                }
                            }
                        } else if (keyEvent.isAltPressed()) {
                            return l(130);
                        } else {
                            return g(130);
                        }
                    } else if (keyEvent.isAltPressed()) {
                        return l(33);
                    } else {
                        return g(33);
                    }
                }
                return false;
            }
        }
        if (isFocused() && keyEvent.getKeyCode() != 4) {
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
            if (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final void k(int i2) {
        if (getChildCount() > 0) {
            this.f488d.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            w(2, 1);
            this.f505v = getScrollY();
            postInvalidateOnAnimation();
        }
    }

    public final boolean l(int i2) {
        boolean z2;
        int childCount;
        if (i2 == 130) {
            z2 = true;
        } else {
            z2 = false;
        }
        int height = getHeight();
        Rect rect = this.f487c;
        rect.top = 0;
        rect.bottom = height;
        if (z2 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return s(i2, rect.top, rect.bottom);
    }

    public final void measureChild(View view, int i2, int i3) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public final void measureChildWithMargins(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final boolean n(View view, int i2, int i3) {
        Rect rect = this.f487c;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        if (rect.bottom + i2 < getScrollY() || rect.top - i2 > getScrollY() + i3) {
            return false;
        }
        return true;
    }

    public final void o(int i2, int i3, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i2);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f508y.b(0, scrollY2, 0, i2 - scrollY2, (int[]) null, i3, iArr);
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f492i = false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00d7, code lost:
        if (r2 >= 0) goto L_0x00e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x012b, code lost:
        if (r2 >= 0) goto L_0x0132;
     */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x02bd  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x02c5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean onGenericMotionEvent(android.view.MotionEvent r31) {
        /*
            r30 = this;
            r0 = r30
            r1 = r31
            r3 = 1
            int r4 = r1.getAction()
            r5 = 8
            if (r4 != r5) goto L_0x036a
            boolean r4 = r0.f494k
            if (r4 != 0) goto L_0x036a
            int r4 = r1.getSource()
            r5 = 2
            r4 = r4 & r5
            if (r4 != r5) goto L_0x001b
            r4 = r3
            goto L_0x001c
        L_0x001b:
            r4 = 0
        L_0x001c:
            r7 = 0
            r8 = 4194304(0x400000, float:5.877472E-39)
            r9 = 26
            if (r4 == 0) goto L_0x002f
            r4 = 9
            float r10 = r1.getAxisValue(r4)
            float r11 = r1.getX()
            int r11 = (int) r11
            goto L_0x0045
        L_0x002f:
            int r4 = r1.getSource()
            r4 = r4 & r8
            if (r4 != r8) goto L_0x0042
            float r10 = r1.getAxisValue(r9)
            int r4 = r0.getWidth()
            int r11 = r4 / 2
            r4 = r9
            goto L_0x0045
        L_0x0042:
            r10 = r7
            r4 = 0
            r11 = 0
        L_0x0045:
            int r12 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1))
            if (r12 == 0) goto L_0x036a
            float r12 = r0.getVerticalScrollFactorCompat()
            float r12 = r12 * r10
            int r10 = (int) r12
            int r12 = r1.getSource()
            r13 = 8194(0x2002, float:1.1482E-41)
            r12 = r12 & r13
            if (r12 != r13) goto L_0x005a
            r12 = r3
            goto L_0x005b
        L_0x005a:
            r12 = 0
        L_0x005b:
            int r10 = -r10
            r0.t(r10, r11, r3, r12)
            if (r4 == 0) goto L_0x0367
            y.h r10 = r0.f485A
            r10.getClass()
            int r11 = r1.getSource()
            int r12 = r1.getDeviceId()
            int r13 = r10.f
            int[] r14 = r10.f1591h
            r16 = r3
            r3 = 34
            if (r13 != r11) goto L_0x0088
            int r13 = r10.f1590g
            if (r13 != r12) goto L_0x0088
            int r13 = r10.f1589e
            if (r13 == r4) goto L_0x0081
            goto L_0x0088
        L_0x0081:
            r6 = 0
            r18 = 20
            r20 = 0
            goto L_0x013c
        L_0x0088:
            android.content.Context r13 = r10.f1586a
            android.view.ViewConfiguration r5 = android.view.ViewConfiguration.get(r13)
            r18 = 20
            int r2 = r1.getDeviceId()
            int r7 = r1.getSource()
            r20 = 0
            int r6 = android.os.Build.VERSION.SDK_INT
            java.lang.String r15 = "android"
            java.lang.String r9 = "dimen"
            r8 = -1
            if (r6 < r3) goto L_0x00aa
            int r23 = y.N.f1551a
            int r2 = y.M.b(r5, r2, r4, r7)
            goto L_0x00e2
        L_0x00aa:
            int r23 = y.N.f1551a
            android.view.InputDevice r2 = android.view.InputDevice.getDevice(r2)
            if (r2 == 0) goto L_0x00df
            android.view.InputDevice$MotionRange r2 = r2.getMotionRange(r4, r7)
            if (r2 == 0) goto L_0x00df
            android.content.res.Resources r2 = r13.getResources()
            r3 = 4194304(0x400000, float:5.877472E-39)
            if (r7 != r3) goto L_0x00cb
            r3 = 26
            if (r4 != r3) goto L_0x00cb
            java.lang.String r3 = "config_viewMinRotaryEncoderFlingVelocity"
            int r3 = r2.getIdentifier(r3, r9, r15)
            goto L_0x00cc
        L_0x00cb:
            r3 = r8
        L_0x00cc:
            java.util.Objects.requireNonNull(r5)
            if (r3 == r8) goto L_0x00da
            if (r3 == 0) goto L_0x00df
            int r2 = r2.getDimensionPixelSize(r3)
            if (r2 >= 0) goto L_0x00e2
            goto L_0x00df
        L_0x00da:
            int r2 = r5.getScaledMinimumFlingVelocity()
            goto L_0x00e2
        L_0x00df:
            r2 = 2147483647(0x7fffffff, float:NaN)
        L_0x00e2:
            r14[r20] = r2
            int r2 = r1.getDeviceId()
            int r3 = r1.getSource()
            r7 = 34
            if (r6 < r7) goto L_0x00f5
            int r2 = y.M.a(r5, r2, r4, r3)
            goto L_0x0132
        L_0x00f5:
            android.view.InputDevice r2 = android.view.InputDevice.getDevice(r2)
            if (r2 == 0) goto L_0x0104
            android.view.InputDevice$MotionRange r2 = r2.getMotionRange(r4, r3)
            if (r2 == 0) goto L_0x0104
            r2 = r16
            goto L_0x0106
        L_0x0104:
            r2 = r20
        L_0x0106:
            r6 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 != 0) goto L_0x010c
        L_0x010a:
            r2 = r6
            goto L_0x0132
        L_0x010c:
            android.content.res.Resources r2 = r13.getResources()
            r7 = 4194304(0x400000, float:5.877472E-39)
            if (r3 != r7) goto L_0x011f
            r3 = 26
            if (r4 != r3) goto L_0x011f
            java.lang.String r3 = "config_viewMaxRotaryEncoderFlingVelocity"
            int r3 = r2.getIdentifier(r3, r9, r15)
            goto L_0x0120
        L_0x011f:
            r3 = r8
        L_0x0120:
            java.util.Objects.requireNonNull(r5)
            if (r3 == r8) goto L_0x012e
            if (r3 == 0) goto L_0x010a
            int r2 = r2.getDimensionPixelSize(r3)
            if (r2 >= 0) goto L_0x0132
            goto L_0x010a
        L_0x012e:
            int r2 = r5.getScaledMaximumFlingVelocity()
        L_0x0132:
            r14[r16] = r2
            r10.f = r11
            r10.f1590g = r12
            r10.f1589e = r4
            r6 = r16
        L_0x013c:
            r2 = r14[r20]
            r3 = 2147483647(0x7fffffff, float:NaN)
            if (r2 != r3) goto L_0x014e
            android.view.VelocityTracker r1 = r10.f1587c
            if (r1 == 0) goto L_0x0369
            r1.recycle()
            r1 = 0
            r10.f1587c = r1
            return r16
        L_0x014e:
            android.view.VelocityTracker r2 = r10.f1587c
            if (r2 != 0) goto L_0x0158
            android.view.VelocityTracker r2 = android.view.VelocityTracker.obtain()
            r10.f1587c = r2
        L_0x0158:
            android.view.VelocityTracker r2 = r10.f1587c
            java.util.Map r3 = y.C0175t.f1597a
            r2.addMovement(r1)
            int r3 = android.os.Build.VERSION.SDK_INT
            r7 = 34
            if (r3 < r7) goto L_0x0166
            goto L_0x01c4
        L_0x0166:
            int r3 = r1.getSource()
            r7 = 4194304(0x400000, float:5.877472E-39)
            if (r3 != r7) goto L_0x01c4
            java.util.Map r3 = y.C0175t.f1597a
            boolean r5 = r3.containsKey(r2)
            if (r5 != 0) goto L_0x017e
            y.u r5 = new y.u
            r5.<init>()
            r3.put(r2, r5)
        L_0x017e:
            java.lang.Object r3 = r3.get(r2)
            y.u r3 = (y.C0176u) r3
            r3.getClass()
            long r7 = r1.getEventTime()
            int r5 = r3.f1600d
            long[] r9 = r3.b
            if (r5 == 0) goto L_0x01a4
            int r5 = r3.f1601e
            r11 = r9[r5]
            long r11 = r7 - r11
            r24 = 40
            int r5 = (r11 > r24 ? 1 : (r11 == r24 ? 0 : -1))
            if (r5 <= 0) goto L_0x01a4
            r5 = r20
            r3.f1600d = r5
            r5 = 0
            r3.f1599c = r5
        L_0x01a4:
            int r5 = r3.f1601e
            int r5 = r5 + 1
            int r5 = r5 % 20
            r3.f1601e = r5
            int r11 = r3.f1600d
            r12 = r18
            if (r11 == r12) goto L_0x01b6
            int r11 = r11 + 1
            r3.f1600d = r11
        L_0x01b6:
            r11 = 26
            float r1 = r1.getAxisValue(r11)
            float[] r11 = r3.f1598a
            r11[r5] = r1
            int r1 = r3.f1601e
            r9[r1] = r7
        L_0x01c4:
            r1 = 1000(0x3e8, float:1.401E-42)
            r3 = 2139095039(0x7f7fffff, float:3.4028235E38)
            r2.computeCurrentVelocity(r1, r3)
            java.util.Map r5 = y.C0175t.f1597a
            java.lang.Object r5 = r5.get(r2)
            y.u r5 = (y.C0176u) r5
            if (r5 == 0) goto L_0x02d6
            int r7 = r5.f1600d
            r8 = 2
            if (r7 >= r8) goto L_0x01e3
        L_0x01db:
            r26 = r2
            r31 = r3
            r2 = r1
            r1 = 0
            goto L_0x02b0
        L_0x01e3:
            int r8 = r5.f1601e
            r18 = 20
            int r9 = r8 + 20
            int r7 = r7 + -1
            int r9 = r9 - r7
            int r9 = r9 % 20
            long[] r7 = r5.b
            r11 = r7[r8]
        L_0x01f2:
            r24 = r7[r9]
            long r26 = r11 - r24
            r28 = 100
            int r8 = (r26 > r28 ? 1 : (r26 == r28 ? 0 : -1))
            if (r8 <= 0) goto L_0x0209
            int r8 = r5.f1600d
            int r8 = r8 + -1
            r5.f1600d = r8
            int r9 = r9 + 1
            r18 = 20
            int r9 = r9 % 20
            goto L_0x01f2
        L_0x0209:
            r18 = 20
            int r8 = r5.f1600d
            r11 = 2
            if (r8 >= r11) goto L_0x0211
            goto L_0x01db
        L_0x0211:
            float[] r12 = r5.f1598a
            if (r8 != r11) goto L_0x022e
            int r9 = r9 + 1
            int r9 = r9 % 20
            r17 = r7[r9]
            int r7 = (r24 > r17 ? 1 : (r24 == r17 ? 0 : -1))
            if (r7 != 0) goto L_0x0220
            goto L_0x01db
        L_0x0220:
            r7 = r12[r9]
            long r8 = r17 - r24
            float r8 = (float) r8
            float r7 = r7 / r8
            r26 = r2
            r31 = r3
            r2 = r1
            r1 = r7
            goto L_0x02b0
        L_0x022e:
            r8 = 0
            r11 = 0
            r13 = 0
        L_0x0231:
            int r15 = r5.f1600d
            int r15 = r15 + -1
            r17 = 1073741824(0x40000000, float:2.0)
            r21 = 1065353216(0x3f800000, float:1.0)
            r22 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r11 >= r15) goto L_0x0294
            int r15 = r11 + r9
            r18 = 20
            int r24 = r15 % 20
            r24 = r7[r24]
            int r15 = r15 + 1
            int r15 = r15 % 20
            r26 = r7[r15]
            int r26 = (r26 > r24 ? 1 : (r26 == r24 ? 0 : -1))
            if (r26 != 0) goto L_0x0256
            r26 = r2
            r31 = r3
            r2 = r16
            goto L_0x028a
        L_0x0256:
            int r13 = r13 + 1
            r19 = 0
            int r26 = (r8 > r19 ? 1 : (r8 == r19 ? 0 : -1))
            if (r26 >= 0) goto L_0x0260
            r21 = r22
        L_0x0260:
            float r22 = java.lang.Math.abs(r8)
            r31 = r3
            float r3 = r22 * r17
            r26 = r2
            double r1 = (double) r3
            double r1 = java.lang.Math.sqrt(r1)
            float r1 = (float) r1
            float r21 = r21 * r1
            r1 = r12[r15]
            r2 = r7[r15]
            long r2 = r2 - r24
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = r1 - r21
            float r1 = java.lang.Math.abs(r1)
            float r1 = r1 * r2
            float r1 = r1 + r8
            r2 = r16
            if (r13 != r2) goto L_0x0289
            r3 = 1056964608(0x3f000000, float:0.5)
            float r1 = r1 * r3
        L_0x0289:
            r8 = r1
        L_0x028a:
            int r11 = r11 + r2
            r3 = r31
            r16 = r2
            r2 = r26
            r1 = 1000(0x3e8, float:1.401E-42)
            goto L_0x0231
        L_0x0294:
            r26 = r2
            r31 = r3
            r19 = 0
            int r1 = (r8 > r19 ? 1 : (r8 == r19 ? 0 : -1))
            if (r1 >= 0) goto L_0x02a0
            r21 = r22
        L_0x02a0:
            float r1 = java.lang.Math.abs(r8)
            float r1 = r1 * r17
            double r1 = (double) r1
            double r1 = java.lang.Math.sqrt(r1)
            float r1 = (float) r1
            float r1 = r1 * r21
            r2 = 1000(0x3e8, float:1.401E-42)
        L_0x02b0:
            float r2 = (float) r2
            float r1 = r1 * r2
            r5.f1599c = r1
            float r2 = java.lang.Math.abs(r31)
            float r2 = -r2
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 >= 0) goto L_0x02c5
            float r1 = java.lang.Math.abs(r31)
            float r1 = -r1
            r5.f1599c = r1
            goto L_0x02d8
        L_0x02c5:
            float r1 = r5.f1599c
            float r2 = java.lang.Math.abs(r31)
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L_0x02d8
            float r1 = java.lang.Math.abs(r31)
            r5.f1599c = r1
            goto L_0x02d8
        L_0x02d6:
            r26 = r2
        L_0x02d8:
            int r1 = android.os.Build.VERSION.SDK_INT
            r7 = 34
            if (r1 < r7) goto L_0x02e5
            r1 = r26
            float r1 = y.C0174s.a(r1, r4)
            goto L_0x0309
        L_0x02e5:
            r1 = r26
            if (r4 != 0) goto L_0x02ee
            float r1 = r1.getXVelocity()
            goto L_0x0309
        L_0x02ee:
            r2 = 1
            if (r4 != r2) goto L_0x02f6
            float r1 = r1.getYVelocity()
            goto L_0x0309
        L_0x02f6:
            java.util.Map r2 = y.C0175t.f1597a
            java.lang.Object r1 = r2.get(r1)
            y.u r1 = (y.C0176u) r1
            if (r1 == 0) goto L_0x0308
            r3 = 26
            if (r4 == r3) goto L_0x0305
            goto L_0x0308
        L_0x0305:
            float r1 = r1.f1599c
            goto L_0x0309
        L_0x0308:
            r1 = 0
        L_0x0309:
            C.j r2 = r10.b
            java.lang.Object r2 = r2.b
            androidx.core.widget.NestedScrollView r2 = (androidx.core.widget.NestedScrollView) r2
            float r3 = r2.getVerticalScrollFactorCompat()
            float r3 = -r3
            float r1 = r1 * r3
            float r3 = java.lang.Math.signum(r1)
            if (r6 != 0) goto L_0x032b
            float r4 = r10.f1588d
            float r4 = java.lang.Math.signum(r4)
            int r4 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r4 == 0) goto L_0x0330
            r19 = 0
            int r3 = (r3 > r19 ? 1 : (r3 == r19 ? 0 : -1))
            if (r3 == 0) goto L_0x0330
        L_0x032b:
            android.widget.OverScroller r3 = r2.f488d
            r3.abortAnimation()
        L_0x0330:
            float r3 = java.lang.Math.abs(r1)
            r20 = 0
            r4 = r14[r20]
            float r4 = (float) r4
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 >= 0) goto L_0x0340
            r16 = 1
            goto L_0x0369
        L_0x0340:
            r16 = 1
            r3 = r14[r16]
            int r4 = -r3
            float r4 = (float) r4
            float r3 = (float) r3
            float r1 = java.lang.Math.min(r1, r3)
            float r1 = java.lang.Math.max(r4, r1)
            r19 = 0
            int r3 = (r1 > r19 ? 1 : (r1 == r19 ? 0 : -1))
            if (r3 != 0) goto L_0x0358
            r7 = r19
            goto L_0x0362
        L_0x0358:
            android.widget.OverScroller r3 = r2.f488d
            r3.abortAnimation()
            int r3 = (int) r1
            r2.k(r3)
            r7 = r1
        L_0x0362:
            r10.f1588d = r7
            r16 = 1
            return r16
        L_0x0367:
            r16 = r3
        L_0x0369:
            return r16
        L_0x036a:
            r20 = 0
            return r20
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onGenericMotionEvent(android.view.MotionEvent):boolean");
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z2 = true;
        if (action == 2 && this.f494k) {
            return true;
        }
        int i2 = action & 255;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 == 2) {
                    int i3 = this.f501r;
                    if (i3 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i3);
                        if (findPointerIndex == -1) {
                            Log.e("NestedScrollView", "Invalid pointerId=" + i3 + " in onInterceptTouchEvent");
                        } else {
                            int y2 = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y2 - this.f490g) > this.f498o && (2 & getNestedScrollAxes()) == 0) {
                                this.f494k = true;
                                this.f490g = y2;
                                if (this.f495l == null) {
                                    this.f495l = VelocityTracker.obtain();
                                }
                                this.f495l.addMovement(motionEvent);
                                this.f504u = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                    }
                } else if (i2 != 3) {
                    if (i2 == 6) {
                        p(motionEvent);
                    }
                }
            }
            this.f494k = false;
            this.f501r = -1;
            VelocityTracker velocityTracker = this.f495l;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.f495l = null;
            }
            if (this.f488d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            y(0);
        } else {
            int y3 = (int) motionEvent.getY();
            int x2 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y3 >= childAt.getTop() - scrollY && y3 < childAt.getBottom() - scrollY && x2 >= childAt.getLeft() && x2 < childAt.getRight()) {
                    this.f490g = y3;
                    this.f501r = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker2 = this.f495l;
                    if (velocityTracker2 == null) {
                        this.f495l = VelocityTracker.obtain();
                    } else {
                        velocityTracker2.clear();
                    }
                    this.f495l.addMovement(motionEvent);
                    this.f488d.computeScrollOffset();
                    if (!x(motionEvent) && this.f488d.isFinished()) {
                        z2 = false;
                    }
                    this.f494k = z2;
                    w(2, 0);
                }
            }
            if (!x(motionEvent) && this.f488d.isFinished()) {
                z2 = false;
            }
            this.f494k = z2;
            VelocityTracker velocityTracker3 = this.f495l;
            if (velocityTracker3 != null) {
                velocityTracker3.recycle();
                this.f495l = null;
            }
        }
        return this.f494k;
    }

    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6;
        super.onLayout(z2, i2, i3, i4, i5);
        int i7 = 0;
        this.f491h = false;
        View view = this.f493j;
        if (view != null && m(view, this)) {
            View view2 = this.f493j;
            Rect rect = this.f487c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int h2 = h(rect);
            if (h2 != 0) {
                scrollBy(0, h2);
            }
        }
        this.f493j = null;
        if (!this.f492i) {
            if (this.f506w != null) {
                scrollTo(getScrollX(), this.f506w.f46a);
                this.f506w = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i6 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                i6 = 0;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < i6 && scrollY >= 0) {
                i7 = paddingTop + scrollY > i6 ? i6 - paddingTop : scrollY;
            }
            if (i7 != scrollY) {
                scrollTo(getScrollX(), i7);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f492i = true;
    }

    public final void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f496m && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public final boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (z2) {
            return false;
        }
        dispatchNestedFling(0.0f, f3, true);
        k((int) f3);
        return true;
    }

    public final boolean onNestedPreFling(View view, float f2, float f3) {
        return this.f508y.a(f2, f3);
    }

    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        i(i2, i3, iArr, (int[]) null, 0);
    }

    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        o(i5, 0, (int[]) null);
    }

    public final void onNestedScrollAccepted(View view, View view2, int i2) {
        b(view, view2, i2, 0);
    }

    public final void onOverScrolled(int i2, int i3, boolean z2, boolean z3) {
        super.scrollTo(i2, i3);
    }

    public final boolean onRequestFocusInDescendants(int i2, Rect rect) {
        View view;
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        if (rect == null) {
            view = FocusFinder.getInstance().findNextFocus(this, (View) null, i2);
        } else {
            view = FocusFinder.getInstance().findNextFocusFromRect(this, rect, i2);
        }
        if (view != null && n(view, 0, getHeight())) {
            return view.requestFocus(i2, rect);
        }
        return false;
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof n)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        n nVar = (n) parcelable;
        super.onRestoreInstanceState(nVar.getSuperState());
        this.f506w = nVar;
        requestLayout();
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [android.view.View$BaseSavedState, android.os.Parcelable, D.n] */
    public final Parcelable onSaveInstanceState() {
        ? baseSavedState = new View.BaseSavedState(super.onSaveInstanceState());
        baseSavedState.f46a = getScrollY();
        return baseSavedState;
    }

    public final void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
    }

    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && n(findFocus, 0, i5)) {
            Rect rect = this.f487c;
            findFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(findFocus, rect);
            int h2 = h(rect);
            if (h2 == 0) {
                return;
            }
            if (this.f497n) {
                v(0, h2, false);
            } else {
                scrollBy(0, h2);
            }
        }
    }

    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        return f(view, view2, i2, 0);
    }

    public final void onStopNestedScroll(View view) {
        c(view, 0);
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        MotionEvent motionEvent2 = motionEvent;
        if (this.f495l == null) {
            this.f495l = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent2.getActionMasked();
        if (actionMasked == 0) {
            this.f504u = 0;
        }
        MotionEvent obtain = MotionEvent.obtain(motionEvent2);
        float f2 = 0.0f;
        obtain.offsetLocation(0.0f, (float) this.f504u);
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f;
            EdgeEffect edgeEffect2 = this.f489e;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f495l;
                velocityTracker.computeCurrentVelocity(1000, (float) this.f500q);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f501r);
                if (Math.abs(yVelocity) >= this.f499p) {
                    if (g.r(edgeEffect2) != 0.0f) {
                        if (u(edgeEffect2, yVelocity)) {
                            edgeEffect2.onAbsorb(yVelocity);
                        } else {
                            k(-yVelocity);
                        }
                    } else if (g.r(edgeEffect) != 0.0f) {
                        int i2 = -yVelocity;
                        if (u(edgeEffect, i2)) {
                            edgeEffect.onAbsorb(i2);
                        } else {
                            k(i2);
                        }
                    } else {
                        int i3 = -yVelocity;
                        float f3 = (float) i3;
                        if (!this.f508y.a(0.0f, f3)) {
                            dispatchNestedFling(0.0f, f3, true);
                            k(i3);
                        }
                    }
                } else if (this.f488d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f501r = -1;
                this.f494k = false;
                VelocityTracker velocityTracker2 = this.f495l;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f495l = null;
                }
                y(0);
                this.f489e.onRelease();
                this.f.onRelease();
            } else if (actionMasked == 2) {
                int findPointerIndex = motionEvent2.findPointerIndex(this.f501r);
                if (findPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f501r + " in onTouchEvent");
                } else {
                    int y2 = (int) motionEvent2.getY(findPointerIndex);
                    int i4 = this.f490g - y2;
                    float x2 = motionEvent2.getX(findPointerIndex) / ((float) getWidth());
                    float height = ((float) i4) / ((float) getHeight());
                    if (g.r(edgeEffect2) != 0.0f) {
                        float f4 = -g.G(edgeEffect2, -height, x2);
                        if (g.r(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                        f2 = f4;
                    } else if (g.r(edgeEffect) != 0.0f) {
                        float G2 = g.G(edgeEffect, height, 1.0f - x2);
                        if (g.r(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                        f2 = G2;
                    }
                    int round = Math.round(f2 * ((float) getHeight()));
                    if (round != 0) {
                        invalidate();
                    }
                    int i5 = i4 - round;
                    if (!this.f494k && Math.abs(i5) > this.f498o) {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f494k = true;
                        i5 = i5 > 0 ? i5 - this.f498o : i5 + this.f498o;
                    }
                    if (this.f494k) {
                        int t2 = t(i5, (int) motionEvent2.getX(findPointerIndex), 0, false);
                        this.f490g = y2 - t2;
                        this.f504u += t2;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f494k && getChildCount() > 0 && this.f488d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f501r = -1;
                this.f494k = false;
                VelocityTracker velocityTracker3 = this.f495l;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f495l = null;
                }
                y(0);
                this.f489e.onRelease();
                this.f.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent2.getActionIndex();
                this.f490g = (int) motionEvent2.getY(actionIndex);
                this.f501r = motionEvent2.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                p(motionEvent);
                this.f490g = (int) motionEvent2.getY(motionEvent2.findPointerIndex(this.f501r));
            }
        } else if (getChildCount() == 0) {
            return false;
        } else {
            if (this.f494k && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f488d.isFinished()) {
                this.f488d.abortAnimation();
                y(1);
            }
            int pointerId = motionEvent2.getPointerId(0);
            this.f490g = (int) motionEvent2.getY();
            this.f501r = pointerId;
            w(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f495l;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(obtain);
        }
        obtain.recycle();
        return true;
    }

    public final void p(MotionEvent motionEvent) {
        int i2;
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f501r) {
            if (actionIndex == 0) {
                i2 = 1;
            } else {
                i2 = 0;
            }
            this.f490g = (int) motionEvent.getY(i2);
            this.f501r = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.f495l;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public final boolean q(int i2, int i3, int i4, int i5) {
        boolean z2;
        int i6;
        boolean z3;
        int i7;
        int overScrollMode = getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i8 = i4 + i2;
        if (i3 <= 0 && i3 >= 0) {
            i6 = i3;
            z2 = false;
        } else {
            i6 = 0;
            z2 = true;
        }
        if (i8 > i5) {
            i7 = i5;
        } else if (i8 < 0) {
            i7 = 0;
        } else {
            i7 = i8;
            z3 = false;
            if (z3 && this.f508y.c(1) == null) {
                this.f488d.springBack(i6, i7, 0, 0, 0, getScrollRange());
            }
            super.scrollTo(i6, i7);
            if (!z2 || z3) {
                return true;
            }
            return false;
        }
        z3 = true;
        this.f488d.springBack(i6, i7, 0, 0, 0, getScrollRange());
        super.scrollTo(i6, i7);
        if (!z2) {
        }
        return true;
    }

    public final void r(int i2) {
        boolean z2;
        if (i2 == 130) {
            z2 = true;
        } else {
            z2 = false;
        }
        int height = getHeight();
        Rect rect = this.f487c;
        if (z2) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i3 = rect.top;
        int i4 = height + i3;
        rect.bottom = i4;
        s(i2, i3, i4);
    }

    public final void requestChildFocus(View view, View view2) {
        if (!this.f491h) {
            Rect rect = this.f487c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int h2 = h(rect);
            if (h2 != 0) {
                scrollBy(0, h2);
            }
        } else {
            this.f493j = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        boolean z3;
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int h2 = h(rect);
        if (h2 != 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (z3) {
            if (z2) {
                scrollBy(0, h2);
                return z3;
            }
            v(0, h2, false);
        }
        return z3;
    }

    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        VelocityTracker velocityTracker;
        if (z2 && (velocityTracker = this.f495l) != null) {
            velocityTracker.recycle();
            this.f495l = null;
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public final void requestLayout() {
        this.f491h = true;
        super.requestLayout();
    }

    public final boolean s(int i2, int i3, int i4) {
        boolean z2;
        boolean z3;
        int i5;
        boolean z4;
        boolean z5;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        int height = getHeight();
        int scrollY = getScrollY();
        int i9 = height + scrollY;
        if (i6 == 33) {
            z2 = true;
        } else {
            z2 = false;
        }
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z6 = false;
        for (int i10 = 0; i10 < size; i10++) {
            View view2 = focusables.get(i10);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i7 < bottom && top < i8) {
                if (i7 >= top || bottom >= i8) {
                    z4 = false;
                } else {
                    z4 = true;
                }
                if (view == null) {
                    view = view2;
                    z6 = z4;
                } else {
                    if ((!z2 || top >= view.getTop()) && (z2 || bottom <= view.getBottom())) {
                        z5 = false;
                    } else {
                        z5 = true;
                    }
                    if (z6) {
                        if (z4) {
                            if (!z5) {
                            }
                        }
                    } else if (z4) {
                        view = view2;
                        z6 = true;
                    } else if (!z5) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i7 < scrollY || i8 > i9) {
            if (z2) {
                i5 = i7 - scrollY;
            } else {
                i5 = i8 - i9;
            }
            t(i5, 0, 1, true);
            z3 = true;
        } else {
            z3 = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i6);
        }
        return z3;
    }

    public final void scrollTo(int i2, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i2 < 0) {
                i2 = 0;
            } else if (width + i2 > width2) {
                i2 = width2 - width;
            }
            if (height >= height2 || i3 < 0) {
                i3 = 0;
            } else if (height + i3 > height2) {
                i3 = height2 - height;
            }
            if (i2 != getScrollX() || i3 != getScrollY()) {
                super.scrollTo(i2, i3);
            }
        }
    }

    public void setFillViewport(boolean z2) {
        if (z2 != this.f496m) {
            this.f496m = z2;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z2) {
        C0169m mVar = this.f508y;
        if (mVar.f1595d) {
            WeakHashMap weakHashMap = K.f1547a;
            A.z(mVar.f1594c);
        }
        mVar.f1595d = z2;
    }

    public void setSmoothScrollingEnabled(boolean z2) {
        this.f497n = z2;
    }

    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    public final boolean startNestedScroll(int i2) {
        return w(i2, 0);
    }

    public final void stopNestedScroll() {
        y(0);
    }

    public final int t(int i2, int i3, int i4, boolean z2) {
        int i5;
        int i6;
        boolean z3;
        boolean z4;
        boolean z5;
        VelocityTracker velocityTracker;
        int i7 = i3;
        int i8 = i4;
        if (i8 == 1) {
            w(2, i8);
        }
        boolean i9 = i(0, i2, this.f503t, this.f502s, i8);
        int[] iArr = this.f503t;
        int[] iArr2 = this.f502s;
        if (i9) {
            i6 = i2 - iArr[1];
            i5 = iArr2[1];
        } else {
            i6 = i2;
            i5 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        if ((overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z2) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (!q(i6, 0, scrollY, scrollRange) || this.f508y.c(i8) != null) {
            z4 = false;
        } else {
            z4 = true;
        }
        int scrollY2 = getScrollY() - scrollY;
        iArr[1] = 0;
        int i10 = scrollRange;
        this.f508y.b(0, scrollY2, 0, i6 - scrollY2, this.f502s, i8, iArr);
        int i11 = i5 + iArr2[1];
        int i12 = i6 - iArr[1];
        int i13 = scrollY + i12;
        EdgeEffect edgeEffect = this.f;
        EdgeEffect edgeEffect2 = this.f489e;
        if (i13 < 0) {
            if (z3) {
                g.G(edgeEffect2, ((float) (-i12)) / ((float) getHeight()), ((float) i7) / ((float) getWidth()));
                if (!edgeEffect.isFinished()) {
                    edgeEffect.onRelease();
                }
            }
        } else if (i13 > i10 && z3) {
            g.G(edgeEffect, ((float) i12) / ((float) getHeight()), 1.0f - (((float) i7) / ((float) getWidth())));
            if (!edgeEffect2.isFinished()) {
                edgeEffect2.onRelease();
            }
        }
        if (!edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
            postInvalidateOnAnimation();
            z5 = false;
        } else {
            z5 = z4;
        }
        if (z5 && i8 == 0 && (velocityTracker = this.f495l) != null) {
            velocityTracker.clear();
        }
        if (i8 == 1) {
            y(i8);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i11;
    }

    public final boolean u(EdgeEffect edgeEffect, int i2) {
        if (i2 > 0) {
            return true;
        }
        float r2 = g.r(edgeEffect) * ((float) getHeight());
        float f2 = this.f486a * 0.015f;
        double log = Math.log((double) ((((float) Math.abs(-i2)) * 0.35f) / f2));
        double d2 = (double) f482B;
        if (((float) (Math.exp((d2 / (d2 - 1.0d)) * log) * ((double) f2))) < r2) {
            return true;
        }
        return false;
    }

    public final void v(int i2, int i3, boolean z2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.b > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f488d;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom())))) - scrollY, 250);
                if (z2) {
                    w(2, 1);
                } else {
                    y(1);
                }
                this.f505v = getScrollY();
                postInvalidateOnAnimation();
            } else {
                if (!this.f488d.isFinished()) {
                    this.f488d.abortAnimation();
                    y(1);
                }
                scrollBy(i2, i3);
            }
            this.b = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    public final boolean w(int i2, int i3) {
        boolean z2;
        boolean z3;
        C0169m mVar = this.f508y;
        if (mVar.c(i3) != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            return true;
        }
        if (!mVar.f1595d) {
            return false;
        }
        View view = mVar.f1594c;
        View view2 = view;
        for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
            boolean z4 = parent instanceof C0170n;
            if (z4) {
                z3 = ((C0170n) parent).f(view2, view, i2, i3);
            } else {
                if (i3 == 0) {
                    try {
                        z3 = O.f(parent, view2, view, i2);
                    } catch (AbstractMethodError e2) {
                        Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onStartNestedScroll", e2);
                    }
                }
                z3 = false;
            }
            if (z3) {
                if (i3 == 0) {
                    mVar.f1593a = parent;
                } else if (i3 == 1) {
                    mVar.b = parent;
                }
                if (z4) {
                    ((C0170n) parent).b(view2, view, i2, i3);
                } else if (i3 == 0) {
                    try {
                        O.e(parent, view2, view, i2);
                    } catch (AbstractMethodError e3) {
                        Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onNestedScrollAccepted", e3);
                    }
                }
                return true;
            }
            if (parent instanceof View) {
                view2 = (View) parent;
            }
        }
        return false;
    }

    public final boolean x(MotionEvent motionEvent) {
        boolean z2;
        EdgeEffect edgeEffect = this.f489e;
        if (g.r(edgeEffect) != 0.0f) {
            g.G(edgeEffect, 0.0f, motionEvent.getX() / ((float) getWidth()));
            z2 = true;
        } else {
            z2 = false;
        }
        EdgeEffect edgeEffect2 = this.f;
        if (g.r(edgeEffect2) == 0.0f) {
            return z2;
        }
        g.G(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / ((float) getWidth())));
        return true;
    }

    public final void y(int i2) {
        C0169m mVar = this.f508y;
        ViewParent c2 = mVar.c(i2);
        if (c2 != null) {
            boolean z2 = c2 instanceof C0170n;
            NestedScrollView nestedScrollView = mVar.f1594c;
            if (z2) {
                ((C0170n) c2).c(nestedScrollView, i2);
            } else if (i2 == 0) {
                try {
                    O.g(c2, nestedScrollView);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onStopNestedScroll", e2);
                }
            }
            if (i2 == 0) {
                mVar.f1593a = null;
            } else if (i2 == 1) {
                mVar.b = null;
            }
        }
    }

    public final void addView(View view, int i2) {
        if (getChildCount() <= 0) {
            super.addView(view, i2);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public final void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void setOnScrollChangeListener(l lVar) {
    }
}
