package androidx.core.graphics.drawable;

import P.a;
import P.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;

public class IconCompatParcelizer {
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        int i2 = iconCompat.f474a;
        if (aVar.e(1)) {
            i2 = ((b) aVar).f126e.readInt();
        }
        iconCompat.f474a = i2;
        byte[] bArr = iconCompat.f475c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f126e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f475c = bArr;
        iconCompat.f476d = aVar.f(iconCompat.f476d, 3);
        int i3 = iconCompat.f477e;
        if (aVar.e(4)) {
            i3 = ((b) aVar).f126e.readInt();
        }
        iconCompat.f477e = i3;
        int i4 = iconCompat.f;
        if (aVar.e(5)) {
            i4 = ((b) aVar).f126e.readInt();
        }
        iconCompat.f = i4;
        iconCompat.f478g = (ColorStateList) aVar.f(iconCompat.f478g, 6);
        String str = iconCompat.f480i;
        if (aVar.e(7)) {
            str = ((b) aVar).f126e.readString();
        }
        iconCompat.f480i = str;
        String str2 = iconCompat.f481j;
        if (aVar.e(8)) {
            str2 = ((b) aVar).f126e.readString();
        }
        iconCompat.f481j = str2;
        iconCompat.f479h = PorterDuff.Mode.valueOf(iconCompat.f480i);
        switch (iconCompat.f474a) {
            case -1:
                Parcelable parcelable = iconCompat.f476d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    return iconCompat;
                }
                throw new IllegalArgumentException("Invalid icon");
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f476d;
                if (parcelable2 != null) {
                    iconCompat.b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f475c;
                iconCompat.b = bArr3;
                iconCompat.f474a = 3;
                iconCompat.f477e = 0;
                iconCompat.f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str3 = new String(iconCompat.f475c, Charset.forName("UTF-16"));
                iconCompat.b = str3;
                if (iconCompat.f474a == 2 && iconCompat.f481j == null) {
                    iconCompat.f481j = str3.split(":", -1)[0];
                    break;
                }
            case 3:
                iconCompat.b = iconCompat.f475c;
                return iconCompat;
        }
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f480i = iconCompat.f479h.name();
        switch (iconCompat.f474a) {
            case -1:
                iconCompat.f476d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case 5:
                iconCompat.f476d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.f475c = ((String) iconCompat.b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f475c = (byte[]) iconCompat.b;
                break;
            case 4:
            case 6:
                iconCompat.f475c = iconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i2 = iconCompat.f474a;
        if (-1 != i2) {
            aVar.h(1);
            ((b) aVar).f126e.writeInt(i2);
        }
        byte[] bArr = iconCompat.f475c;
        if (bArr != null) {
            aVar.h(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f126e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f476d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).f126e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.f477e;
        if (i3 != 0) {
            aVar.h(4);
            ((b) aVar).f126e.writeInt(i3);
        }
        int i4 = iconCompat.f;
        if (i4 != 0) {
            aVar.h(5);
            ((b) aVar).f126e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f478g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).f126e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f480i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).f126e.writeString(str);
        }
        String str2 = iconCompat.f481j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).f126e.writeString(str2);
        }
    }
}
