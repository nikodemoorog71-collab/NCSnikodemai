package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import androidx.versionedparcelable.CustomVersionedParcelable;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k  reason: collision with root package name */
    public static final PorterDuff.Mode f473k = PorterDuff.Mode.SRC_IN;

    /* renamed from: a  reason: collision with root package name */
    public int f474a = -1;
    public Object b;

    /* renamed from: c  reason: collision with root package name */
    public byte[] f475c = null;

    /* renamed from: d  reason: collision with root package name */
    public Parcelable f476d = null;

    /* renamed from: e  reason: collision with root package name */
    public int f477e = 0;
    public int f = 0;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f478g = null;

    /* renamed from: h  reason: collision with root package name */
    public PorterDuff.Mode f479h = f473k;

    /* renamed from: i  reason: collision with root package name */
    public String f480i = null;

    /* renamed from: j  reason: collision with root package name */
    public String f481j;

    /* JADX WARNING: Removed duplicated region for block: B:42:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0108  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String toString() {
        /*
            r7 = this;
            int r0 = r7.f474a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r7.b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r2 = "Icon(typ="
            r0.<init>(r2)
            int r2 = r7.f474a
            switch(r2) {
                case 1: goto L_0x002a;
                case 2: goto L_0x0027;
                case 3: goto L_0x0024;
                case 4: goto L_0x0021;
                case 5: goto L_0x001e;
                case 6: goto L_0x001b;
                default: goto L_0x0018;
            }
        L_0x0018:
            java.lang.String r2 = "UNKNOWN"
            goto L_0x002c
        L_0x001b:
            java.lang.String r2 = "URI_MASKABLE"
            goto L_0x002c
        L_0x001e:
            java.lang.String r2 = "BITMAP_MASKABLE"
            goto L_0x002c
        L_0x0021:
            java.lang.String r2 = "URI"
            goto L_0x002c
        L_0x0024:
            java.lang.String r2 = "DATA"
            goto L_0x002c
        L_0x0027:
            java.lang.String r2 = "RESOURCE"
            goto L_0x002c
        L_0x002a:
            java.lang.String r2 = "BITMAP"
        L_0x002c:
            r0.append(r2)
            int r2 = r7.f474a
            switch(r2) {
                case 1: goto L_0x00d4;
                case 2: goto L_0x005c;
                case 3: goto L_0x0042;
                case 4: goto L_0x0036;
                case 5: goto L_0x00d4;
                case 6: goto L_0x0036;
                default: goto L_0x0034;
            }
        L_0x0034:
            goto L_0x00f4
        L_0x0036:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r7.b
            r0.append(r1)
            goto L_0x00f4
        L_0x0042:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r7.f477e
            r0.append(r1)
            int r1 = r7.f
            if (r1 == 0) goto L_0x00f4
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r7.f
            r0.append(r1)
            goto L_0x00f4
        L_0x005c:
            java.lang.String r2 = " pkg="
            r0.append(r2)
            java.lang.String r2 = r7.f481j
            r0.append(r2)
            java.lang.String r2 = " id="
            r0.append(r2)
            int r2 = r7.f474a
            if (r2 != r1) goto L_0x00a9
            int r1 = android.os.Build.VERSION.SDK_INT
            java.lang.Object r2 = r7.b
            java.lang.String r3 = "Unable to get icon resource"
            java.lang.String r4 = "IconCompat"
            r5 = 28
            if (r1 < r5) goto L_0x0080
            int r1 = s.C0144c.a(r2)
            goto L_0x00ae
        L_0x0080:
            java.lang.Class r1 = r2.getClass()     // Catch:{ IllegalAccessException -> 0x009a, InvocationTargetException -> 0x0098, NoSuchMethodException -> 0x0096 }
            java.lang.String r5 = "getResId"
            r6 = 0
            java.lang.reflect.Method r1 = r1.getMethod(r5, r6)     // Catch:{ IllegalAccessException -> 0x009a, InvocationTargetException -> 0x0098, NoSuchMethodException -> 0x0096 }
            java.lang.Object r1 = r1.invoke(r2, r6)     // Catch:{ IllegalAccessException -> 0x009a, InvocationTargetException -> 0x0098, NoSuchMethodException -> 0x0096 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ IllegalAccessException -> 0x009a, InvocationTargetException -> 0x0098, NoSuchMethodException -> 0x0096 }
            int r1 = r1.intValue()     // Catch:{ IllegalAccessException -> 0x009a, InvocationTargetException -> 0x0098, NoSuchMethodException -> 0x0096 }
            goto L_0x00ae
        L_0x0096:
            r1 = move-exception
            goto L_0x009c
        L_0x0098:
            r1 = move-exception
            goto L_0x00a0
        L_0x009a:
            r1 = move-exception
            goto L_0x00a4
        L_0x009c:
            android.util.Log.e(r4, r3, r1)
            goto L_0x00a7
        L_0x00a0:
            android.util.Log.e(r4, r3, r1)
            goto L_0x00a7
        L_0x00a4:
            android.util.Log.e(r4, r3, r1)
        L_0x00a7:
            r1 = 0
            goto L_0x00ae
        L_0x00a9:
            r1 = 2
            if (r2 != r1) goto L_0x00c0
            int r1 = r7.f477e
        L_0x00ae:
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            java.lang.Object[] r1 = new java.lang.Object[]{r1}
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x00f4
        L_0x00c0:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "called getResId() on "
            r1.<init>(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x00d4:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r7.b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r7.b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
            r0.append(r1)
        L_0x00f4:
            android.content.res.ColorStateList r1 = r7.f478g
            if (r1 == 0) goto L_0x0102
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r7.f478g
            r0.append(r1)
        L_0x0102:
            android.graphics.PorterDuff$Mode r1 = r7.f479h
            android.graphics.PorterDuff$Mode r2 = f473k
            if (r1 == r2) goto L_0x0112
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r7.f479h
            r0.append(r1)
        L_0x0112:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
