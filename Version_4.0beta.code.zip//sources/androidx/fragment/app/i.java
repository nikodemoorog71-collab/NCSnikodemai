package androidx.fragment.app;

import android.content.res.Configuration;
import o.r;
import x.C0156a;

public final /* synthetic */ class i implements C0156a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f590a;
    public final /* synthetic */ p b;

    public /* synthetic */ i(p pVar, int i2) {
        this.f590a = i2;
        this.b = pVar;
    }

    public final void a(Object obj) {
        switch (this.f590a) {
            case 0:
                Configuration configuration = (Configuration) obj;
                for (Object obj2 : this.b.f602c.n()) {
                    if (obj2 != null) {
                        throw new ClassCastException();
                    }
                }
                return;
            case 1:
                p pVar = this.b;
                pVar.getClass();
                if (((Integer) obj).intValue() == 80) {
                    for (Object obj3 : pVar.f602c.n()) {
                        if (obj3 != null) {
                            throw new ClassCastException();
                        }
                    }
                    return;
                }
                return;
            case 2:
                p pVar2 = this.b;
                pVar2.getClass();
                boolean z2 = ((o.i) obj).f1462a;
                for (Object obj4 : pVar2.f602c.n()) {
                    if (obj4 != null) {
                        throw new ClassCastException();
                    }
                }
                return;
            default:
                p pVar3 = this.b;
                pVar3.getClass();
                boolean z3 = ((r) obj).f1464a;
                for (Object obj5 : pVar3.f602c.n()) {
                    if (obj5 != null) {
                        throw new ClassCastException();
                    }
                }
                return;
        }
    }
}
