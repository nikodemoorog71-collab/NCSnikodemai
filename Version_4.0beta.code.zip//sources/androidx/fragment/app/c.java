package androidx.fragment.app;

import D.m;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

public final class c implements Parcelable {
    public static final Parcelable.Creator<c> CREATOR = new m(4);

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f581a;
    public final ArrayList b;

    public c(Parcel parcel) {
        this.f581a = parcel.createStringArrayList();
        this.b = parcel.createTypedArrayList(b.CREATOR);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeStringList(this.f581a);
        parcel.writeTypedList(this.b);
    }
}
