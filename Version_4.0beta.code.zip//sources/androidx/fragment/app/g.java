package androidx.fragment.app;

import H.a;
import a0.c;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import e.C0021i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import nikodemai.firmware.ncs.R;
import y.C0180y;
import y.K;
import y.f0;

public final class g extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f586a = new ArrayList();
    public final ArrayList b = new ArrayList();

    /* renamed from: c  reason: collision with root package name */
    public View.OnApplyWindowInsetsListener f587c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f588d = true;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g(Context context, AttributeSet attributeSet, p pVar) {
        super(context, attributeSet);
        String str;
        c.e(context, "context");
        c.e(attributeSet, "attrs");
        c.e(pVar, "fm");
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.b, 0, 0);
        classAttribute = classAttribute == null ? obtainStyledAttributes.getString(0) : classAttribute;
        String string = obtainStyledAttributes.getString(1);
        obtainStyledAttributes.recycle();
        int id = getId();
        pVar.g();
        if (classAttribute == null) {
            Iterator it = pVar.f602c.i().iterator();
            if (it.hasNext()) {
                it.next().getClass();
                throw new ClassCastException();
            }
        } else if (id == -1) {
            if (string != null) {
                str = " with tag ".concat(string);
            } else {
                str = "";
            }
            throw new IllegalStateException("FragmentContainerView must have an android:id to add Fragment " + classAttribute + str);
        } else {
            context.getClassLoader();
            pVar.f618t.a(classAttribute);
            c.d((Object) null, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            throw null;
        }
    }

    public final void a(View view) {
        if (this.b.contains(view)) {
            this.f586a.add(view);
        }
    }

    public final void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        c.e(view, "child");
        view.getTag(R.id.fragment_container_view_tag);
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        f0 f0Var;
        c.e(windowInsets, "insets");
        f0 c2 = f0.c(windowInsets, (View) null);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f587c;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets onApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            c.d(onApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            f0Var = f0.c(onApplyWindowInsets, (View) null);
        } else {
            WeakHashMap weakHashMap = K.f1547a;
            WindowInsets b2 = c2.b();
            if (b2 != null) {
                WindowInsets b3 = C0180y.b(this, b2);
                if (!b3.equals(b2)) {
                    c2 = f0.c(b3, this);
                }
            }
            f0Var = c2;
        }
        if (!f0Var.f1584a.m()) {
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                WeakHashMap weakHashMap2 = K.f1547a;
                WindowInsets b4 = f0Var.b();
                if (b4 != null) {
                    WindowInsets a2 = C0180y.a(childAt, b4);
                    if (!a2.equals(b4)) {
                        f0.c(a2, childAt);
                    }
                }
            }
        }
        return windowInsets;
    }

    public final void dispatchDraw(Canvas canvas) {
        c.e(canvas, "canvas");
        if (this.f588d) {
            ArrayList arrayList = this.f586a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                super.drawChild(canvas, (View) obj, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    public final boolean drawChild(Canvas canvas, View view, long j2) {
        c.e(canvas, "canvas");
        c.e(view, "child");
        if (this.f588d) {
            ArrayList arrayList = this.f586a;
            if (!arrayList.isEmpty() && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j2);
    }

    public final void endViewTransition(View view) {
        c.e(view, "view");
        this.b.remove(view);
        if (this.f586a.remove(view)) {
            this.f588d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends d> F getFragment() {
        C0021i iVar;
        View view = this;
        while (view != null) {
            view.getTag(R.id.fragment_container_view_tag);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                view = (View) parent;
            } else {
                view = null;
            }
        }
        Context context = getContext();
        while (true) {
            if (!(context instanceof ContextWrapper)) {
                iVar = null;
                break;
            } else if (context instanceof C0021i) {
                iVar = (C0021i) context;
                break;
            } else {
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        if (iVar != null) {
            getId();
            ((f) iVar.f862r.b).f584c.g();
            return null;
        }
        throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
    }

    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        c.e(windowInsets, "insets");
        return windowInsets;
    }

    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 < childCount) {
                View childAt = getChildAt(childCount);
                c.d(childAt, "view");
                a(childAt);
            } else {
                super.removeAllViewsInLayout();
                return;
            }
        }
    }

    public final void removeView(View view) {
        c.e(view, "view");
        a(view);
        super.removeView(view);
    }

    public final void removeViewAt(int i2) {
        View childAt = getChildAt(i2);
        c.d(childAt, "view");
        a(childAt);
        super.removeViewAt(i2);
    }

    public final void removeViewInLayout(View view) {
        c.e(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    public final void removeViews(int i2, int i3) {
        int i4 = i2 + i3;
        for (int i5 = i2; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            c.d(childAt, "view");
            a(childAt);
        }
        super.removeViews(i2, i3);
    }

    public final void removeViewsInLayout(int i2, int i3) {
        int i4 = i2 + i3;
        for (int i5 = i2; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            c.d(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i2, i3);
    }

    public final void setDrawDisappearingViewsLast(boolean z2) {
        this.f588d = z2;
    }

    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        c.e(onApplyWindowInsetsListener, "listener");
        this.f587c = onApplyWindowInsetsListener;
    }

    public final void startViewTransition(View view) {
        c.e(view, "view");
        if (view.getParent() == this) {
            this.b.add(view);
        }
        super.startViewTransition(view);
    }
}
