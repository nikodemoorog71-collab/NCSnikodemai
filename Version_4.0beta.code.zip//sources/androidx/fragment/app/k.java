package androidx.fragment.app;

import androidx.activity.s;
import java.util.concurrent.CopyOnWriteArrayList;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public boolean f592a = false;
    public final CopyOnWriteArrayList b = new CopyOnWriteArrayList();

    /* renamed from: c  reason: collision with root package name */
    public s f593c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ p f594d;

    public k(p pVar) {
        this.f594d = pVar;
    }
}
