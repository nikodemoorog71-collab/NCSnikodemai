package androidx.fragment.app;

import androidx.lifecycle.l;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public int f645a;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public int f646c;

    /* renamed from: d  reason: collision with root package name */
    public int f647d;

    /* renamed from: e  reason: collision with root package name */
    public int f648e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public l f649g;

    /* renamed from: h  reason: collision with root package name */
    public l f650h;
}
