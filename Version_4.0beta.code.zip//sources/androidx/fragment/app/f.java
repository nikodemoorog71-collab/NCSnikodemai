package androidx.fragment.app;

import C.j;
import L.e;
import L.g;
import android.os.Handler;
import androidx.lifecycle.G;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import e.C0021i;

public final class f implements G, q, g {

    /* renamed from: a  reason: collision with root package name */
    public final C0021i f583a;
    public final Handler b;

    /* renamed from: c  reason: collision with root package name */
    public final p f584c = new p();

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ C0021i f585d;

    public f(C0021i iVar) {
        this.f585d = iVar;
        Handler handler = new Handler();
        this.f583a = iVar;
        this.b = handler;
    }

    public final e a() {
        return (e) this.f585d.f285e.f118c;
    }

    public final j b() {
        return this.f585d.b();
    }

    public final s c() {
        return this.f585d.f863s;
    }
}
