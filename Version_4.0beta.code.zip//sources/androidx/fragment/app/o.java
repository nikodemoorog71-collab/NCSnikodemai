package androidx.fragment.app;

import D.m;
import android.os.Parcel;
import android.os.Parcelable;

public final class o implements Parcelable {
    public static final Parcelable.Creator<o> CREATOR = new m(5);

    /* renamed from: a  reason: collision with root package name */
    public String f598a;
    public int b;

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f598a);
        parcel.writeInt(this.b);
    }
}
