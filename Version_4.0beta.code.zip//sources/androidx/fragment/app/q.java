package androidx.fragment.app;

import D.m;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

public final class q implements Parcelable {
    public static final Parcelable.Creator<q> CREATOR = new m(6);

    /* renamed from: a  reason: collision with root package name */
    public ArrayList f625a;
    public ArrayList b;

    /* renamed from: c  reason: collision with root package name */
    public b[] f626c;

    /* renamed from: d  reason: collision with root package name */
    public int f627d;

    /* renamed from: e  reason: collision with root package name */
    public String f628e;
    public ArrayList f;

    /* renamed from: g  reason: collision with root package name */
    public ArrayList f629g;

    /* renamed from: h  reason: collision with root package name */
    public ArrayList f630h;

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeStringList(this.f625a);
        parcel.writeStringList(this.b);
        parcel.writeTypedArray(this.f626c, i2);
        parcel.writeInt(this.f627d);
        parcel.writeString(this.f628e);
        parcel.writeStringList(this.f);
        parcel.writeTypedList(this.f629g);
        parcel.writeTypedList(this.f630h);
    }
}
