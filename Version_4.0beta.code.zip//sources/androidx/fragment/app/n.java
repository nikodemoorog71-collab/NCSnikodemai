package androidx.fragment.app;

import D.g;
import U.e;
import android.content.Intent;
import androidx.activity.result.a;
import java.util.ArrayList;
import java.util.Iterator;

public final class n extends g {

    /* renamed from: o  reason: collision with root package name */
    public final /* synthetic */ int f597o;

    public /* synthetic */ n(int i2) {
        this.f597o = i2;
    }

    public final Object J(int i2, Intent intent) {
        boolean z2;
        switch (this.f597o) {
            case 0:
                return new a(i2, intent);
            case 1:
                e eVar = e.f251a;
                if (i2 != -1 || intent == null) {
                    return eVar;
                }
                String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                if (intArrayExtra == null || stringArrayExtra == null) {
                    return eVar;
                }
                ArrayList arrayList = new ArrayList(intArrayExtra.length);
                for (int i3 : intArrayExtra) {
                    if (i3 == 0) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    arrayList.add(Boolean.valueOf(z2));
                }
                ArrayList arrayList2 = new ArrayList();
                for (String str : stringArrayExtra) {
                    if (str != null) {
                        arrayList2.add(str);
                    }
                }
                Iterator it = arrayList2.iterator();
                Iterator it2 = arrayList.iterator();
                ArrayList arrayList3 = new ArrayList(Math.min(arrayList2.size(), arrayList.size()));
                while (it.hasNext() && it2.hasNext()) {
                    arrayList3.add(new T.a(it.next(), it2.next()));
                }
                return U.g.V(arrayList3);
            default:
                return new a(i2, intent);
        }
    }
}
