package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

public final class u extends Writer implements AutoCloseable {

    /* renamed from: a  reason: collision with root package name */
    public final String f651a = "FragmentManager";
    public final StringBuilder b = new StringBuilder(128);

    public final void a() {
        StringBuilder sb = this.b;
        if (sb.length() > 0) {
            Log.d(this.f651a, sb.toString());
            sb.delete(0, sb.length());
        }
    }

    public final void close() {
        a();
    }

    public final void flush() {
        a();
    }

    public final void write(char[] cArr, int i2, int i3) {
        for (int i4 = 0; i4 < i3; i4++) {
            char c2 = cArr[i2 + i4];
            if (c2 == 10) {
                a();
            } else {
                this.b.append(c2);
            }
        }
    }
}
