package androidx.fragment.app;

import android.content.Intent;
import android.content.res.Configuration;
import e.C0021i;
import x.C0156a;

public final /* synthetic */ class e implements C0156a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f582a;
    public final /* synthetic */ C0021i b;

    public /* synthetic */ e(C0021i iVar, int i2) {
        this.f582a = i2;
        this.b = iVar;
    }

    public final void a(Object obj) {
        switch (this.f582a) {
            case 0:
                Configuration configuration = (Configuration) obj;
                this.b.f862r.x();
                return;
            default:
                Intent intent = (Intent) obj;
                this.b.f862r.x();
                return;
        }
    }
}
