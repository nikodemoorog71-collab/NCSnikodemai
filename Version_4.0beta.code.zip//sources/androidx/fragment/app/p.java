package androidx.fragment.app;

import C.h;
import D.b;
import K.d;
import android.os.Looper;
import android.util.Log;
import androidx.activity.t;
import androidx.lifecycle.l;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public final class p {

    /* renamed from: A  reason: collision with root package name */
    public r f599A;

    /* renamed from: B  reason: collision with root package name */
    public final b f600B;

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f601a = new ArrayList();
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public final h f602c = new h();

    /* renamed from: d  reason: collision with root package name */
    public ArrayList f603d;

    /* renamed from: e  reason: collision with root package name */
    public final h f604e = new h(this);
    public t f;

    /* renamed from: g  reason: collision with root package name */
    public final k f605g = new k(this);

    /* renamed from: h  reason: collision with root package name */
    public final AtomicInteger f606h = new AtomicInteger();

    /* renamed from: i  reason: collision with root package name */
    public final Map f607i = Collections.synchronizedMap(new HashMap());

    /* renamed from: j  reason: collision with root package name */
    public final Map f608j = Collections.synchronizedMap(new HashMap());

    /* renamed from: k  reason: collision with root package name */
    public final CopyOnWriteArrayList f609k;

    /* renamed from: l  reason: collision with root package name */
    public final i f610l;

    /* renamed from: m  reason: collision with root package name */
    public final i f611m;

    /* renamed from: n  reason: collision with root package name */
    public final i f612n;

    /* renamed from: o  reason: collision with root package name */
    public final i f613o;

    /* renamed from: p  reason: collision with root package name */
    public final l f614p;

    /* renamed from: q  reason: collision with root package name */
    public int f615q;

    /* renamed from: r  reason: collision with root package name */
    public f f616r;

    /* renamed from: s  reason: collision with root package name */
    public f f617s;

    /* renamed from: t  reason: collision with root package name */
    public final m f618t;

    /* renamed from: u  reason: collision with root package name */
    public ArrayDeque f619u;

    /* renamed from: v  reason: collision with root package name */
    public boolean f620v;

    /* renamed from: w  reason: collision with root package name */
    public boolean f621w;

    /* renamed from: x  reason: collision with root package name */
    public ArrayList f622x;

    /* renamed from: y  reason: collision with root package name */
    public ArrayList f623y;

    /* renamed from: z  reason: collision with root package name */
    public ArrayList f624z;

    public p() {
        Collections.synchronizedMap(new HashMap());
        new CopyOnWriteArrayList();
        this.f609k = new CopyOnWriteArrayList();
        this.f610l = new i(this, 0);
        this.f611m = new i(this, 1);
        this.f612n = new i(this, 2);
        this.f613o = new i(this, 3);
        this.f614p = new l(this);
        this.f615q = -1;
        this.f618t = new m(this);
        this.f619u = new ArrayDeque();
        this.f600B = new b(2, (Object) this);
    }

    public static boolean h(int i2) {
        if (Log.isLoggable("FragmentManager", i2)) {
            return true;
        }
        return false;
    }

    public final void a() {
        this.b = false;
        this.f623y.clear();
        this.f622x.clear();
    }

    public final HashSet b() {
        HashSet hashSet = new HashSet();
        Iterator it = this.f602c.i().iterator();
        if (!it.hasNext()) {
            return hashSet;
        }
        d.a(it.next());
        throw null;
    }

    /* JADX INFO: finally extract failed */
    public final void c(int i2) {
        try {
            this.b = true;
            for (Object obj : ((HashMap) this.f602c.b).values()) {
                if (obj != null) {
                    throw new ClassCastException();
                }
            }
            i(i2, false);
            Iterator it = b().iterator();
            if (!it.hasNext()) {
                this.b = false;
                e(true);
                return;
            }
            ((v) it.next()).a();
            throw null;
        } catch (Throwable th) {
            this.b = false;
            throw th;
        }
    }

    public final void d(boolean z2) {
        if (this.b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.f616r == null) {
            throw new IllegalStateException("FragmentManager has not been attached to a host.");
        } else if (Looper.myLooper() != this.f616r.b.getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        } else if (!z2 && (this.f620v || this.f621w)) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        } else if (this.f622x == null) {
            this.f622x = new ArrayList();
            this.f623y = new ArrayList();
        }
    }

    /* JADX INFO: finally extract failed */
    public final boolean e(boolean z2) {
        boolean z3;
        d(z2);
        boolean z4 = false;
        while (true) {
            ArrayList arrayList = this.f622x;
            ArrayList arrayList2 = this.f623y;
            synchronized (this.f601a) {
                if (this.f601a.isEmpty()) {
                    z3 = false;
                } else {
                    try {
                        int size = this.f601a.size();
                        int i2 = 0;
                        z3 = false;
                        while (i2 < size) {
                            ((a) this.f601a.get(i2)).c(arrayList, arrayList2);
                            i2++;
                            z3 = true;
                        }
                    } finally {
                        this.f601a.clear();
                        this.f616r.b.removeCallbacks(this.f600B);
                    }
                }
            }
            if (z3) {
                this.b = true;
                try {
                    j(this.f622x, this.f623y);
                    a();
                    z4 = true;
                } catch (Throwable th) {
                    a();
                    throw th;
                }
            } else {
                k();
                ((HashMap) this.f602c.b).values().removeAll(Collections.singleton((Object) null));
                return z4;
            }
        }
    }

    /* JADX WARNING: type inference failed for: r6v18, types: [androidx.fragment.app.t, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r9v8, types: [androidx.fragment.app.t, java.lang.Object] */
    public final void f(ArrayList arrayList, ArrayList arrayList2, int i2, int i3) {
        boolean z2;
        ArrayList arrayList3 = arrayList;
        ArrayList arrayList4 = arrayList2;
        int i4 = i2;
        int i5 = i3;
        boolean z3 = ((a) arrayList3.get(i4)).f566o;
        ArrayList arrayList5 = this.f624z;
        if (arrayList5 == null) {
            this.f624z = new ArrayList();
        } else {
            arrayList5.clear();
        }
        this.f624z.addAll(this.f602c.n());
        int i6 = i4;
        boolean z4 = false;
        while (true) {
            int i7 = 1;
            if (i6 < i5) {
                a aVar = (a) arrayList3.get(i6);
                int i8 = 3;
                if (!((Boolean) arrayList4.get(i6)).booleanValue()) {
                    ArrayList arrayList6 = this.f624z;
                    int i9 = 0;
                    while (true) {
                        ArrayList arrayList7 = aVar.f554a;
                        if (i9 < arrayList7.size()) {
                            t tVar = (t) arrayList7.get(i9);
                            int i10 = tVar.f645a;
                            if (i10 != i7) {
                                if (i10 == 2) {
                                    throw null;
                                } else if (i10 == i8 || i10 == 6) {
                                    arrayList6.remove((Object) null);
                                    ? obj = new Object();
                                    obj.f645a = 9;
                                    obj.b = false;
                                    l lVar = l.f675e;
                                    obj.f649g = lVar;
                                    obj.f650h = lVar;
                                    arrayList7.add(i9, obj);
                                    i9++;
                                    i7 = 1;
                                    i9++;
                                    i8 = 3;
                                } else if (i10 != 7) {
                                    if (i10 == 8) {
                                        ? obj2 = new Object();
                                        obj2.f645a = 9;
                                        obj2.b = true;
                                        l lVar2 = l.f675e;
                                        obj2.f649g = lVar2;
                                        obj2.f650h = lVar2;
                                        arrayList7.add(i9, obj2);
                                        tVar.b = true;
                                        i9++;
                                    }
                                    i7 = 1;
                                    i9++;
                                    i8 = 3;
                                }
                            }
                            arrayList6.add((Object) null);
                            i7 = 1;
                            i9++;
                            i8 = 3;
                        } else {
                            z2 = false;
                        }
                    }
                } else {
                    z2 = false;
                    ArrayList arrayList8 = this.f624z;
                    ArrayList arrayList9 = aVar.f554a;
                    int size = arrayList9.size() - 1;
                    while (size >= 0) {
                        t tVar2 = (t) arrayList9.get(size);
                        int i11 = tVar2.f645a;
                        if (i11 != i7) {
                            if (i11 != 3) {
                                switch (i11) {
                                    case 6:
                                        break;
                                    case 7:
                                        break;
                                    case 10:
                                        tVar2.f650h = tVar2.f649g;
                                        break;
                                }
                            }
                            arrayList8.add((Object) null);
                            size--;
                            i7 = 1;
                        }
                        arrayList8.remove((Object) null);
                        size--;
                        i7 = 1;
                    }
                }
                if (z4 || aVar.f558g) {
                    z4 = true;
                } else {
                    z4 = z2;
                }
                i6++;
            } else {
                this.f624z.clear();
                if (!z3 && this.f615q >= 1) {
                    for (int i12 = i4; i12 < i5; i12++) {
                        ArrayList arrayList10 = ((a) arrayList3.get(i12)).f554a;
                        int size2 = arrayList10.size();
                        int i13 = 0;
                        while (i13 < size2) {
                            Object obj3 = arrayList10.get(i13);
                            i13++;
                            ((t) obj3).getClass();
                        }
                    }
                }
                for (int i14 = i4; i14 < i5; i14++) {
                    a aVar2 = (a) arrayList3.get(i14);
                    if (((Boolean) arrayList4.get(i14)).booleanValue()) {
                        aVar2.a(-1);
                        ArrayList arrayList11 = aVar2.f554a;
                        for (int size3 = arrayList11.size() - 1; size3 >= 0; size3--) {
                            t tVar3 = (t) arrayList11.get(size3);
                            tVar3.getClass();
                            int i15 = tVar3.f645a;
                            p pVar = aVar2.f567p;
                            switch (i15) {
                                case 1:
                                    throw null;
                                case 3:
                                    throw null;
                                case 4:
                                    throw null;
                                case 5:
                                    throw null;
                                case 6:
                                    throw null;
                                case 7:
                                    throw null;
                                case 8:
                                    pVar.getClass();
                                    break;
                                case 9:
                                    pVar.getClass();
                                    break;
                                case 10:
                                    pVar.getClass();
                                    throw null;
                                default:
                                    throw new IllegalArgumentException("Unknown cmd: " + tVar3.f645a);
                            }
                        }
                        continue;
                    } else {
                        aVar2.a(1);
                        ArrayList arrayList12 = aVar2.f554a;
                        int size4 = arrayList12.size();
                        for (int i16 = 0; i16 < size4; i16++) {
                            t tVar4 = (t) arrayList12.get(i16);
                            tVar4.getClass();
                            int i17 = tVar4.f645a;
                            p pVar2 = aVar2.f567p;
                            switch (i17) {
                                case 1:
                                    throw null;
                                case 3:
                                    throw null;
                                case 4:
                                    throw null;
                                case 5:
                                    throw null;
                                case 6:
                                    throw null;
                                case 7:
                                    throw null;
                                case 8:
                                    pVar2.getClass();
                                    break;
                                case 9:
                                    pVar2.getClass();
                                    break;
                                case 10:
                                    pVar2.getClass();
                                    throw null;
                                default:
                                    throw new IllegalArgumentException("Unknown cmd: " + tVar4.f645a);
                            }
                        }
                        continue;
                    }
                }
                boolean booleanValue = ((Boolean) arrayList4.get(i5 - 1)).booleanValue();
                for (int i18 = i4; i18 < i5; i18++) {
                    a aVar3 = (a) arrayList3.get(i18);
                    if (booleanValue) {
                        for (int size5 = aVar3.f554a.size() - 1; size5 >= 0; size5--) {
                            ((t) aVar3.f554a.get(size5)).getClass();
                        }
                    } else {
                        ArrayList arrayList13 = aVar3.f554a;
                        int size6 = arrayList13.size();
                        int i19 = 0;
                        while (i19 < size6) {
                            Object obj4 = arrayList13.get(i19);
                            i19++;
                            ((t) obj4).getClass();
                        }
                    }
                }
                i(this.f615q, true);
                HashSet hashSet = new HashSet();
                for (int i20 = i4; i20 < i5; i20++) {
                    ArrayList arrayList14 = ((a) arrayList3.get(i20)).f554a;
                    int size7 = arrayList14.size();
                    int i21 = 0;
                    while (i21 < size7) {
                        Object obj5 = arrayList14.get(i21);
                        i21++;
                        ((t) obj5).getClass();
                    }
                }
                Iterator it = hashSet.iterator();
                if (!it.hasNext()) {
                    while (i4 < i5) {
                        a aVar4 = (a) arrayList3.get(i4);
                        if (((Boolean) arrayList4.get(i4)).booleanValue() && aVar4.f568q >= 0) {
                            aVar4.f568q = -1;
                        }
                        aVar4.getClass();
                        i4++;
                    }
                    return;
                }
                ((v) it.next()).getClass();
                throw null;
            }
        }
    }

    public final void g() {
        h hVar = this.f602c;
        ArrayList arrayList = (ArrayList) hVar.f6a;
        int size = arrayList.size() - 1;
        while (size >= 0) {
            if (arrayList.get(size) == null) {
                size--;
            } else {
                throw new ClassCastException();
            }
        }
        for (Object a2 : ((HashMap) hVar.b).values()) {
            d.a(a2);
        }
    }

    public final void i(int i2, boolean z2) {
        if (this.f616r == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        } else if (z2 || i2 != this.f615q) {
            this.f615q = i2;
            h hVar = this.f602c;
            Iterator it = ((ArrayList) hVar.f6a).iterator();
            if (!it.hasNext()) {
                for (Object obj : ((HashMap) hVar.b).values()) {
                    if (obj != null) {
                        throw new ClassCastException();
                    }
                }
                Iterator it2 = hVar.i().iterator();
                if (it2.hasNext()) {
                    it2.next().getClass();
                    throw new ClassCastException();
                }
                return;
            }
            it.next().getClass();
            throw new ClassCastException();
        }
    }

    public final void j(ArrayList arrayList, ArrayList arrayList2) {
        if (!arrayList.isEmpty()) {
            if (arrayList.size() == arrayList2.size()) {
                int size = arrayList.size();
                int i2 = 0;
                int i3 = 0;
                while (i2 < size) {
                    if (!((a) arrayList.get(i2)).f566o) {
                        if (i3 != i2) {
                            f(arrayList, arrayList2, i3, i2);
                        }
                        i3 = i2 + 1;
                        if (((Boolean) arrayList2.get(i2)).booleanValue()) {
                            while (i3 < size && ((Boolean) arrayList2.get(i3)).booleanValue() && !((a) arrayList.get(i3)).f566o) {
                                i3++;
                            }
                        }
                        f(arrayList, arrayList2, i2, i3);
                        i2 = i3 - 1;
                    }
                    i2++;
                }
                if (i3 != size) {
                    f(arrayList, arrayList2, i3, size);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Internal error with the back stack records");
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001c, code lost:
        r0 = r4.f605g;
        r1 = r4.f603d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0021, code lost:
        if (r1 == null) goto L_0x0028;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0023, code lost:
        r1 = r1.size();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0028, code lost:
        r1 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0029, code lost:
        if (r1 <= 0) goto L_0x002c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002c, code lost:
        r2 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x002d, code lost:
        r0.f592a = r2;
        r0 = r0.f593c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0031, code lost:
        if (r0 == null) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0033, code lost:
        r0.a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0018, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void k() {
        /*
            r4 = this;
            java.util.ArrayList r0 = r4.f601a
            monitor-enter(r0)
            java.util.ArrayList r1 = r4.f601a     // Catch:{ all -> 0x0019 }
            boolean r1 = r1.isEmpty()     // Catch:{ all -> 0x0019 }
            r2 = 1
            if (r1 != 0) goto L_0x001b
            androidx.fragment.app.k r1 = r4.f605g     // Catch:{ all -> 0x0019 }
            r1.f592a = r2     // Catch:{ all -> 0x0019 }
            androidx.activity.s r1 = r1.f593c     // Catch:{ all -> 0x0019 }
            if (r1 == 0) goto L_0x0017
            r1.a()     // Catch:{ all -> 0x0019 }
        L_0x0017:
            monitor-exit(r0)     // Catch:{ all -> 0x0019 }
            return
        L_0x0019:
            r1 = move-exception
            goto L_0x0037
        L_0x001b:
            monitor-exit(r0)     // Catch:{ all -> 0x0019 }
            androidx.fragment.app.k r0 = r4.f605g
            java.util.ArrayList r1 = r4.f603d
            r3 = 0
            if (r1 == 0) goto L_0x0028
            int r1 = r1.size()
            goto L_0x0029
        L_0x0028:
            r1 = r3
        L_0x0029:
            if (r1 <= 0) goto L_0x002c
            goto L_0x002d
        L_0x002c:
            r2 = r3
        L_0x002d:
            r0.f592a = r2
            androidx.activity.s r0 = r0.f593c
            if (r0 == 0) goto L_0x0036
            r0.a()
        L_0x0036:
            return
        L_0x0037:
            monitor-exit(r0)     // Catch:{ all -> 0x0019 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.p.k():void");
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        f fVar = this.f616r;
        if (fVar != null) {
            sb.append(fVar.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.f616r)));
            sb.append("}");
        } else {
            sb.append("null");
        }
        sb.append("}}");
        return sb.toString();
    }
}
