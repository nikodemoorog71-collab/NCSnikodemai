package androidx.fragment.app;

import H.a;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;

public final class h implements LayoutInflater.Factory2 {

    /* renamed from: a  reason: collision with root package name */
    public final p f589a;

    public h(p pVar) {
        this.f589a = pVar;
    }

    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z2;
        boolean equals = g.class.getName().equals(str);
        p pVar = this.f589a;
        if (equals) {
            return new g(context, attributeSet, pVar);
        }
        if ("fragment".equals(str)) {
            String attributeValue = attributeSet.getAttributeValue((String) null, "class");
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f72a);
            int i2 = 0;
            if (attributeValue == null) {
                attributeValue = obtainStyledAttributes.getString(0);
            }
            int resourceId = obtainStyledAttributes.getResourceId(1, -1);
            String string = obtainStyledAttributes.getString(2);
            obtainStyledAttributes.recycle();
            if (attributeValue != null) {
                try {
                    z2 = d.class.isAssignableFrom(m.b(context.getClassLoader(), attributeValue));
                } catch (ClassNotFoundException unused) {
                    z2 = false;
                }
                if (z2) {
                    if (view != null) {
                        i2 = view.getId();
                    }
                    if (i2 == -1 && resourceId == -1 && string == null) {
                        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
                    }
                    if (resourceId != -1) {
                        pVar.g();
                    }
                    if (string != null) {
                        C.h hVar = pVar.f602c;
                        ArrayList arrayList = (ArrayList) hVar.f6a;
                        int size = arrayList.size() - 1;
                        while (size >= 0) {
                            if (arrayList.get(size) == null) {
                                size--;
                            } else {
                                throw new ClassCastException();
                            }
                        }
                        for (Object obj : ((HashMap) hVar.b).values()) {
                            if (obj != null) {
                                throw new ClassCastException();
                            }
                        }
                    }
                    if (i2 != -1) {
                        pVar.g();
                    }
                    m mVar = pVar.f618t;
                    context.getClassLoader();
                    mVar.a(attributeValue);
                    throw null;
                }
            }
        }
        return null;
    }
}
