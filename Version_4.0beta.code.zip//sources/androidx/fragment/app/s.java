package androidx.fragment.app;

import D.m;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

public final class s implements Parcelable {
    public static final Parcelable.Creator<s> CREATOR = new m(7);

    /* renamed from: a  reason: collision with root package name */
    public final String f634a;
    public final String b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f635c;

    /* renamed from: d  reason: collision with root package name */
    public final int f636d;

    /* renamed from: e  reason: collision with root package name */
    public final int f637e;
    public final String f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f638g;

    /* renamed from: h  reason: collision with root package name */
    public final boolean f639h;

    /* renamed from: i  reason: collision with root package name */
    public final boolean f640i;

    /* renamed from: j  reason: collision with root package name */
    public final Bundle f641j;

    /* renamed from: k  reason: collision with root package name */
    public final boolean f642k;

    /* renamed from: l  reason: collision with root package name */
    public final int f643l;

    /* renamed from: m  reason: collision with root package name */
    public final Bundle f644m;

    public s(Parcel parcel) {
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        this.f634a = parcel.readString();
        this.b = parcel.readString();
        boolean z6 = false;
        if (parcel.readInt() != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        this.f635c = z2;
        this.f636d = parcel.readInt();
        this.f637e = parcel.readInt();
        this.f = parcel.readString();
        if (parcel.readInt() != 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        this.f638g = z3;
        if (parcel.readInt() != 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        this.f639h = z4;
        if (parcel.readInt() != 0) {
            z5 = true;
        } else {
            z5 = false;
        }
        this.f640i = z5;
        this.f641j = parcel.readBundle();
        this.f642k = parcel.readInt() != 0 ? true : z6;
        this.f644m = parcel.readBundle();
        this.f643l = parcel.readInt();
    }

    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f634a);
        sb.append(" (");
        sb.append(this.b);
        sb.append(")}:");
        if (this.f635c) {
            sb.append(" fromLayout");
        }
        int i2 = this.f637e;
        if (i2 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i2));
        }
        String str = this.f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(str);
        }
        if (this.f638g) {
            sb.append(" retainInstance");
        }
        if (this.f639h) {
            sb.append(" removing");
        }
        if (this.f640i) {
            sb.append(" detached");
        }
        if (this.f642k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f634a);
        parcel.writeString(this.b);
        parcel.writeInt(this.f635c ? 1 : 0);
        parcel.writeInt(this.f636d);
        parcel.writeInt(this.f637e);
        parcel.writeString(this.f);
        parcel.writeInt(this.f638g ? 1 : 0);
        parcel.writeInt(this.f639h ? 1 : 0);
        parcel.writeInt(this.f640i ? 1 : 0);
        parcel.writeBundle(this.f641j);
        parcel.writeInt(this.f642k ? 1 : 0);
        parcel.writeBundle(this.f644m);
        parcel.writeInt(this.f643l);
    }
}
