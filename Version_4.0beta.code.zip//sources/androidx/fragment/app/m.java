package androidx.fragment.app;

import java.lang.reflect.InvocationTargetException;
import l.k;

public final class m {
    public static final k b = new k();

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ p f596a;

    public m(p pVar) {
        this.f596a = pVar;
    }

    public static Class b(ClassLoader classLoader, String str) {
        k kVar = b;
        k kVar2 = (k) kVar.getOrDefault(classLoader, (Object) null);
        if (kVar2 == null) {
            kVar2 = new k();
            kVar.put(classLoader, kVar2);
        }
        Class cls = (Class) kVar2.getOrDefault(str, (Object) null);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        kVar2.put(str, cls2);
        return cls2;
    }

    public static Class c(ClassLoader classLoader, String str) {
        try {
            return b(classLoader, str);
        } catch (ClassNotFoundException e2) {
            throw new RuntimeException("Unable to instantiate fragment " + str + ": make sure class name exists", e2);
        } catch (ClassCastException e3) {
            throw new RuntimeException("Unable to instantiate fragment " + str + ": make sure class is a valid subclass of Fragment", e3);
        }
    }

    public final void a(String str) {
        try {
            if (c(this.f596a.f616r.f583a.getClassLoader(), str).getConstructor((Class[]) null).newInstance((Object[]) null) != null) {
                throw new ClassCastException();
            }
        } catch (InstantiationException e2) {
            throw new RuntimeException("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (IllegalAccessException e3) {
            throw new RuntimeException("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new RuntimeException("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new RuntimeException("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }
}
