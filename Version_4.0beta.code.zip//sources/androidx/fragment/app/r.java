package androidx.fragment.app;

import F.d;
import android.util.Log;
import androidx.lifecycle.E;
import java.util.HashMap;
import java.util.Iterator;

public final class r extends E {
    public static final d f = new d(19);

    /* renamed from: c  reason: collision with root package name */
    public final HashMap f631c = new HashMap();

    /* renamed from: d  reason: collision with root package name */
    public final HashMap f632d = new HashMap();

    /* renamed from: e  reason: collision with root package name */
    public final HashMap f633e = new HashMap();

    public r(boolean z2) {
    }

    public final void a() {
        if (p.h(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && r.class == obj.getClass()) {
            r rVar = (r) obj;
            if (!this.f631c.equals(rVar.f631c) || !this.f632d.equals(rVar.f632d) || !this.f633e.equals(rVar.f633e)) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int hashCode = this.f632d.hashCode();
        return this.f633e.hashCode() + ((hashCode + (this.f631c.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.f631c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.f632d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.f633e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
