package androidx.fragment.app;

import android.util.Log;
import java.io.PrintWriter;
import java.util.ArrayList;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f554a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public int f555c;

    /* renamed from: d  reason: collision with root package name */
    public int f556d;

    /* renamed from: e  reason: collision with root package name */
    public int f557e;
    public int f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f558g;

    /* renamed from: h  reason: collision with root package name */
    public String f559h;

    /* renamed from: i  reason: collision with root package name */
    public int f560i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f561j;

    /* renamed from: k  reason: collision with root package name */
    public int f562k;

    /* renamed from: l  reason: collision with root package name */
    public CharSequence f563l;

    /* renamed from: m  reason: collision with root package name */
    public ArrayList f564m;

    /* renamed from: n  reason: collision with root package name */
    public ArrayList f565n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f566o;

    /* renamed from: p  reason: collision with root package name */
    public final p f567p;

    /* renamed from: q  reason: collision with root package name */
    public int f568q;

    public a(p pVar) {
        m mVar = pVar.f618t;
        f fVar = pVar.f616r;
        if (fVar != null) {
            fVar.f583a.getClassLoader();
        }
        this.f554a = new ArrayList();
        this.f566o = false;
        this.f568q = -1;
        this.f567p = pVar;
    }

    public final void a(int i2) {
        if (this.f558g) {
            if (p.h(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            ArrayList arrayList = this.f554a;
            int size = arrayList.size();
            for (int i3 = 0; i3 < size; i3++) {
                ((t) arrayList.get(i3)).getClass();
            }
        }
    }

    public final void b(String str, PrintWriter printWriter, boolean z2) {
        String str2;
        if (z2) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f559h);
            printWriter.print(" mIndex=");
            printWriter.print(this.f568q);
            printWriter.print(" mCommitted=");
            printWriter.println(false);
            if (this.f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f));
            }
            if (!(this.b == 0 && this.f555c == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f555c));
            }
            if (!(this.f556d == 0 && this.f557e == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f556d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f557e));
            }
            if (!(this.f560i == 0 && this.f561j == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f560i));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f561j);
            }
            if (!(this.f562k == 0 && this.f563l == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f562k));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f563l);
            }
        }
        ArrayList arrayList = this.f554a;
        if (!arrayList.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                t tVar = (t) arrayList.get(i2);
                switch (tVar.f645a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        str2 = "cmd=" + tVar.f645a;
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println((Object) null);
                if (z2) {
                    if (!(tVar.f646c == 0 && tVar.f647d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(tVar.f646c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(tVar.f647d));
                    }
                    if (tVar.f648e != 0 || tVar.f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(tVar.f648e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(tVar.f));
                    }
                }
            }
        }
    }

    public final void c(ArrayList arrayList, ArrayList arrayList2) {
        if (p.h(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (this.f558g) {
            p pVar = this.f567p;
            if (pVar.f603d == null) {
                pVar.f603d = new ArrayList();
            }
            pVar.f603d.add(this);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f568q >= 0) {
            sb.append(" #");
            sb.append(this.f568q);
        }
        if (this.f559h != null) {
            sb.append(" ");
            sb.append(this.f559h);
        }
        sb.append("}");
        return sb.toString();
    }
}
