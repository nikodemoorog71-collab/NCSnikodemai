package androidx.fragment.app;

import android.util.Log;
import androidx.activity.result.a;
import java.util.ArrayList;
import java.util.Map;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f591a;
    public final /* synthetic */ p b;

    public /* synthetic */ j(p pVar, int i2) {
        this.f591a = i2;
        this.b = pVar;
    }

    public final void a(Object obj) {
        int i2;
        switch (this.f591a) {
            case 0:
                Map map = (Map) obj;
                String[] strArr = (String[]) map.keySet().toArray(new String[0]);
                ArrayList arrayList = new ArrayList(map.values());
                int[] iArr = new int[arrayList.size()];
                for (int i3 = 0; i3 < arrayList.size(); i3++) {
                    if (((Boolean) arrayList.get(i3)).booleanValue()) {
                        i2 = 0;
                    } else {
                        i2 = -1;
                    }
                    iArr[i3] = i2;
                }
                p pVar = this.b;
                o oVar = (o) pVar.f619u.pollFirst();
                if (oVar == null) {
                    Log.w("FragmentManager", "No permissions were requested for " + this);
                    return;
                }
                String str = oVar.f598a;
                pVar.f602c.g();
                Log.w("FragmentManager", "Permission request result delivered for unknown Fragment " + str);
                return;
            case 1:
                a aVar = (a) obj;
                p pVar2 = this.b;
                o oVar2 = (o) pVar2.f619u.pollFirst();
                if (oVar2 == null) {
                    Log.w("FragmentManager", "No Activities were started for result for " + this);
                    return;
                }
                String str2 = oVar2.f598a;
                pVar2.f602c.g();
                Log.w("FragmentManager", "Activity result delivered for unknown Fragment " + str2);
                return;
            default:
                a aVar2 = (a) obj;
                p pVar3 = this.b;
                o oVar3 = (o) pVar3.f619u.pollFirst();
                if (oVar3 == null) {
                    Log.w("FragmentManager", "No IntentSenders were started for " + this);
                    return;
                }
                String str3 = oVar3.f598a;
                pVar3.f602c.g();
                Log.w("FragmentManager", "Intent Sender result delivered for unknown Fragment " + str3);
                return;
        }
    }
}
