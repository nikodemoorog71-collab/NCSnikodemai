package androidx.fragment.app;

import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;

class Fragment$6 implements o {
    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_STOP) {
            throw null;
        }
    }
}
