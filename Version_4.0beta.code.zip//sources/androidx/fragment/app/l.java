package androidx.fragment.app;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ p f595a;

    public l(p pVar) {
        this.f595a = pVar;
    }
}
