package androidx.fragment.app;

import D.m;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

public final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new m(3);

    /* renamed from: a  reason: collision with root package name */
    public final int[] f569a;
    public final ArrayList b;

    /* renamed from: c  reason: collision with root package name */
    public final int[] f570c;

    /* renamed from: d  reason: collision with root package name */
    public final int[] f571d;

    /* renamed from: e  reason: collision with root package name */
    public final int f572e;
    public final String f;

    /* renamed from: g  reason: collision with root package name */
    public final int f573g;

    /* renamed from: h  reason: collision with root package name */
    public final int f574h;

    /* renamed from: i  reason: collision with root package name */
    public final CharSequence f575i;

    /* renamed from: j  reason: collision with root package name */
    public final int f576j;

    /* renamed from: k  reason: collision with root package name */
    public final CharSequence f577k;

    /* renamed from: l  reason: collision with root package name */
    public final ArrayList f578l;

    /* renamed from: m  reason: collision with root package name */
    public final ArrayList f579m;

    /* renamed from: n  reason: collision with root package name */
    public final boolean f580n;

    public b(a aVar) {
        int size = aVar.f554a.size();
        this.f569a = new int[(size * 6)];
        if (aVar.f558g) {
            this.b = new ArrayList(size);
            this.f570c = new int[size];
            this.f571d = new int[size];
            int i2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                t tVar = (t) aVar.f554a.get(i3);
                this.f569a[i2] = tVar.f645a;
                this.b.add((Object) null);
                int[] iArr = this.f569a;
                iArr[i2 + 1] = tVar.b;
                iArr[i2 + 2] = tVar.f646c;
                iArr[i2 + 3] = tVar.f647d;
                int i4 = i2 + 5;
                iArr[i2 + 4] = tVar.f648e;
                i2 += 6;
                iArr[i4] = tVar.f;
                this.f570c[i3] = tVar.f649g.ordinal();
                this.f571d[i3] = tVar.f650h.ordinal();
            }
            this.f572e = aVar.f;
            this.f = aVar.f559h;
            this.f573g = aVar.f568q;
            this.f574h = aVar.f560i;
            this.f575i = aVar.f561j;
            this.f576j = aVar.f562k;
            this.f577k = aVar.f563l;
            this.f578l = aVar.f564m;
            this.f579m = aVar.f565n;
            this.f580n = aVar.f566o;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f569a);
        parcel.writeStringList(this.b);
        parcel.writeIntArray(this.f570c);
        parcel.writeIntArray(this.f571d);
        parcel.writeInt(this.f572e);
        parcel.writeString(this.f);
        parcel.writeInt(this.f573g);
        parcel.writeInt(this.f574h);
        TextUtils.writeToParcel(this.f575i, parcel, 0);
        parcel.writeInt(this.f576j);
        TextUtils.writeToParcel(this.f577k, parcel, 0);
        parcel.writeStringList(this.f578l);
        parcel.writeStringList(this.f579m);
        parcel.writeInt(this.f580n ? 1 : 0);
    }

    public b(Parcel parcel) {
        this.f569a = parcel.createIntArray();
        this.b = parcel.createStringArrayList();
        this.f570c = parcel.createIntArray();
        this.f571d = parcel.createIntArray();
        this.f572e = parcel.readInt();
        this.f = parcel.readString();
        this.f573g = parcel.readInt();
        this.f574h = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f575i = (CharSequence) creator.createFromParcel(parcel);
        this.f576j = parcel.readInt();
        this.f577k = (CharSequence) creator.createFromParcel(parcel);
        this.f578l = parcel.createStringArrayList();
        this.f579m = parcel.createStringArrayList();
        this.f580n = parcel.readInt() != 0;
    }
}
