package androidx.savedstate;

import C.j;
import L.a;
import L.c;
import L.e;
import L.g;
import android.os.Bundle;
import androidx.lifecycle.E;
import androidx.lifecycle.G;
import androidx.lifecycle.SavedStateHandleController;
import androidx.lifecycle.h;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

public final class Recreator implements o {

    /* renamed from: a  reason: collision with root package name */
    public final Object f692a;

    public Recreator(g gVar) {
        this.f692a = gVar;
    }

    /* JADX WARNING: type inference failed for: r13v3, types: [L.g, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v2, types: [L.g, androidx.lifecycle.q, java.lang.Object] */
    public final void b(q qVar, k kVar) {
        Object obj;
        boolean z2;
        if (kVar == k.ON_CREATE) {
            qVar.c().f(this);
            Bundle c2 = this.f692a.a().c("androidx.savedstate.Restarter");
            if (c2 != null) {
                ArrayList<String> stringArrayList = c2.getStringArrayList("classes_to_restore");
                if (stringArrayList != null) {
                    int size = stringArrayList.size();
                    int i2 = 0;
                    while (i2 < size) {
                        String str = stringArrayList.get(i2);
                        i2++;
                        String str2 = str;
                        try {
                            Class<? extends U> asSubclass = Class.forName(str2, false, Recreator.class.getClassLoader()).asSubclass(c.class);
                            a0.c.d(asSubclass, "{\n                Class.…class.java)\n            }");
                            try {
                                Constructor<? extends U> declaredConstructor = asSubclass.getDeclaredConstructor((Class[]) null);
                                declaredConstructor.setAccessible(true);
                                try {
                                    Object newInstance = declaredConstructor.newInstance((Object[]) null);
                                    a0.c.d(newInstance, "{\n                constr…wInstance()\n            }");
                                    c cVar = (c) newInstance;
                                    ? r2 = this.f692a;
                                    if (r2 instanceof G) {
                                        j b = r2.b();
                                        e a2 = r2.a();
                                        b.getClass();
                                        Iterator it = new HashSet(((LinkedHashMap) b.b).keySet()).iterator();
                                        while (it.hasNext()) {
                                            String str3 = (String) it.next();
                                            a0.c.e(str3, "key");
                                            E e2 = (E) ((LinkedHashMap) b.b).get(str3);
                                            a0.c.b(e2);
                                            s c3 = r2.c();
                                            a0.c.e(a2, "registry");
                                            a0.c.e(c3, "lifecycle");
                                            HashMap hashMap = e2.f661a;
                                            if (hashMap == null) {
                                                obj = null;
                                            } else {
                                                synchronized (hashMap) {
                                                    obj = e2.f661a.get("androidx.lifecycle.savedstate.vm.tag");
                                                }
                                            }
                                            SavedStateHandleController savedStateHandleController = (SavedStateHandleController) obj;
                                            if (savedStateHandleController != null && !(z2 = savedStateHandleController.f665a)) {
                                                if (z2) {
                                                    throw new IllegalStateException("Already attached to lifecycleOwner");
                                                }
                                                savedStateHandleController.f665a = true;
                                                c3.a(savedStateHandleController);
                                                throw null;
                                            }
                                        }
                                        if (!new HashSet(((LinkedHashMap) b.b).keySet()).isEmpty()) {
                                            Class<h> cls = h.class;
                                            if (a2.f114c) {
                                                a aVar = (a) a2.f;
                                                if (aVar == null) {
                                                    aVar = new a(a2);
                                                }
                                                a2.f = aVar;
                                                try {
                                                    cls.getDeclaredConstructor((Class[]) null);
                                                    a aVar2 = (a) a2.f;
                                                    if (aVar2 != null) {
                                                        ((LinkedHashSet) aVar2.b).add(cls.getName());
                                                    }
                                                } catch (NoSuchMethodException e3) {
                                                    throw new IllegalArgumentException("Class " + cls.getSimpleName() + " must have default constructor in order to be automatically recreated", e3);
                                                }
                                            } else {
                                                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
                                            }
                                        }
                                    } else {
                                        throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
                                    }
                                } catch (Exception e4) {
                                    throw new RuntimeException("Failed to instantiate " + str2, e4);
                                }
                            } catch (NoSuchMethodException e5) {
                                throw new IllegalStateException("Class " + asSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e5);
                            }
                        } catch (ClassNotFoundException e6) {
                            throw new RuntimeException("Class " + str2 + " wasn't found", e6);
                        }
                    }
                    return;
                }
                throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
            }
            return;
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
