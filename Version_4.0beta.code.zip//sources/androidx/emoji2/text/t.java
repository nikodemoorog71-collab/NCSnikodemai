package androidx.emoji2.text;

import android.util.SparseArray;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public final SparseArray f543a;
    public w b;

    public t(int i2) {
        this.f543a = new SparseArray(i2);
    }

    public final void a(w wVar, int i2, int i3) {
        t tVar;
        int a2 = wVar.a(i2);
        SparseArray sparseArray = this.f543a;
        if (sparseArray == null) {
            tVar = null;
        } else {
            tVar = (t) sparseArray.get(a2);
        }
        if (tVar == null) {
            tVar = new t(1);
            sparseArray.put(wVar.a(i2), tVar);
        }
        if (i3 > i2) {
            tVar.a(wVar, i2 + 1, i3);
        } else {
            tVar.b = wVar;
        }
    }
}
