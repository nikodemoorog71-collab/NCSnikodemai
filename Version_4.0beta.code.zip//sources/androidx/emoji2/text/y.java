package androidx.emoji2.text;

import F.d;

public final class y extends d {
    public final boolean g(CharSequence charSequence) {
        if (!b.p(charSequence)) {
            return false;
        }
        return true;
    }
}
