package androidx.emoji2.text;

import D.g;
import F.d;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import l.C0107c;

public final class k {

    /* renamed from: j  reason: collision with root package name */
    public static final Object f517j = new Object();

    /* renamed from: k  reason: collision with root package name */
    public static volatile k f518k;

    /* renamed from: a  reason: collision with root package name */
    public final ReentrantReadWriteLock f519a;
    public final C0107c b;

    /* renamed from: c  reason: collision with root package name */
    public volatile int f520c = 3;

    /* renamed from: d  reason: collision with root package name */
    public final Handler f521d;

    /* renamed from: e  reason: collision with root package name */
    public final g f522e;
    public final j f;

    /* renamed from: g  reason: collision with root package name */
    public final d f523g;

    /* renamed from: h  reason: collision with root package name */
    public final int f524h;

    /* renamed from: i  reason: collision with root package name */
    public final e f525i;

    public k(s sVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.f519a = reentrantReadWriteLock;
        j jVar = sVar.f541a;
        this.f = jVar;
        int i2 = sVar.b;
        this.f524h = i2;
        this.f525i = sVar.f542c;
        this.f521d = new Handler(Looper.getMainLooper());
        this.b = new C0107c(0);
        this.f523g = new d(16);
        g gVar = new g(this);
        this.f522e = gVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i2 == 0) {
            try {
                this.f520c = 0;
            } catch (Throwable th) {
                this.f519a.writeLock().unlock();
                throw th;
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                jVar.p(new f(gVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public static k a() {
        k kVar;
        boolean z2;
        synchronized (f517j) {
            try {
                kVar = f518k;
                if (kVar != null) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (!z2) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return kVar;
    }

    public final int b() {
        this.f519a.readLock().lock();
        try {
            return this.f520c;
        } finally {
            this.f519a.readLock().unlock();
        }
    }

    public final void c() {
        boolean z2;
        if (this.f524h == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (!z2) {
            throw new IllegalStateException("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        } else if (b() != 1) {
            this.f519a.writeLock().lock();
            try {
                if (this.f520c != 0) {
                    this.f520c = 0;
                    this.f519a.writeLock().unlock();
                    g gVar = this.f522e;
                    k kVar = gVar.f514a;
                    try {
                        kVar.f.p(new f(gVar));
                    } catch (Throwable th) {
                        kVar.d(th);
                    }
                }
            } finally {
                this.f519a.writeLock().unlock();
            }
        }
    }

    /* JADX INFO: finally extract failed */
    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f519a.writeLock().lock();
        try {
            this.f520c = 2;
            arrayList.addAll(this.b);
            this.b.clear();
            this.f519a.writeLock().unlock();
            this.f521d.post(new i(arrayList, this.f520c, th));
        } catch (Throwable th2) {
            this.f519a.writeLock().unlock();
            throw th2;
        }
    }

    /* JADX WARNING: type inference failed for: r0v11, types: [androidx.emoji2.text.z, java.lang.Object] */
    /* JADX WARNING: Removed duplicated region for block: B:106:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0086 A[SYNTHETIC, Splitter:B:47:0x0086] */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00b8 A[SYNTHETIC, Splitter:B:61:0x00b8] */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x00fa  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.CharSequence e(java.lang.CharSequence r11, int r12, int r13) {
        /*
            r10 = this;
            int r0 = r10.b()
            r1 = 0
            r2 = 1
            if (r0 != r2) goto L_0x000a
            r0 = r2
            goto L_0x000b
        L_0x000a:
            r0 = r1
        L_0x000b:
            if (r0 == 0) goto L_0x012a
            if (r12 < 0) goto L_0x0122
            if (r13 < 0) goto L_0x011a
            if (r12 > r13) goto L_0x0015
            r0 = r2
            goto L_0x0016
        L_0x0015:
            r0 = r1
        L_0x0016:
            if (r0 == 0) goto L_0x0112
            r0 = 0
            if (r11 != 0) goto L_0x001c
            return r0
        L_0x001c:
            int r3 = r11.length()
            if (r12 > r3) goto L_0x0024
            r3 = r2
            goto L_0x0025
        L_0x0024:
            r3 = r1
        L_0x0025:
            if (r3 == 0) goto L_0x010a
            int r3 = r11.length()
            if (r13 > r3) goto L_0x002e
            goto L_0x002f
        L_0x002e:
            r2 = r1
        L_0x002f:
            if (r2 == 0) goto L_0x0102
            int r2 = r11.length()
            if (r2 == 0) goto L_0x0039
            if (r12 != r13) goto L_0x003c
        L_0x0039:
            r4 = r11
            goto L_0x0101
        L_0x003c:
            androidx.emoji2.text.g r2 = r10.f522e
            C.h r3 = r2.b
            r3.getClass()
            boolean r2 = r11 instanceof androidx.emoji2.text.v
            if (r2 == 0) goto L_0x004d
            r4 = r11
            androidx.emoji2.text.v r4 = (androidx.emoji2.text.v) r4
            r4.a()
        L_0x004d:
            java.lang.Class<androidx.emoji2.text.x> r4 = androidx.emoji2.text.x.class
            if (r2 != 0) goto L_0x007c
            boolean r5 = r11 instanceof android.text.Spannable     // Catch:{ all -> 0x0079 }
            if (r5 == 0) goto L_0x0056
            goto L_0x007c
        L_0x0056:
            boolean r5 = r11 instanceof android.text.Spanned     // Catch:{ all -> 0x0079 }
            if (r5 == 0) goto L_0x0084
            r5 = r11
            android.text.Spanned r5 = (android.text.Spanned) r5     // Catch:{ all -> 0x0079 }
            int r6 = r12 + -1
            int r7 = r13 + 1
            int r5 = r5.nextSpanTransition(r6, r7, r4)     // Catch:{ all -> 0x0079 }
            if (r5 > r13) goto L_0x0084
            androidx.emoji2.text.z r0 = new androidx.emoji2.text.z     // Catch:{ all -> 0x0079 }
            r0.<init>()     // Catch:{ all -> 0x0079 }
            r0.f553a = r1     // Catch:{ all -> 0x0079 }
            android.text.SpannableString r5 = new android.text.SpannableString     // Catch:{ all -> 0x0079 }
            r5.<init>(r11)     // Catch:{ all -> 0x0079 }
            r0.b = r5     // Catch:{ all -> 0x0079 }
            goto L_0x0084
        L_0x0076:
            r4 = r11
            goto L_0x00f8
        L_0x0079:
            r0 = move-exception
            r12 = r0
            goto L_0x0076
        L_0x007c:
            androidx.emoji2.text.z r0 = new androidx.emoji2.text.z     // Catch:{ all -> 0x00ed }
            r5 = r11
            android.text.Spannable r5 = (android.text.Spannable) r5     // Catch:{ all -> 0x00ed }
            r0.<init>(r5)     // Catch:{ all -> 0x00ed }
        L_0x0084:
            if (r0 == 0) goto L_0x00b4
            android.text.Spannable r5 = r0.b     // Catch:{ all -> 0x0079 }
            java.lang.Object[] r4 = r5.getSpans(r12, r13, r4)     // Catch:{ all -> 0x0079 }
            androidx.emoji2.text.x[] r4 = (androidx.emoji2.text.x[]) r4     // Catch:{ all -> 0x0079 }
            if (r4 == 0) goto L_0x00b4
            int r5 = r4.length     // Catch:{ all -> 0x0079 }
            if (r5 <= 0) goto L_0x00b4
            int r5 = r4.length     // Catch:{ all -> 0x0079 }
        L_0x0094:
            if (r1 >= r5) goto L_0x00b4
            r6 = r4[r1]     // Catch:{ all -> 0x0079 }
            android.text.Spannable r7 = r0.b     // Catch:{ all -> 0x0079 }
            int r7 = r7.getSpanStart(r6)     // Catch:{ all -> 0x0079 }
            android.text.Spannable r8 = r0.b     // Catch:{ all -> 0x0079 }
            int r8 = r8.getSpanEnd(r6)     // Catch:{ all -> 0x0079 }
            if (r7 == r13) goto L_0x00a9
            r0.removeSpan(r6)     // Catch:{ all -> 0x0079 }
        L_0x00a9:
            int r12 = java.lang.Math.min(r7, r12)     // Catch:{ all -> 0x0079 }
            int r13 = java.lang.Math.max(r8, r13)     // Catch:{ all -> 0x0079 }
            int r1 = r1 + 1
            goto L_0x0094
        L_0x00b4:
            r5 = r12
            r6 = r13
            if (r5 == r6) goto L_0x00be
            int r12 = r11.length()     // Catch:{ all -> 0x00ed }
            if (r5 < r12) goto L_0x00c0
        L_0x00be:
            r4 = r11
            goto L_0x00f5
        L_0x00c0:
            G.a r9 = new G.a     // Catch:{ all -> 0x00ed }
            java.lang.Object r12 = r3.f6a     // Catch:{ all -> 0x00f0 }
            F.d r12 = (F.d) r12     // Catch:{ all -> 0x00f0 }
            r9.<init>((java.lang.Object) r0, (java.lang.Object) r12)     // Catch:{ all -> 0x00ed }
            r8 = 0
            r7 = 2147483647(0x7fffffff, float:NaN)
            r4 = r11
            java.lang.Object r11 = r3.q(r4, r5, r6, r7, r8, r9)     // Catch:{ all -> 0x00ea }
            androidx.emoji2.text.z r11 = (androidx.emoji2.text.z) r11     // Catch:{ all -> 0x00ea }
            if (r11 == 0) goto L_0x00e1
            android.text.Spannable r11 = r11.b     // Catch:{ all -> 0x00ea }
            if (r2 == 0) goto L_0x00e0
            r12 = r4
            androidx.emoji2.text.v r12 = (androidx.emoji2.text.v) r12
            r12.b()
        L_0x00e0:
            return r11
        L_0x00e1:
            if (r2 == 0) goto L_0x0101
        L_0x00e3:
            r11 = r4
            androidx.emoji2.text.v r11 = (androidx.emoji2.text.v) r11
            r11.b()
            return r4
        L_0x00ea:
            r0 = move-exception
        L_0x00eb:
            r12 = r0
            goto L_0x00f8
        L_0x00ed:
            r0 = move-exception
            r4 = r11
            goto L_0x00eb
        L_0x00f0:
            r0 = move-exception
            r4 = r11
            r11 = r0
            r12 = r11
            goto L_0x00f8
        L_0x00f5:
            if (r2 == 0) goto L_0x0101
            goto L_0x00e3
        L_0x00f8:
            if (r2 == 0) goto L_0x0100
            r11 = r4
            androidx.emoji2.text.v r11 = (androidx.emoji2.text.v) r11
            r11.b()
        L_0x0100:
            throw r12
        L_0x0101:
            return r4
        L_0x0102:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.String r12 = "end should be < than charSequence length"
            r11.<init>(r12)
            throw r11
        L_0x010a:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.String r12 = "start should be < than charSequence length"
            r11.<init>(r12)
            throw r11
        L_0x0112:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.String r12 = "start should be <= than end"
            r11.<init>(r12)
            throw r11
        L_0x011a:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.String r12 = "end cannot be negative"
            r11.<init>(r12)
            throw r11
        L_0x0122:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.String r12 = "start cannot be negative"
            r11.<init>(r12)
            throw r11
        L_0x012a:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r12 = "Not initialized yet"
            r11.<init>(r12)
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.emoji2.text.k.e(java.lang.CharSequence, int, int):java.lang.CharSequence");
    }

    public final void f(h hVar) {
        g.d(hVar, "initCallback cannot be null");
        this.f519a.writeLock().lock();
        try {
            if (this.f520c != 1) {
                if (this.f520c != 2) {
                    this.b.add(hVar);
                }
            }
            this.f521d.post(new i(Arrays.asList(new h[]{hVar}), this.f520c, (Throwable) null));
        } finally {
            this.f519a.writeLock().unlock();
        }
    }
}
