package androidx.emoji2.text;

public interface p {
    boolean c(CharSequence charSequence, int i2, int i3, w wVar);

    Object i();
}
