package androidx.emoji2.text;

import D.g;
import S.d;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import androidx.activity.c;
import e.C0018f;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import v.C0154b;

public final class r implements j {

    /* renamed from: a  reason: collision with root package name */
    public final Context f534a;
    public final d b;

    /* renamed from: c  reason: collision with root package name */
    public final F.d f535c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f536d = new Object();

    /* renamed from: e  reason: collision with root package name */
    public Handler f537e;
    public ThreadPoolExecutor f;

    /* renamed from: g  reason: collision with root package name */
    public ThreadPoolExecutor f538g;

    /* renamed from: h  reason: collision with root package name */
    public g f539h;

    public r(Context context, d dVar) {
        F.d dVar2 = s.f540d;
        g.d(context, "Context cannot be null");
        this.f534a = context.getApplicationContext();
        this.b = dVar;
        this.f535c = dVar2;
    }

    public final void a() {
        synchronized (this.f536d) {
            try {
                this.f539h = null;
                Handler handler = this.f537e;
                if (handler != null) {
                    handler.removeCallbacks((Runnable) null);
                }
                this.f537e = null;
                ThreadPoolExecutor threadPoolExecutor = this.f538g;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f = null;
                this.f538g = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final v.g b() {
        try {
            F.d dVar = this.f535c;
            Context context = this.f534a;
            d dVar2 = this.b;
            dVar.getClass();
            C0018f a2 = C0154b.a(context, dVar2);
            int i2 = a2.f856a;
            if (i2 == 0) {
                v.g[] gVarArr = (v.g[]) a2.b;
                if (gVarArr != null && gVarArr.length != 0) {
                    return gVarArr[0];
                }
                throw new RuntimeException("fetchFonts failed (empty result)");
            }
            throw new RuntimeException("fetchFonts failed (" + i2 + ")");
        } catch (PackageManager.NameNotFoundException e2) {
            throw new RuntimeException("provider not found", e2);
        }
    }

    public final void p(g gVar) {
        synchronized (this.f536d) {
            try {
                this.f539h = gVar;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        synchronized (this.f536d) {
            try {
                if (this.f539h != null) {
                    if (this.f == null) {
                        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15, TimeUnit.SECONDS, new LinkedBlockingDeque(), new a("emojiCompat"));
                        threadPoolExecutor.allowCoreThreadTimeOut(true);
                        this.f538g = threadPoolExecutor;
                        this.f = threadPoolExecutor;
                    }
                    this.f.execute(new c(3, this));
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
