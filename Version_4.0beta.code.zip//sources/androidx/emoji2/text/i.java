package androidx.emoji2.text;

import D.g;
import java.util.ArrayList;
import java.util.List;

public final class i implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f516a;
    public final int b;

    public i(List list, int i2, Throwable th) {
        g.d(list, "initCallbacks cannot be null");
        this.f516a = new ArrayList(list);
        this.b = i2;
    }

    public final void run() {
        ArrayList arrayList = this.f516a;
        int size = arrayList.size();
        int i2 = 0;
        if (this.b != 1) {
            while (i2 < size) {
                ((h) arrayList.get(i2)).getClass();
                i2++;
            }
            return;
        }
        while (i2 < size) {
            ((h) arrayList.get(i2)).a();
            i2++;
        }
    }
}
