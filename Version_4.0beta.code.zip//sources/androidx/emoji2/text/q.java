package androidx.emoji2.text;

import F.a;
import java.nio.ByteBuffer;

public final class q {

    /* renamed from: a  reason: collision with root package name */
    public int f530a = 1;
    public final t b;

    /* renamed from: c  reason: collision with root package name */
    public t f531c;

    /* renamed from: d  reason: collision with root package name */
    public t f532d;

    /* renamed from: e  reason: collision with root package name */
    public int f533e;
    public int f;

    public q(t tVar) {
        this.b = tVar;
        this.f531c = tVar;
    }

    public final void a() {
        this.f530a = 1;
        this.f531c = this.b;
        this.f = 0;
    }

    public final boolean b() {
        a b2 = this.f531c.b.b();
        int a2 = b2.a(6);
        if ((a2 == 0 || ((ByteBuffer) b2.f55d).get(a2 + b2.f53a) == 0) && this.f533e != 65039) {
            return false;
        }
        return true;
    }
}
