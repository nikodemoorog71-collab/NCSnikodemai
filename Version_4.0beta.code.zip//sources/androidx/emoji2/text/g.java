package androidx.emoji2.text;

import C.h;
import Q.t;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final k f514a;
    public volatile h b;

    /* renamed from: c  reason: collision with root package name */
    public volatile t f515c;

    public g(k kVar) {
        this.f514a = kVar;
    }
}
