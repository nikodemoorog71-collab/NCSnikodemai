package androidx.emoji2.text;

import F.d;
import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

public final class z implements Spannable {

    /* renamed from: a  reason: collision with root package name */
    public boolean f553a = false;
    public Spannable b;

    public z(Spannable spannable) {
        this.b = spannable;
    }

    public final void a() {
        d dVar;
        Spannable spannable = this.b;
        if (!this.f553a) {
            if (Build.VERSION.SDK_INT < 28) {
                dVar = new d(18);
            } else {
                dVar = new d(18);
            }
            if (dVar.g(spannable)) {
                this.b = new SpannableString(spannable);
            }
        }
        this.f553a = true;
    }

    public final char charAt(int i2) {
        return this.b.charAt(i2);
    }

    public final IntStream chars() {
        return this.b.chars();
    }

    public final IntStream codePoints() {
        return this.b.codePoints();
    }

    public final int getSpanEnd(Object obj) {
        return this.b.getSpanEnd(obj);
    }

    public final int getSpanFlags(Object obj) {
        return this.b.getSpanFlags(obj);
    }

    public final int getSpanStart(Object obj) {
        return this.b.getSpanStart(obj);
    }

    public final Object[] getSpans(int i2, int i3, Class cls) {
        return this.b.getSpans(i2, i3, cls);
    }

    public final int length() {
        return this.b.length();
    }

    public final int nextSpanTransition(int i2, int i3, Class cls) {
        return this.b.nextSpanTransition(i2, i3, cls);
    }

    public final void removeSpan(Object obj) {
        a();
        this.b.removeSpan(obj);
    }

    public final void setSpan(Object obj, int i2, int i3, int i4) {
        a();
        this.b.setSpan(obj, i2, i3, i4);
    }

    public final CharSequence subSequence(int i2, int i3) {
        return this.b.subSequence(i2, i3);
    }

    public final String toString() {
        return this.b.toString();
    }
}
