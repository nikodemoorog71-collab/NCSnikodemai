package androidx.emoji2.text;

import D.g;

public interface j {
    void p(g gVar);
}
