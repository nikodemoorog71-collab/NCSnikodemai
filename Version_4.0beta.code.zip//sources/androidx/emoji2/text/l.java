package androidx.emoji2.text;

import C.j;
import D.g;
import android.content.Context;
import java.util.concurrent.ThreadPoolExecutor;

public final /* synthetic */ class l implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j f526a;
    public final /* synthetic */ g b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ThreadPoolExecutor f527c;

    public /* synthetic */ l(j jVar, g gVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f526a = jVar;
        this.b = gVar;
        this.f527c = threadPoolExecutor;
    }

    public final void run() {
        j jVar = this.f526a;
        g gVar = this.b;
        ThreadPoolExecutor threadPoolExecutor = this.f527c;
        jVar.getClass();
        try {
            s i2 = g.i((Context) jVar.b);
            if (i2 != null) {
                r rVar = (r) i2.f541a;
                synchronized (rVar.f536d) {
                    rVar.f = threadPoolExecutor;
                }
                i2.f541a.p(new m(gVar, threadPoolExecutor));
                return;
            }
            throw new RuntimeException("EmojiCompat font provider not available on this device.");
        } catch (Throwable th) {
            gVar.E(th);
            threadPoolExecutor.shutdown();
        }
    }
}
