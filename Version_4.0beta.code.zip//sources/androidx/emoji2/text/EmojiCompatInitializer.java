package androidx.emoji2.text;

import C.j;
import M.a;
import M.b;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.C0004d;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class EmojiCompatInitializer implements b {
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    public final Object b(Context context) {
        Object obj;
        s sVar = new s(new j(context));
        sVar.b = 1;
        if (k.f518k == null) {
            synchronized (k.f517j) {
                try {
                    if (k.f518k == null) {
                        k.f518k = new k(sVar);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        a c2 = a.c(context);
        Class<ProcessLifecycleInitializer> cls = ProcessLifecycleInitializer.class;
        c2.getClass();
        synchronized (a.f120e) {
            try {
                obj = c2.f121a.get(cls);
                if (obj == null) {
                    obj = c2.b(cls, new HashSet());
                }
            } catch (Throwable th2) {
                while (true) {
                    throw th2;
                }
            }
        }
        final s c3 = ((q) obj).c();
        c3.a(new C0004d(this) {
            /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Object, java.lang.Runnable] */
            public final void a() {
                Handler handler;
                if (Build.VERSION.SDK_INT >= 28) {
                    handler = c.a(Looper.getMainLooper());
                } else {
                    handler = new Handler(Looper.getMainLooper());
                }
                handler.postDelayed(new Object(), 500);
                c3.f(this);
            }
        });
        return Boolean.TRUE;
    }
}
