package androidx.emoji2.text;

import android.text.TextPaint;

public final class e {
    public static final ThreadLocal b = new ThreadLocal();

    /* renamed from: a  reason: collision with root package name */
    public final TextPaint f512a;

    public e() {
        TextPaint textPaint = new TextPaint();
        this.f512a = textPaint;
        textPaint.setTextSize(10.0f);
    }
}
