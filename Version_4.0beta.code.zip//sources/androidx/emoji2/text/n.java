package androidx.emoji2.text;

import android.os.Trace;
import u.C0152e;

public final class n implements Runnable {
    public final void run() {
        boolean z2;
        try {
            int i2 = C0152e.f1524a;
            Trace.beginSection("EmojiCompat.EmojiCompatInitializer.run");
            if (k.f518k != null) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z2) {
                k.a().c();
            }
            Trace.endSection();
        } catch (Throwable th) {
            int i3 = C0152e.f1524a;
            Trace.endSection();
            throw th;
        }
    }
}
