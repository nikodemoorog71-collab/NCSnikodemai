package androidx.emoji2.text;

import D.g;
import Q.t;
import java.util.concurrent.ThreadPoolExecutor;

public final class m extends g {

    /* renamed from: o  reason: collision with root package name */
    public final /* synthetic */ g f528o;

    /* renamed from: p  reason: collision with root package name */
    public final /* synthetic */ ThreadPoolExecutor f529p;

    public m(g gVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f528o = gVar;
        this.f529p = threadPoolExecutor;
    }

    public final void E(Throwable th) {
        ThreadPoolExecutor threadPoolExecutor = this.f529p;
        try {
            this.f528o.E(th);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }

    public final void F(t tVar) {
        ThreadPoolExecutor threadPoolExecutor = this.f529p;
        try {
            this.f528o.F(tVar);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}
