package androidx.emoji2.text;

import D.g;
import F.a;
import android.graphics.Paint;
import android.text.TextPaint;
import android.text.style.ReplacementSpan;
import java.nio.ByteBuffer;

public final class x extends ReplacementSpan {

    /* renamed from: a  reason: collision with root package name */
    public final Paint.FontMetricsInt f549a = new Paint.FontMetricsInt();
    public final w b;

    /* renamed from: c  reason: collision with root package name */
    public short f550c = -1;

    /* renamed from: d  reason: collision with root package name */
    public float f551d = 1.0f;

    /* renamed from: e  reason: collision with root package name */
    public TextPaint f552e;

    public x(w wVar) {
        g.d(wVar, "rasterizer cannot be null");
        this.b = wVar;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v0, resolved type: android.graphics.Paint} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v0, resolved type: android.text.TextPaint} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v1, resolved type: android.text.TextPaint} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v2, resolved type: android.text.TextPaint} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void draw(android.graphics.Canvas r19, java.lang.CharSequence r20, int r21, int r22, float r23, int r24, int r25, int r26, android.graphics.Paint r27) {
        /*
            r18 = this;
            r0 = r18
            r1 = r20
            r2 = r27
            boolean r3 = r1 instanceof android.text.Spanned
            r4 = 0
            if (r3 == 0) goto L_0x004a
            android.text.Spanned r1 = (android.text.Spanned) r1
            java.lang.Class<android.text.style.CharacterStyle> r3 = android.text.style.CharacterStyle.class
            r5 = r21
            r6 = r22
            java.lang.Object[] r1 = r1.getSpans(r5, r6, r3)
            android.text.style.CharacterStyle[] r1 = (android.text.style.CharacterStyle[]) r1
            int r3 = r1.length
            if (r3 == 0) goto L_0x0042
            int r3 = r1.length
            r5 = 1
            r6 = 0
            if (r3 != r5) goto L_0x0026
            r3 = r1[r6]
            if (r3 != r0) goto L_0x0026
            goto L_0x0042
        L_0x0026:
            android.text.TextPaint r3 = r0.f552e
            if (r3 != 0) goto L_0x0031
            android.text.TextPaint r3 = new android.text.TextPaint
            r3.<init>()
            r0.f552e = r3
        L_0x0031:
            r4 = r3
            r4.set(r2)
        L_0x0035:
            int r3 = r1.length
            if (r6 >= r3) goto L_0x0040
            r3 = r1[r6]
            r3.updateDrawState(r4)
            int r6 = r6 + 1
            goto L_0x0035
        L_0x0040:
            r10 = r4
            goto L_0x0052
        L_0x0042:
            boolean r1 = r2 instanceof android.text.TextPaint
            if (r1 == 0) goto L_0x0040
            r4 = r2
            android.text.TextPaint r4 = (android.text.TextPaint) r4
            goto L_0x0040
        L_0x004a:
            boolean r1 = r2 instanceof android.text.TextPaint
            if (r1 == 0) goto L_0x0040
            r4 = r2
            android.text.TextPaint r4 = (android.text.TextPaint) r4
            goto L_0x0040
        L_0x0052:
            if (r10 == 0) goto L_0x0082
            int r1 = r10.bgColor
            if (r1 == 0) goto L_0x0082
            short r1 = r0.f550c
            float r1 = (float) r1
            float r8 = r23 + r1
            r1 = r24
            float r7 = (float) r1
            r1 = r26
            float r9 = (float) r1
            int r1 = r10.getColor()
            android.graphics.Paint$Style r3 = r10.getStyle()
            int r4 = r10.bgColor
            r10.setColor(r4)
            android.graphics.Paint$Style r4 = android.graphics.Paint.Style.FILL
            r10.setStyle(r4)
            r5 = r19
            r6 = r23
            r5.drawRect(r6, r7, r8, r9, r10)
            r10.setStyle(r3)
            r10.setColor(r1)
        L_0x0082:
            androidx.emoji2.text.k r1 = androidx.emoji2.text.k.a()
            r1.getClass()
            r1 = r25
            float r1 = (float) r1
            if (r10 == 0) goto L_0x008f
            goto L_0x0090
        L_0x008f:
            r10 = r2
        L_0x0090:
            androidx.emoji2.text.w r2 = r0.b
            Q.t r3 = r2.b
            java.lang.Object r4 = r3.f176d
            android.graphics.Typeface r4 = (android.graphics.Typeface) r4
            android.graphics.Typeface r5 = r10.getTypeface()
            r10.setTypeface(r4)
            int r2 = r2.f547a
            int r13 = r2 * 2
            r14 = 2
            java.lang.Object r2 = r3.b
            r12 = r2
            char[] r12 = (char[]) r12
            r11 = r19
            r15 = r23
            r16 = r1
            r17 = r10
            r11.drawText(r12, r13, r14, r15, r16, r17)
            r10.setTypeface(r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.emoji2.text.x.draw(android.graphics.Canvas, java.lang.CharSequence, int, int, float, int, int, int, android.graphics.Paint):void");
    }

    public final int getSize(Paint paint, CharSequence charSequence, int i2, int i3, Paint.FontMetricsInt fontMetricsInt) {
        short s2;
        Paint.FontMetricsInt fontMetricsInt2 = this.f549a;
        paint.getFontMetricsInt(fontMetricsInt2);
        float abs = ((float) Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent)) * 1.0f;
        w wVar = this.b;
        a b2 = wVar.b();
        int a2 = b2.a(14);
        short s3 = 0;
        if (a2 != 0) {
            s2 = ((ByteBuffer) b2.f55d).getShort(a2 + b2.f53a);
        } else {
            s2 = 0;
        }
        this.f551d = abs / ((float) s2);
        a b3 = wVar.b();
        int a3 = b3.a(14);
        if (a3 != 0) {
            ((ByteBuffer) b3.f55d).getShort(a3 + b3.f53a);
        }
        a b4 = wVar.b();
        int a4 = b4.a(12);
        if (a4 != 0) {
            s3 = ((ByteBuffer) b4.f55d).getShort(a4 + b4.f53a);
        }
        short s4 = (short) ((int) (((float) s3) * this.f551d));
        this.f550c = s4;
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = fontMetricsInt2.ascent;
            fontMetricsInt.descent = fontMetricsInt2.descent;
            fontMetricsInt.top = fontMetricsInt2.top;
            fontMetricsInt.bottom = fontMetricsInt2.bottom;
        }
        return s4;
    }
}
