package androidx.emoji2.text;

import android.os.Build;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.TextWatcher;
import java.util.concurrent.atomic.AtomicInteger;

public final class u implements TextWatcher, SpanWatcher {

    /* renamed from: a  reason: collision with root package name */
    public final Object f544a;
    public final AtomicInteger b = new AtomicInteger(0);

    public u(Object obj) {
        this.f544a = obj;
    }

    public final void afterTextChanged(Editable editable) {
        ((TextWatcher) this.f544a).afterTextChanged(editable);
    }

    public final void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        ((TextWatcher) this.f544a).beforeTextChanged(charSequence, i2, i3, i4);
    }

    public final void onSpanAdded(Spannable spannable, Object obj, int i2, int i3) {
        if (this.b.get() <= 0 || !(obj instanceof x)) {
            ((SpanWatcher) this.f544a).onSpanAdded(spannable, obj, i2, i3);
        }
    }

    public final void onSpanChanged(Spannable spannable, Object obj, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        if (this.b.get() <= 0 || !(obj instanceof x)) {
            if (Build.VERSION.SDK_INT < 28) {
                if (i2 > i3) {
                    i2 = 0;
                }
                if (i4 > i5) {
                    i7 = i2;
                    i6 = 0;
                    ((SpanWatcher) this.f544a).onSpanChanged(spannable, obj, i7, i3, i6, i5);
                }
            }
            i7 = i2;
            i6 = i4;
            ((SpanWatcher) this.f544a).onSpanChanged(spannable, obj, i7, i3, i6, i5);
        }
    }

    public final void onSpanRemoved(Spannable spannable, Object obj, int i2, int i3) {
        if (this.b.get() <= 0 || !(obj instanceof x)) {
            ((SpanWatcher) this.f544a).onSpanRemoved(spannable, obj, i2, i3);
        }
    }

    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        ((TextWatcher) this.f544a).onTextChanged(charSequence, i2, i3, i4);
    }
}
