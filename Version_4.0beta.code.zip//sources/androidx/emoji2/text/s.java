package androidx.emoji2.text;

import F.d;

public final class s {

    /* renamed from: d  reason: collision with root package name */
    public static final d f540d = new d(17);

    /* renamed from: a  reason: collision with root package name */
    public final j f541a;
    public int b = 0;

    /* renamed from: c  reason: collision with root package name */
    public final e f542c = new e();

    public s(j jVar) {
        this.f541a = jVar;
    }
}
