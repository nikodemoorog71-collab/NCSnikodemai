package androidx.emoji2.text;

import C.h;
import D.g;
import F.d;
import Q.t;
import android.os.Build;
import java.util.ArrayList;
import java.util.Set;

public final class f extends g {

    /* renamed from: o  reason: collision with root package name */
    public final /* synthetic */ g f513o;

    public f(g gVar) {
        this.f513o = gVar;
    }

    public final void E(Throwable th) {
        this.f513o.f514a.d(th);
    }

    /* JADX INFO: finally extract failed */
    public final void F(t tVar) {
        Set<int[]> set;
        g gVar = this.f513o;
        gVar.f515c = tVar;
        t tVar2 = gVar.f515c;
        k kVar = gVar.f514a;
        d dVar = kVar.f523g;
        e eVar = kVar.f525i;
        if (Build.VERSION.SDK_INT >= 34) {
            set = o.a();
        } else {
            set = g.t();
        }
        gVar.b = new h(tVar2, dVar, eVar, set);
        k kVar2 = gVar.f514a;
        kVar2.getClass();
        ArrayList arrayList = new ArrayList();
        kVar2.f519a.writeLock().lock();
        try {
            kVar2.f520c = 1;
            arrayList.addAll(kVar2.b);
            kVar2.b.clear();
            kVar2.f519a.writeLock().unlock();
            kVar2.f521d.post(new i(arrayList, kVar2.f520c, (Throwable) null));
        } catch (Throwable th) {
            kVar2.f519a.writeLock().unlock();
            throw th;
        }
    }
}
