package androidx.emoji2.text;

import D.g;
import java.util.Set;

public abstract class o {
    public static Set<int[]> a() {
        return g.t();
    }
}
