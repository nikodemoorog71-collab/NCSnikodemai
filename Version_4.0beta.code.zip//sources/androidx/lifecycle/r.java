package androidx.lifecycle;

import a0.c;

public final class r {

    /* renamed from: a  reason: collision with root package name */
    public l f677a;
    public o b;

    public final void a(q qVar, k kVar) {
        l a2 = kVar.a();
        l lVar = this.f677a;
        c.e(lVar, "state1");
        if (a2.compareTo(lVar) < 0) {
            lVar = a2;
        }
        this.f677a = lVar;
        this.b.b(qVar, kVar);
        this.f677a = a2;
    }
}
