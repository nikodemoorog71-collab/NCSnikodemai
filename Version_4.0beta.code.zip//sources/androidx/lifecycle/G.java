package androidx.lifecycle;

import C.j;

public interface G {
    j b();
}
