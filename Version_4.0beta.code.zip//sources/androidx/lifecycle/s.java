package androidx.lifecycle;

import a0.c;
import android.os.Looper;
import j.C0098a;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicReference;
import k.C0099a;
import k.C0100b;
import k.C0101c;
import k.C0102d;
import k.C0103e;

public final class s {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f678a = true;
    public C0099a b = new C0099a();

    /* renamed from: c  reason: collision with root package name */
    public l f679c = l.b;

    /* renamed from: d  reason: collision with root package name */
    public final WeakReference f680d;

    /* renamed from: e  reason: collision with root package name */
    public int f681e;
    public boolean f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f682g;

    /* renamed from: h  reason: collision with root package name */
    public final ArrayList f683h = new ArrayList();

    public s(q qVar) {
        new AtomicReference();
        this.f680d = new WeakReference(qVar);
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [androidx.lifecycle.r, java.lang.Object] */
    public final void a(p pVar) {
        o oVar;
        Object obj;
        q qVar;
        k kVar;
        ArrayList arrayList = this.f683h;
        c("addObserver");
        l lVar = this.f679c;
        l lVar2 = l.f672a;
        if (lVar != lVar2) {
            lVar2 = l.b;
        }
        ? obj2 = new Object();
        HashMap hashMap = t.f684a;
        boolean z2 = pVar instanceof o;
        boolean z3 = pVar instanceof C0004d;
        boolean z4 = false;
        if (z2 && z3) {
            oVar = new DefaultLifecycleObserverAdapter((C0004d) pVar, (o) pVar);
        } else if (z3) {
            oVar = new DefaultLifecycleObserverAdapter((C0004d) pVar, (o) null);
        } else if (z2) {
            oVar = (o) pVar;
        } else {
            Class<?> cls = pVar.getClass();
            if (t.c(cls) == 2) {
                Object obj3 = t.b.get(cls);
                c.b(obj3);
                List list = (List) obj3;
                if (list.size() != 1) {
                    int size = list.size();
                    C0007g[] gVarArr = new C0007g[size];
                    if (size <= 0) {
                        oVar = new CompositeGeneratedAdaptersObserver(gVarArr);
                    } else {
                        t.a((Constructor) list.get(0), pVar);
                        throw null;
                    }
                } else {
                    t.a((Constructor) list.get(0), pVar);
                    throw null;
                }
            } else {
                oVar = new ReflectiveGenericLifecycleObserver(pVar);
            }
        }
        obj2.b = oVar;
        obj2.f677a = lVar2;
        C0099a aVar = this.b;
        C0101c a2 = aVar.a(pVar);
        if (a2 != null) {
            obj = a2.b;
        } else {
            HashMap hashMap2 = aVar.f1374e;
            C0101c cVar = new C0101c(pVar, obj2);
            aVar.f1384d++;
            C0101c cVar2 = aVar.b;
            if (cVar2 == null) {
                aVar.f1382a = cVar;
                aVar.b = cVar;
            } else {
                cVar2.f1378c = cVar;
                cVar.f1379d = cVar2;
                aVar.b = cVar;
            }
            hashMap2.put(pVar, cVar);
            obj = null;
        }
        if (((r) obj) == null && (qVar = (q) this.f680d.get()) != null) {
            if (this.f681e != 0 || this.f) {
                z4 = true;
            }
            l b2 = b(pVar);
            this.f681e++;
            while (obj2.f677a.compareTo(b2) < 0 && this.b.f1374e.containsKey(pVar)) {
                arrayList.add(obj2.f677a);
                i iVar = k.Companion;
                l lVar3 = obj2.f677a;
                iVar.getClass();
                c.e(lVar3, "state");
                int ordinal = lVar3.ordinal();
                if (ordinal == 1) {
                    kVar = k.ON_CREATE;
                } else if (ordinal == 2) {
                    kVar = k.ON_START;
                } else if (ordinal != 3) {
                    kVar = null;
                } else {
                    kVar = k.ON_RESUME;
                }
                if (kVar != null) {
                    obj2.a(qVar, kVar);
                    arrayList.remove(arrayList.size() - 1);
                    b2 = b(pVar);
                } else {
                    throw new IllegalStateException("no event up from " + obj2.f677a);
                }
            }
            if (!z4) {
                g();
            }
            this.f681e--;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: androidx.lifecycle.l} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final androidx.lifecycle.l b(androidx.lifecycle.p r4) {
        /*
            r3 = this;
            k.a r0 = r3.b
            java.util.HashMap r0 = r0.f1374e
            boolean r1 = r0.containsKey(r4)
            r2 = 0
            if (r1 == 0) goto L_0x0014
            java.lang.Object r4 = r0.get(r4)
            k.c r4 = (k.C0101c) r4
            k.c r4 = r4.f1379d
            goto L_0x0015
        L_0x0014:
            r4 = r2
        L_0x0015:
            if (r4 == 0) goto L_0x001e
            java.lang.Object r4 = r4.b
            androidx.lifecycle.r r4 = (androidx.lifecycle.r) r4
            androidx.lifecycle.l r4 = r4.f677a
            goto L_0x001f
        L_0x001e:
            r4 = r2
        L_0x001f:
            java.util.ArrayList r0 = r3.f683h
            boolean r1 = r0.isEmpty()
            if (r1 != 0) goto L_0x0034
            int r1 = r0.size()
            int r1 = r1 + -1
            java.lang.Object r0 = r0.get(r1)
            r2 = r0
            androidx.lifecycle.l r2 = (androidx.lifecycle.l) r2
        L_0x0034:
            androidx.lifecycle.l r0 = r3.f679c
            java.lang.String r1 = "state1"
            a0.c.e(r0, r1)
            if (r4 == 0) goto L_0x0044
            int r1 = r4.compareTo(r0)
            if (r1 >= 0) goto L_0x0044
            goto L_0x0045
        L_0x0044:
            r4 = r0
        L_0x0045:
            if (r2 == 0) goto L_0x004e
            int r0 = r2.compareTo(r4)
            if (r0 >= 0) goto L_0x004e
            return r2
        L_0x004e:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.s.b(androidx.lifecycle.p):androidx.lifecycle.l");
    }

    public final void c(String str) {
        C0098a aVar;
        if (this.f678a) {
            if (C0098a.f1371p != null) {
                aVar = C0098a.f1371p;
            } else {
                synchronized (C0098a.class) {
                    try {
                        if (C0098a.f1371p == null) {
                            C0098a.f1371p = new C0098a(0);
                        }
                    } catch (Throwable th) {
                        while (true) {
                            throw th;
                        }
                    }
                }
                aVar = C0098a.f1371p;
            }
            ((C0098a) aVar.f1372o).getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(("Method " + str + " must be called on the main thread").toString());
            }
        }
    }

    public final void d(k kVar) {
        c.e(kVar, "event");
        c("handleLifecycleEvent");
        e(kVar.a());
    }

    public final void e(l lVar) {
        l lVar2 = this.f679c;
        if (lVar2 != lVar) {
            l lVar3 = l.b;
            l lVar4 = l.f672a;
            if (lVar2 == lVar3 && lVar == lVar4) {
                throw new IllegalStateException(("no event down from " + this.f679c + " in component " + this.f680d.get()).toString());
            }
            this.f679c = lVar;
            if (this.f || this.f681e != 0) {
                this.f682g = true;
                return;
            }
            this.f = true;
            g();
            this.f = false;
            if (this.f679c == lVar4) {
                this.b = new C0099a();
            }
        }
    }

    public final void f(p pVar) {
        c("removeObserver");
        C0099a aVar = this.b;
        C0101c a2 = aVar.a(pVar);
        if (a2 != null) {
            aVar.f1384d--;
            WeakHashMap weakHashMap = aVar.f1383c;
            if (!weakHashMap.isEmpty()) {
                for (C0103e a3 : weakHashMap.keySet()) {
                    a3.a(a2);
                }
            }
            C0101c cVar = a2.f1379d;
            if (cVar != null) {
                cVar.f1378c = a2.f1378c;
            } else {
                aVar.f1382a = a2.f1378c;
            }
            C0101c cVar2 = a2.f1378c;
            if (cVar2 != null) {
                cVar2.f1379d = cVar;
            } else {
                aVar.b = cVar;
            }
            a2.f1378c = null;
            a2.f1379d = null;
        }
        aVar.f1374e.remove(pVar);
    }

    public final void g() {
        k kVar;
        k kVar2;
        q qVar = (q) this.f680d.get();
        if (qVar != null) {
            while (true) {
                C0099a aVar = this.b;
                if (aVar.f1384d != 0) {
                    C0101c cVar = aVar.f1382a;
                    c.b(cVar);
                    l lVar = ((r) cVar.b).f677a;
                    C0101c cVar2 = this.b.b;
                    c.b(cVar2);
                    l lVar2 = ((r) cVar2.b).f677a;
                    if (lVar == lVar2 && this.f679c == lVar2) {
                        break;
                    }
                    this.f682g = false;
                    l lVar3 = this.f679c;
                    C0101c cVar3 = this.b.f1382a;
                    c.b(cVar3);
                    if (lVar3.compareTo(((r) cVar3.b).f677a) < 0) {
                        C0099a aVar2 = this.b;
                        C0100b bVar = new C0100b(aVar2.b, aVar2.f1382a, 1);
                        aVar2.f1383c.put(bVar, Boolean.FALSE);
                        while (bVar.hasNext() && !this.f682g) {
                            Map.Entry entry = (Map.Entry) bVar.next();
                            c.d(entry, "next()");
                            p pVar = (p) entry.getKey();
                            r rVar = (r) entry.getValue();
                            while (rVar.f677a.compareTo(this.f679c) > 0 && !this.f682g && this.b.f1374e.containsKey(pVar)) {
                                i iVar = k.Companion;
                                l lVar4 = rVar.f677a;
                                iVar.getClass();
                                c.e(lVar4, "state");
                                int ordinal = lVar4.ordinal();
                                if (ordinal == 2) {
                                    kVar2 = k.ON_DESTROY;
                                } else if (ordinal == 3) {
                                    kVar2 = k.ON_STOP;
                                } else if (ordinal != 4) {
                                    kVar2 = null;
                                } else {
                                    kVar2 = k.ON_PAUSE;
                                }
                                if (kVar2 != null) {
                                    this.f683h.add(kVar2.a());
                                    rVar.a(qVar, kVar2);
                                    ArrayList arrayList = this.f683h;
                                    arrayList.remove(arrayList.size() - 1);
                                } else {
                                    throw new IllegalStateException("no event down from " + rVar.f677a);
                                }
                            }
                        }
                    }
                    C0101c cVar4 = this.b.b;
                    if (!this.f682g && cVar4 != null && this.f679c.compareTo(((r) cVar4.b).f677a) > 0) {
                        C0099a aVar3 = this.b;
                        aVar3.getClass();
                        C0102d dVar = new C0102d(aVar3);
                        aVar3.f1383c.put(dVar, Boolean.FALSE);
                        while (dVar.hasNext() && !this.f682g) {
                            Map.Entry entry2 = (Map.Entry) dVar.next();
                            p pVar2 = (p) entry2.getKey();
                            r rVar2 = (r) entry2.getValue();
                            while (rVar2.f677a.compareTo(this.f679c) < 0 && !this.f682g && this.b.f1374e.containsKey(pVar2)) {
                                this.f683h.add(rVar2.f677a);
                                i iVar2 = k.Companion;
                                l lVar5 = rVar2.f677a;
                                iVar2.getClass();
                                c.e(lVar5, "state");
                                int ordinal2 = lVar5.ordinal();
                                if (ordinal2 == 1) {
                                    kVar = k.ON_CREATE;
                                } else if (ordinal2 == 2) {
                                    kVar = k.ON_START;
                                } else if (ordinal2 != 3) {
                                    kVar = null;
                                } else {
                                    kVar = k.ON_RESUME;
                                }
                                if (kVar != null) {
                                    rVar2.a(qVar, kVar);
                                    ArrayList arrayList2 = this.f683h;
                                    arrayList2.remove(arrayList2.size() - 1);
                                } else {
                                    throw new IllegalStateException("no event up from " + rVar2.f677a);
                                }
                            }
                        }
                    }
                } else {
                    break;
                }
            }
            this.f682g = false;
            return;
        }
        throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
    }
}
