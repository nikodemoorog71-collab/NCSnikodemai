package androidx.lifecycle;

import C.j;
import a0.c;
import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

public class A extends Fragment {
    public static final /* synthetic */ int b = 0;

    /* renamed from: a  reason: collision with root package name */
    public j f652a;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final z Companion = new Object();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            c.e(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
            c.e(activity, "activity");
        }

        public void onActivityDestroyed(Activity activity) {
            c.e(activity, "activity");
        }

        public void onActivityPaused(Activity activity) {
            c.e(activity, "activity");
        }

        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_CREATE);
        }

        public void onActivityPostResumed(Activity activity) {
            c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_RESUME);
        }

        public void onActivityPostStarted(Activity activity) {
            c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_START);
        }

        public void onActivityPreDestroyed(Activity activity) {
            c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_DESTROY);
        }

        public void onActivityPrePaused(Activity activity) {
            c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_PAUSE);
        }

        public void onActivityPreStopped(Activity activity) {
            c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_STOP);
        }

        public void onActivityResumed(Activity activity) {
            c.e(activity, "activity");
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            c.e(activity, "activity");
            c.e(bundle, "bundle");
        }

        public void onActivityStarted(Activity activity) {
            c.e(activity, "activity");
        }

        public void onActivityStopped(Activity activity) {
            c.e(activity, "activity");
        }
    }

    public final void a(k kVar) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            c.d(activity, "activity");
            y.a(activity, kVar);
        }
    }

    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(k.ON_CREATE);
    }

    public final void onDestroy() {
        super.onDestroy();
        a(k.ON_DESTROY);
        this.f652a = null;
    }

    public final void onPause() {
        super.onPause();
        a(k.ON_PAUSE);
    }

    public final void onResume() {
        super.onResume();
        j jVar = this.f652a;
        if (jVar != null) {
            ((x) jVar.b).b();
        }
        a(k.ON_RESUME);
    }

    public final void onStart() {
        super.onStart();
        j jVar = this.f652a;
        if (jVar != null) {
            x xVar = (x) jVar.b;
            int i2 = xVar.f686a + 1;
            xVar.f686a = i2;
            if (i2 == 1 && xVar.f688d) {
                xVar.f.d(k.ON_START);
                xVar.f688d = false;
            }
        }
        a(k.ON_START);
    }

    public final void onStop() {
        super.onStop();
        a(k.ON_STOP);
    }
}
