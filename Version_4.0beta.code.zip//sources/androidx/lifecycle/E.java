package androidx.lifecycle;

import java.util.HashMap;
import java.util.LinkedHashSet;

public abstract class E {

    /* renamed from: a  reason: collision with root package name */
    public final HashMap f661a = new HashMap();
    public final LinkedHashSet b = new LinkedHashSet();

    public void a() {
    }
}
