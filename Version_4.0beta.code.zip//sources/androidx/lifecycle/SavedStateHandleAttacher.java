package androidx.lifecycle;

import android.os.Bundle;

public final class SavedStateHandleAttacher implements o {

    /* renamed from: a  reason: collision with root package name */
    public final C f664a;

    public SavedStateHandleAttacher(C c2) {
        this.f664a = c2;
    }

    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_CREATE) {
            qVar.c().f(this);
            C c2 = this.f664a;
            if (!c2.b) {
                Bundle c3 = c2.f655a.c("androidx.lifecycle.internal.SavedStateHandlesProvider");
                Bundle bundle = new Bundle();
                Bundle bundle2 = c2.f656c;
                if (bundle2 != null) {
                    bundle.putAll(bundle2);
                }
                if (c3 != null) {
                    bundle.putAll(c3);
                }
                c2.f656c = bundle;
                c2.b = true;
                D d2 = (D) c2.f657d.a();
                return;
            }
            return;
        }
        throw new IllegalStateException(("Next event must be ON_CREATE, it was " + kVar).toString());
    }
}
