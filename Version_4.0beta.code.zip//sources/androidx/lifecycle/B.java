package androidx.lifecycle;

public abstract class B {

    /* renamed from: a  reason: collision with root package name */
    public static final F f653a = new Object();
    public static final F b = new Object();

    /* renamed from: c  reason: collision with root package name */
    public static final F f654c = new Object();
}
