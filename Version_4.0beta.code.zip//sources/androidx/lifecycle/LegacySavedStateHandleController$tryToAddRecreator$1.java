package androidx.lifecycle;

public final class LegacySavedStateHandleController$tryToAddRecreator$1 implements o {
    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_START) {
            throw null;
        }
    }
}
