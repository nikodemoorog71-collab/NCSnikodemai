package androidx.lifecycle;

public final class SingleGeneratedAdapterObserver implements o {
    public final void b(q qVar, k kVar) {
        throw null;
    }
}
