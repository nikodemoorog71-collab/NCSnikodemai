package androidx.lifecycle;

import a0.c;
import android.app.Activity;
import android.app.Application;

public abstract class v {
    public static final void a(Activity activity, Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        c.e(activity, "activity");
        c.e(activityLifecycleCallbacks, "callback");
        activity.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
    }
}
