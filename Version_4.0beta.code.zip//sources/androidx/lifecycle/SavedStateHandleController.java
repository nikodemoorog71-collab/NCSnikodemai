package androidx.lifecycle;

public final class SavedStateHandleController implements o {

    /* renamed from: a  reason: collision with root package name */
    public boolean f665a;

    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_DESTROY) {
            this.f665a = false;
            qVar.c().f(this);
        }
    }
}
