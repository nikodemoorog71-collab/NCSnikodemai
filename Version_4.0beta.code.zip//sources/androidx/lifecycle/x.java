package androidx.lifecycle;

import C.j;
import android.os.Handler;
import androidx.activity.c;

public final class x implements q {

    /* renamed from: i  reason: collision with root package name */
    public static final x f685i = new x();

    /* renamed from: a  reason: collision with root package name */
    public int f686a;
    public int b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f687c = true;

    /* renamed from: d  reason: collision with root package name */
    public boolean f688d = true;

    /* renamed from: e  reason: collision with root package name */
    public Handler f689e;
    public final s f = new s(this);

    /* renamed from: g  reason: collision with root package name */
    public final c f690g = new c(4, this);

    /* renamed from: h  reason: collision with root package name */
    public final j f691h = new j(12, (Object) this);

    public final void b() {
        int i2 = this.b + 1;
        this.b = i2;
        if (i2 != 1) {
            return;
        }
        if (this.f687c) {
            this.f.d(k.ON_RESUME);
            this.f687c = false;
            return;
        }
        Handler handler = this.f689e;
        a0.c.b(handler);
        handler.removeCallbacks(this.f690g);
    }

    public final s c() {
        return this.f;
    }
}
