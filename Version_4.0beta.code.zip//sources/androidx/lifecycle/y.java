package androidx.lifecycle;

import a0.c;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import androidx.lifecycle.A;

public abstract class y {
    public static void a(Activity activity, k kVar) {
        s c2;
        c.e(kVar, "event");
        if ((activity instanceof q) && (c2 = ((q) activity).c()) != null) {
            c2.d(kVar);
        }
    }

    public static void b(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            A.a.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new A.a());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new Fragment(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }
}
