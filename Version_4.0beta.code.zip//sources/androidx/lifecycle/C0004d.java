package androidx.lifecycle;

/* renamed from: androidx.lifecycle.d  reason: case insensitive filesystem */
public interface C0004d extends p {
    void a();
}
