package androidx.lifecycle;

import M.a;
import M.b;
import U.d;
import a0.c;
import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

public final class ProcessLifecycleInitializer implements b {
    public final List a() {
        return d.f250a;
    }

    public final Object b(Context context) {
        c.e(context, "context");
        a c2 = a.c(context);
        c.d(c2, "getInstance(context)");
        if (c2.b.contains(ProcessLifecycleInitializer.class)) {
            if (!n.f676a.getAndSet(true)) {
                Context applicationContext = context.getApplicationContext();
                c.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
                ((Application) applicationContext).registerActivityLifecycleCallbacks(new m());
            }
            x xVar = x.f685i;
            xVar.getClass();
            xVar.f689e = new Handler();
            xVar.f.d(k.ON_CREATE);
            Context applicationContext2 = context.getApplicationContext();
            c.c(applicationContext2, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext2).registerActivityLifecycleCallbacks(new w(xVar));
            return xVar;
        }
        throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
    }
}
