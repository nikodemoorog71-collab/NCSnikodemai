package androidx.lifecycle;

import java.util.HashMap;

public final class CompositeGeneratedAdaptersObserver implements o {

    /* renamed from: a  reason: collision with root package name */
    public final C0007g[] f658a;

    public CompositeGeneratedAdaptersObserver(C0007g[] gVarArr) {
        this.f658a = gVarArr;
    }

    public final void b(q qVar, k kVar) {
        new HashMap();
        C0007g[] gVarArr = this.f658a;
        if (gVarArr.length > 0) {
            C0007g gVar = gVarArr[0];
            throw null;
        } else if (gVarArr.length > 0) {
            C0007g gVar2 = gVarArr[0];
            throw null;
        }
    }
}
