package androidx.lifecycle;

public final class DefaultLifecycleObserverAdapter implements o {

    /* renamed from: a  reason: collision with root package name */
    public final C0004d f660a;
    public final o b;

    public DefaultLifecycleObserverAdapter(C0004d dVar, o oVar) {
        this.f660a = dVar;
        this.b = oVar;
    }

    public final void b(q qVar, k kVar) {
        int i2 = C0005e.f670a[kVar.ordinal()];
        C0004d dVar = this.f660a;
        if (i2 == 3) {
            dVar.a();
        } else if (i2 == 7) {
            throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        o oVar = this.b;
        if (oVar != null) {
            oVar.b(qVar, kVar);
        }
    }
}
