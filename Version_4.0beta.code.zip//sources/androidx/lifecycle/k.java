package androidx.lifecycle;

public enum k {
    ;
    
    public static final i Companion = null;

    /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r1v1, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r2v2, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r3v2, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r4v2, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r5v2, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r6v2, types: [java.lang.Enum, androidx.lifecycle.k] */
    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, androidx.lifecycle.i] */
    static {
        Companion = new Object();
    }

    public final l a() {
        switch (j.f671a[ordinal()]) {
            case 1:
            case 2:
                return l.f673c;
            case 3:
            case 4:
                return l.f674d;
            case 5:
                return l.f675e;
            case 6:
                return l.f672a;
            default:
                throw new IllegalArgumentException(this + " has no target state");
        }
    }
}
