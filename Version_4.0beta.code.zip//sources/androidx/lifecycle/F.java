package androidx.lifecycle;

public final class F {

    /* renamed from: a  reason: collision with root package name */
    public static final F f662a = new Object();
    public static final F b = new Object();
}
