package androidx.lifecycle;

import a0.c;
import android.app.Activity;
import android.os.Bundle;

public final class m extends C0006f {
    public void onActivityCreated(Activity activity, Bundle bundle) {
        c.e(activity, "activity");
        int i2 = A.b;
        y.b(activity);
    }
}
