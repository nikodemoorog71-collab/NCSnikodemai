package androidx.lifecycle;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;

@Deprecated
class ReflectiveGenericLifecycleObserver implements o {

    /* renamed from: a  reason: collision with root package name */
    public final p f663a;
    public final C0001a b;

    public ReflectiveGenericLifecycleObserver(p pVar) {
        this.f663a = pVar;
        C0003c cVar = C0003c.f668c;
        Class<?> cls = pVar.getClass();
        C0001a aVar = (C0001a) cVar.f669a.get(cls);
        this.b = aVar == null ? cVar.a(cls, (Method[]) null) : aVar;
    }

    public final void b(q qVar, k kVar) {
        HashMap hashMap = this.b.f666a;
        p pVar = this.f663a;
        C0001a.a((List) hashMap.get(kVar), qVar, kVar, pVar);
        C0001a.a((List) hashMap.get(k.ON_ANY), qVar, kVar, pVar);
    }
}
