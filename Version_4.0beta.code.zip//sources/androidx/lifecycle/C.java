package androidx.lifecycle;

import L.d;
import L.e;
import T.b;
import a0.c;
import android.os.Bundle;
import androidx.activity.k;
import androidx.activity.n;
import java.util.Iterator;
import java.util.Map;

public final class C implements d {

    /* renamed from: a  reason: collision with root package name */
    public final e f655a;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f656c;

    /* renamed from: d  reason: collision with root package name */
    public final b f657d;

    public C(e eVar, k kVar) {
        c.e(eVar, "savedStateRegistry");
        this.f655a = eVar;
        this.f657d = new b(new n(3, kVar));
    }

    public final Bundle a() {
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f656c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        Iterator it = ((D) this.f657d.a()).f659c.entrySet().iterator();
        if (!it.hasNext()) {
            this.b = false;
            return bundle;
        }
        Map.Entry entry = (Map.Entry) it.next();
        String str = (String) entry.getKey();
        entry.getValue().getClass();
        throw new ClassCastException();
    }
}
