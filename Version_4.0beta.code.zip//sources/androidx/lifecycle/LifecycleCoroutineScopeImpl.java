package androidx.lifecycle;

public final class LifecycleCoroutineScopeImpl implements o {
    public final void b(q qVar, k kVar) {
        throw null;
    }
}
