package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: androidx.lifecycle.a  reason: case insensitive filesystem */
public final class C0001a {

    /* renamed from: a  reason: collision with root package name */
    public final HashMap f666a = new HashMap();
    public final HashMap b;

    public C0001a(HashMap hashMap) {
        this.b = hashMap;
        for (Map.Entry entry : hashMap.entrySet()) {
            k kVar = (k) entry.getValue();
            List list = (List) this.f666a.get(kVar);
            if (list == null) {
                list = new ArrayList();
                this.f666a.put(kVar, list);
            }
            list.add((C0002b) entry.getKey());
        }
    }

    public static void a(List list, q qVar, k kVar, p pVar) {
        if (list != null) {
            int size = list.size() - 1;
            while (size >= 0) {
                C0002b bVar = (C0002b) list.get(size);
                bVar.getClass();
                try {
                    int i2 = bVar.f667a;
                    Method method = bVar.b;
                    if (i2 == 0) {
                        method.invoke(pVar, (Object[]) null);
                    } else if (i2 == 1) {
                        method.invoke(pVar, new Object[]{qVar});
                    } else if (i2 == 2) {
                        method.invoke(pVar, new Object[]{qVar, kVar});
                    }
                    size--;
                } catch (InvocationTargetException e2) {
                    throw new RuntimeException("Failed to call observer method", e2.getCause());
                } catch (IllegalAccessException e3) {
                    throw new RuntimeException(e3);
                }
            }
        }
    }
}
