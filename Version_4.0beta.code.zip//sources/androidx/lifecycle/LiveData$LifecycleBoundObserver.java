package androidx.lifecycle;

class LiveData$LifecycleBoundObserver extends B implements o {
    public final void b(q qVar, k kVar) {
        throw null;
    }
}
