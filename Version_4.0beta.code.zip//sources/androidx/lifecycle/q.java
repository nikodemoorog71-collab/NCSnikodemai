package androidx.lifecycle;

public interface q {
    s c();
}
