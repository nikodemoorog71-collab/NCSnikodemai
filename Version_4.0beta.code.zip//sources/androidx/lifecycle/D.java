package androidx.lifecycle;

import java.util.LinkedHashMap;

public final class D extends E {

    /* renamed from: c  reason: collision with root package name */
    public final LinkedHashMap f659c = new LinkedHashMap();
}
