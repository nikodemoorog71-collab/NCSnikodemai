package androidx.lifecycle;

import a0.c;
import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

public final class w extends C0006f {
    final /* synthetic */ x this$0;

    public static final class a extends C0006f {
        final /* synthetic */ x this$0;

        public a(x xVar) {
            this.this$0 = xVar;
        }

        public void onActivityPostResumed(Activity activity) {
            c.e(activity, "activity");
            this.this$0.b();
        }

        public void onActivityPostStarted(Activity activity) {
            c.e(activity, "activity");
            x xVar = this.this$0;
            int i2 = xVar.f686a + 1;
            xVar.f686a = i2;
            if (i2 == 1 && xVar.f688d) {
                xVar.f.d(k.ON_START);
                xVar.f688d = false;
            }
        }
    }

    public w(x xVar) {
        this.this$0 = xVar;
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        c.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i2 = A.b;
            Fragment findFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            c.c(findFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((A) findFragmentByTag).f652a = this.this$0.f691h;
        }
    }

    public void onActivityPaused(Activity activity) {
        c.e(activity, "activity");
        x xVar = this.this$0;
        int i2 = xVar.b - 1;
        xVar.b = i2;
        if (i2 == 0) {
            Handler handler = xVar.f689e;
            c.b(handler);
            handler.postDelayed(xVar.f690g, 700);
        }
    }

    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        c.e(activity, "activity");
        v.a(activity, new a(this.this$0));
    }

    public void onActivityStopped(Activity activity) {
        c.e(activity, "activity");
        x xVar = this.this$0;
        int i2 = xVar.f686a - 1;
        xVar.f686a = i2;
        if (i2 == 0 && xVar.f687c) {
            xVar.f.d(k.ON_STOP);
            xVar.f688d = true;
        }
    }
}
