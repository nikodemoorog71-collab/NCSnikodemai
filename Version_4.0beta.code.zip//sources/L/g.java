package L;

import androidx.lifecycle.q;

public interface g extends q {
    e a();
}
