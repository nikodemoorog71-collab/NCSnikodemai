package L;

import D.d;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.CompoundButton;
import android.widget.TextView;
import i.C0084t;
import k.C0101c;
import k.C0104f;
import s.C0142a;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public boolean f113a;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f114c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f115d;

    /* renamed from: e  reason: collision with root package name */
    public Parcelable f116e;
    public Object f;

    public /* synthetic */ e(TextView textView) {
        this.f116e = null;
        this.f = null;
        this.f113a = false;
        this.b = false;
        this.f115d = textView;
    }

    public void a() {
        CompoundButton compoundButton = (CompoundButton) this.f115d;
        Drawable a2 = d.a(compoundButton);
        if (a2 == null) {
            return;
        }
        if (this.f113a || this.b) {
            Drawable mutate = a2.mutate();
            if (this.f113a) {
                C0142a.h(mutate, (ColorStateList) this.f116e);
            }
            if (this.b) {
                C0142a.i(mutate, (PorterDuff.Mode) this.f);
            }
            if (mutate.isStateful()) {
                mutate.setState(compoundButton.getDrawableState());
            }
            compoundButton.setButtonDrawable(mutate);
        }
    }

    public void b() {
        C0084t tVar = (C0084t) this.f115d;
        Drawable checkMarkDrawable = tVar.getCheckMarkDrawable();
        if (checkMarkDrawable == null) {
            return;
        }
        if (this.f113a || this.b) {
            Drawable mutate = checkMarkDrawable.mutate();
            if (this.f113a) {
                C0142a.h(mutate, (ColorStateList) this.f116e);
            }
            if (this.b) {
                C0142a.i(mutate, (PorterDuff.Mode) this.f);
            }
            if (mutate.isStateful()) {
                mutate.setState(tVar.getDrawableState());
            }
            tVar.setCheckMarkDrawable(mutate);
        }
    }

    public Bundle c(String str) {
        if (this.b) {
            Bundle bundle = (Bundle) this.f116e;
            if (bundle == null) {
                return null;
            }
            Bundle bundle2 = bundle.getBundle(str);
            Bundle bundle3 = (Bundle) this.f116e;
            if (bundle3 != null) {
                bundle3.remove(str);
            }
            Bundle bundle4 = (Bundle) this.f116e;
            if (bundle4 != null && !bundle4.isEmpty()) {
                return bundle2;
            }
            this.f116e = null;
            return bundle2;
        }
        throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(13:0|1|2|(2:6|7)|10|11|(1:15)|16|(1:18)|19|(1:21)|22|23) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x003e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(android.util.AttributeSet r9, int r10) {
        /*
            r8 = this;
            java.lang.Object r0 = r8.f115d
            r1 = r0
            android.widget.CompoundButton r1 = (android.widget.CompoundButton) r1
            android.content.Context r0 = r1.getContext()
            int[] r3 = d.C0009a.f705m
            C.h r7 = C.h.p(r0, r9, r3, r10)
            java.lang.Object r0 = r7.b
            android.content.res.TypedArray r0 = (android.content.res.TypedArray) r0
            android.content.Context r2 = r1.getContext()
            java.lang.Object r4 = r7.b
            r5 = r4
            android.content.res.TypedArray r5 = (android.content.res.TypedArray) r5
            r4 = r9
            r6 = r10
            y.K.g(r1, r2, r3, r4, r5, r6)
            r9 = 1
            boolean r10 = r0.hasValue(r9)     // Catch:{ all -> 0x003b }
            r2 = 0
            if (r10 == 0) goto L_0x003e
            int r9 = r0.getResourceId(r9, r2)     // Catch:{ all -> 0x003b }
            if (r9 == 0) goto L_0x003e
            android.content.Context r10 = r1.getContext()     // Catch:{ NotFoundException -> 0x003e }
            android.graphics.drawable.Drawable r9 = D.g.s(r10, r9)     // Catch:{ NotFoundException -> 0x003e }
            r1.setButtonDrawable(r9)     // Catch:{ NotFoundException -> 0x003e }
            goto L_0x0055
        L_0x003b:
            r0 = move-exception
            r9 = r0
            goto L_0x007b
        L_0x003e:
            boolean r9 = r0.hasValue(r2)     // Catch:{ all -> 0x003b }
            if (r9 == 0) goto L_0x0055
            int r9 = r0.getResourceId(r2, r2)     // Catch:{ all -> 0x003b }
            if (r9 == 0) goto L_0x0055
            android.content.Context r10 = r1.getContext()     // Catch:{ all -> 0x003b }
            android.graphics.drawable.Drawable r9 = D.g.s(r10, r9)     // Catch:{ all -> 0x003b }
            r1.setButtonDrawable(r9)     // Catch:{ all -> 0x003b }
        L_0x0055:
            r9 = 2
            boolean r10 = r0.hasValue(r9)     // Catch:{ all -> 0x003b }
            if (r10 == 0) goto L_0x0063
            android.content.res.ColorStateList r9 = r7.j(r9)     // Catch:{ all -> 0x003b }
            D.c.c(r1, r9)     // Catch:{ all -> 0x003b }
        L_0x0063:
            r9 = 3
            boolean r10 = r0.hasValue(r9)     // Catch:{ all -> 0x003b }
            if (r10 == 0) goto L_0x0077
            r10 = -1
            int r9 = r0.getInt(r9, r10)     // Catch:{ all -> 0x003b }
            r10 = 0
            android.graphics.PorterDuff$Mode r9 = i.C0074n0.b(r9, r10)     // Catch:{ all -> 0x003b }
            D.c.d(r1, r9)     // Catch:{ all -> 0x003b }
        L_0x0077:
            r7.r()
            return
        L_0x007b:
            r7.r()
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: L.e.d(android.util.AttributeSet, int):void");
    }

    public void e(String str, d dVar) {
        Object obj;
        C0104f fVar = (C0104f) this.f115d;
        C0101c cVar = fVar.f1382a;
        while (cVar != null && !cVar.f1377a.equals(str)) {
            cVar = cVar.f1378c;
        }
        if (cVar != null) {
            obj = cVar.b;
        } else {
            C0101c cVar2 = new C0101c(str, dVar);
            fVar.f1384d++;
            C0101c cVar3 = fVar.b;
            if (cVar3 == null) {
                fVar.f1382a = cVar2;
                fVar.b = cVar2;
            } else {
                cVar3.f1378c = cVar2;
                cVar2.f1379d = cVar3;
                fVar.b = cVar2;
            }
            obj = null;
        }
        if (((d) obj) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
        }
    }

    public e() {
        this.f115d = new C0104f();
        this.f114c = true;
    }
}
