package L;

import android.os.Bundle;
import androidx.activity.d;
import androidx.activity.j;
import androidx.lifecycle.l;
import androidx.lifecycle.s;
import androidx.savedstate.Recreator;
import java.util.ArrayList;
import java.util.Map;
import k.C0102d;
import k.C0104f;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final Object f117a;
    public boolean b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f118c;

    public f(g gVar) {
        this.f117a = gVar;
        this.f118c = new e();
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [L.g, androidx.lifecycle.q, java.lang.Object] */
    public void a() {
        ? r0 = this.f117a;
        s c2 = r0.c();
        if (c2.f679c == l.b) {
            c2.a(new Recreator(r0));
            e eVar = (e) this.f118c;
            eVar.getClass();
            if (!eVar.f113a) {
                c2.a(new b(eVar));
                eVar.f113a = true;
                this.b = true;
                return;
            }
            throw new IllegalStateException("SavedStateRegistry was already attached.");
        }
        throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [androidx.lifecycle.q, java.lang.Object] */
    public void b(Bundle bundle) {
        Bundle bundle2;
        if (!this.b) {
            a();
        }
        s c2 = this.f117a.c();
        if (c2.f679c.compareTo(l.f674d) < 0) {
            e eVar = (e) this.f118c;
            if (!eVar.f113a) {
                throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).");
            } else if (!eVar.b) {
                if (bundle != null) {
                    bundle2 = bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
                } else {
                    bundle2 = null;
                }
                eVar.f116e = bundle2;
                eVar.b = true;
            } else {
                throw new IllegalStateException("SavedStateRegistry was already restored.");
            }
        } else {
            throw new IllegalStateException(("performRestore cannot be called when owner is " + c2.f679c).toString());
        }
    }

    public void c(Bundle bundle) {
        e eVar = (e) this.f118c;
        eVar.getClass();
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = (Bundle) eVar.f116e;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        C0104f fVar = (C0104f) eVar.f115d;
        fVar.getClass();
        C0102d dVar = new C0102d(fVar);
        fVar.f1383c.put(dVar, Boolean.FALSE);
        while (dVar.hasNext()) {
            Map.Entry entry = (Map.Entry) dVar.next();
            bundle2.putBundle((String) entry.getKey(), ((d) entry.getValue()).a());
        }
        if (!bundle2.isEmpty()) {
            bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
        }
    }

    public f(j jVar, d dVar) {
        this.f117a = new Object();
        this.f118c = new ArrayList();
    }
}
