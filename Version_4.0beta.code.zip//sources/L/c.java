package L;

public interface c {
}
