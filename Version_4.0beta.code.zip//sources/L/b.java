package L;

import a0.c;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;

public final /* synthetic */ class b implements o {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f112a;

    public /* synthetic */ b(e eVar) {
        this.f112a = eVar;
    }

    public final void b(q qVar, k kVar) {
        e eVar = this.f112a;
        c.e(eVar, "this$0");
        if (kVar == k.ON_START) {
            eVar.f114c = true;
        } else if (kVar == k.ON_STOP) {
            eVar.f114c = false;
        }
    }
}
