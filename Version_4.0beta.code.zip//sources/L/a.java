package L;

import a0.c;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import nikodemai.firmware.ncs.MainActivity;

public final class a implements d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f111a = 0;
    public final Object b;

    public a(e eVar) {
        c.e(eVar, "registry");
        this.b = new LinkedHashSet();
        eVar.e("androidx.savedstate.Restarter", this);
    }

    public final Bundle a() {
        switch (this.f111a) {
            case 0:
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("classes_to_restore", new ArrayList((LinkedHashSet) this.b));
                return bundle;
            default:
                Bundle bundle2 = new Bundle();
                ((MainActivity) this.b).i().getClass();
                return bundle2;
        }
    }

    public a(MainActivity mainActivity) {
        this.b = mainActivity;
    }
}
