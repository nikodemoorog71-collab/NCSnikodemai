package L;

import android.os.Bundle;

public interface d {
    Bundle a();
}
