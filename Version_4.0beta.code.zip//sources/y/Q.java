package y;

import android.animation.Animator;
import android.view.View;
import i.C0051c;
import java.lang.ref.WeakReference;

public final class Q {

    /* renamed from: a  reason: collision with root package name */
    public final WeakReference f1553a;

    public Q(View view) {
        this.f1553a = new WeakReference(view);
    }

    public final void a(float f) {
        View view = (View) this.f1553a.get();
        if (view != null) {
            view.animate().alpha(f);
        }
    }

    public final void b() {
        View view = (View) this.f1553a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public final void c(long j2) {
        View view = (View) this.f1553a.get();
        if (view != null) {
            view.animate().setDuration(j2);
        }
    }

    public final void d(S s2) {
        View view = (View) this.f1553a.get();
        if (view == null) {
            return;
        }
        if (s2 != null) {
            view.animate().setListener(new C0051c(s2, view));
        } else {
            view.animate().setListener((Animator.AnimatorListener) null);
        }
    }

    public final void e(float f) {
        View view = (View) this.f1553a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
    }
}
