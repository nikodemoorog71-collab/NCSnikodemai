package y;

import C.j;
import android.view.ContentInfo;
import android.view.OnReceiveContentListener;
import android.view.View;
import java.util.Objects;

public abstract class G {
    public static String[] a(View view) {
        return view.getReceiveContentMimeTypes();
    }

    public static C0163g b(View view, C0163g gVar) {
        ContentInfo s2 = gVar.f1585a.s();
        Objects.requireNonNull(s2);
        ContentInfo e2 = C0159c.e(s2);
        ContentInfo performReceiveContent = view.performReceiveContent(e2);
        if (performReceiveContent == null) {
            return null;
        }
        if (performReceiveContent == e2) {
            return gVar;
        }
        return new C0163g(new j(performReceiveContent));
    }

    public static void c(View view, String[] strArr, C0173q qVar) {
        if (qVar == null) {
            view.setOnReceiveContentListener(strArr, (OnReceiveContentListener) null);
        } else {
            view.setOnReceiveContentListener(strArr, new H(qVar));
        }
    }
}
