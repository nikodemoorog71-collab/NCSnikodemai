package y;

import C.j;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeProvider;

/* renamed from: y.a  reason: case insensitive filesystem */
public final class C0157a extends View.AccessibilityDelegate {

    /* renamed from: a  reason: collision with root package name */
    public final C0158b f1572a;

    public C0157a(C0158b bVar) {
        this.f1572a = bVar;
    }

    public final boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        return this.f1572a.f1574a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public final AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
        j jVar;
        AccessibilityNodeProvider accessibilityNodeProvider = this.f1572a.f1574a.getAccessibilityNodeProvider(view);
        if (accessibilityNodeProvider != null) {
            jVar = new j(23, (Object) accessibilityNodeProvider);
        } else {
            jVar = null;
        }
        if (jVar != null) {
            return (AccessibilityNodeProvider) jVar.b;
        }
        return null;
    }

    public final void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        this.f1572a.a(view, accessibilityEvent);
    }

    /* JADX WARNING: type inference failed for: r2v9, types: [java.lang.Object[]] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onInitializeAccessibilityNodeInfo(android.view.View r19, android.view.accessibility.AccessibilityNodeInfo r20) {
        /*
            r18 = this;
            r0 = r19
            r1 = r20
            z.h r3 = new z.h
            r3.<init>(r1)
            java.util.WeakHashMap r4 = y.K.f1547a
            int r4 = android.os.Build.VERSION.SDK_INT
            java.lang.Class<java.lang.Boolean> r5 = java.lang.Boolean.class
            r6 = 28
            r7 = 0
            if (r4 < r6) goto L_0x001d
            boolean r4 = y.D.d(r0)
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r4)
            goto L_0x002c
        L_0x001d:
            r4 = 2131230887(0x7f0800a7, float:1.807784E38)
            java.lang.Object r4 = r0.getTag(r4)
            boolean r8 = r5.isInstance(r4)
            if (r8 == 0) goto L_0x002b
            goto L_0x002c
        L_0x002b:
            r4 = r7
        L_0x002c:
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            r8 = 0
            if (r4 == 0) goto L_0x0039
            boolean r4 = r4.booleanValue()
            if (r4 == 0) goto L_0x0039
            r4 = 1
            goto L_0x003a
        L_0x0039:
            r4 = r8
        L_0x003a:
            int r9 = android.os.Build.VERSION.SDK_INT
            java.lang.String r10 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY"
            if (r9 < r6) goto L_0x0044
            r1.setScreenReaderFocusable(r4)
            goto L_0x0054
        L_0x0044:
            android.os.Bundle r11 = r1.getExtras()
            if (r11 == 0) goto L_0x0054
            int r12 = r11.getInt(r10, r8)
            r12 = r12 & -2
            r4 = r4 | r12
            r11.putInt(r10, r4)
        L_0x0054:
            int r4 = android.os.Build.VERSION.SDK_INT
            if (r4 < r6) goto L_0x0061
            boolean r4 = y.D.c(r0)
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r4)
            goto L_0x0070
        L_0x0061:
            r4 = 2131230882(0x7f0800a2, float:1.807783E38)
            java.lang.Object r4 = r0.getTag(r4)
            boolean r5 = r5.isInstance(r4)
            if (r5 == 0) goto L_0x006f
            goto L_0x0070
        L_0x006f:
            r4 = r7
        L_0x0070:
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            if (r4 == 0) goto L_0x007c
            boolean r4 = r4.booleanValue()
            if (r4 == 0) goto L_0x007c
            r4 = 1
            goto L_0x007d
        L_0x007c:
            r4 = r8
        L_0x007d:
            if (r9 < r6) goto L_0x0083
            r1.setHeading(r4)
            goto L_0x0098
        L_0x0083:
            android.os.Bundle r5 = r1.getExtras()
            if (r5 == 0) goto L_0x0098
            int r11 = r5.getInt(r10, r8)
            r11 = r11 & -3
            if (r4 == 0) goto L_0x0093
            r4 = 2
            goto L_0x0094
        L_0x0093:
            r4 = r8
        L_0x0094:
            r4 = r4 | r11
            r5.putInt(r10, r4)
        L_0x0098:
            java.lang.Class<java.lang.CharSequence> r4 = java.lang.CharSequence.class
            if (r9 < r6) goto L_0x00a1
            java.lang.CharSequence r5 = y.D.b(r0)
            goto L_0x00b0
        L_0x00a1:
            r5 = 2131230883(0x7f0800a3, float:1.8077831E38)
            java.lang.Object r5 = r0.getTag(r5)
            boolean r10 = r4.isInstance(r5)
            if (r10 == 0) goto L_0x00af
            goto L_0x00b0
        L_0x00af:
            r5 = r7
        L_0x00b0:
            java.lang.CharSequence r5 = (java.lang.CharSequence) r5
            if (r9 < r6) goto L_0x00b8
            r1.setPaneTitle(r5)
            goto L_0x00c1
        L_0x00b8:
            android.os.Bundle r6 = r1.getExtras()
            java.lang.String r10 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY"
            r6.putCharSequence(r10, r5)
        L_0x00c1:
            r5 = 30
            if (r9 < r5) goto L_0x00ca
            java.lang.CharSequence r4 = y.F.b(r0)
            goto L_0x00da
        L_0x00ca:
            r6 = 2131230888(0x7f0800a8, float:1.8077841E38)
            java.lang.Object r6 = r0.getTag(r6)
            boolean r4 = r4.isInstance(r6)
            if (r4 == 0) goto L_0x00d9
            r4 = r6
            goto L_0x00da
        L_0x00d9:
            r4 = r7
        L_0x00da:
            java.lang.CharSequence r4 = (java.lang.CharSequence) r4
            if (r9 < r5) goto L_0x00e4
            z.C0185d.c(r1, r4)
        L_0x00e1:
            r4 = r18
            goto L_0x00ee
        L_0x00e4:
            android.os.Bundle r5 = r1.getExtras()
            java.lang.String r6 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"
            r5.putCharSequence(r6, r4)
            goto L_0x00e1
        L_0x00ee:
            y.b r5 = r4.f1572a
            r5.b(r0, r3)
            java.lang.CharSequence r5 = r1.getText()
            r6 = 26
            if (r9 >= r6) goto L_0x0214
            android.os.Bundle r6 = r1.getExtras()
            java.lang.String r9 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY"
            r6.remove(r9)
            android.os.Bundle r6 = r1.getExtras()
            java.lang.String r10 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY"
            r6.remove(r10)
            android.os.Bundle r6 = r1.getExtras()
            java.lang.String r11 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY"
            r6.remove(r11)
            android.os.Bundle r6 = r1.getExtras()
            java.lang.String r12 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY"
            r6.remove(r12)
            r6 = 2131230881(0x7f0800a1, float:1.8077827E38)
            java.lang.Object r13 = r0.getTag(r6)
            android.util.SparseArray r13 = (android.util.SparseArray) r13
            if (r13 == 0) goto L_0x0165
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
            r15 = r8
            r16 = 1
        L_0x0132:
            int r2 = r13.size()
            if (r15 >= r2) goto L_0x014e
            java.lang.Object r2 = r13.valueAt(r15)
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2
            java.lang.Object r2 = r2.get()
            if (r2 != 0) goto L_0x014b
            java.lang.Integer r2 = java.lang.Integer.valueOf(r15)
            r14.add(r2)
        L_0x014b:
            int r15 = r15 + 1
            goto L_0x0132
        L_0x014e:
            r2 = r8
        L_0x014f:
            int r15 = r14.size()
            if (r2 >= r15) goto L_0x0167
            java.lang.Object r15 = r14.get(r2)
            java.lang.Integer r15 = (java.lang.Integer) r15
            int r15 = r15.intValue()
            r13.remove(r15)
            int r2 = r2 + 1
            goto L_0x014f
        L_0x0165:
            r16 = 1
        L_0x0167:
            boolean r2 = r5 instanceof android.text.Spanned
            if (r2 == 0) goto L_0x017b
            r2 = r5
            android.text.Spanned r2 = (android.text.Spanned) r2
            int r7 = r5.length()
            java.lang.Class<android.text.style.ClickableSpan> r13 = android.text.style.ClickableSpan.class
            java.lang.Object[] r2 = r2.getSpans(r8, r7, r13)
            r7 = r2
            android.text.style.ClickableSpan[] r7 = (android.text.style.ClickableSpan[]) r7
        L_0x017b:
            if (r7 == 0) goto L_0x0216
            int r2 = r7.length
            if (r2 <= 0) goto L_0x0216
            android.os.Bundle r1 = r1.getExtras()
            java.lang.String r2 = "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY"
            r13 = 2131230726(0x7f080006, float:1.8077513E38)
            r1.putInt(r2, r13)
            java.lang.Object r1 = r0.getTag(r6)
            android.util.SparseArray r1 = (android.util.SparseArray) r1
            if (r1 != 0) goto L_0x019c
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r0.setTag(r6, r1)
        L_0x019c:
            r2 = r8
        L_0x019d:
            int r6 = r7.length
            if (r2 >= r6) goto L_0x0216
            r6 = r7[r2]
            r13 = r8
        L_0x01a3:
            int r14 = r1.size()
            if (r13 >= r14) goto L_0x01c3
            java.lang.Object r14 = r1.valueAt(r13)
            java.lang.ref.WeakReference r14 = (java.lang.ref.WeakReference) r14
            java.lang.Object r14 = r14.get()
            android.text.style.ClickableSpan r14 = (android.text.style.ClickableSpan) r14
            boolean r14 = r6.equals(r14)
            if (r14 == 0) goto L_0x01c0
            int r6 = r1.keyAt(r13)
            goto L_0x01c9
        L_0x01c0:
            int r13 = r13 + 1
            goto L_0x01a3
        L_0x01c3:
            int r6 = z.C0189h.b
            int r13 = r6 + 1
            z.C0189h.b = r13
        L_0x01c9:
            java.lang.ref.WeakReference r13 = new java.lang.ref.WeakReference
            r14 = r7[r2]
            r13.<init>(r14)
            r1.put(r6, r13)
            r13 = r7[r2]
            r14 = r5
            android.text.Spanned r14 = (android.text.Spanned) r14
            java.util.ArrayList r15 = r3.a(r9)
            int r17 = r14.getSpanStart(r13)
            java.lang.Integer r8 = java.lang.Integer.valueOf(r17)
            r15.add(r8)
            java.util.ArrayList r8 = r3.a(r10)
            int r15 = r14.getSpanEnd(r13)
            java.lang.Integer r15 = java.lang.Integer.valueOf(r15)
            r8.add(r15)
            java.util.ArrayList r8 = r3.a(r11)
            int r13 = r14.getSpanFlags(r13)
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            r8.add(r13)
            java.util.ArrayList r8 = r3.a(r12)
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r8.add(r6)
            int r2 = r2 + 1
            r8 = 0
            goto L_0x019d
        L_0x0214:
            r16 = 1
        L_0x0216:
            r1 = 2131230880(0x7f0800a0, float:1.8077825E38)
            java.lang.Object r0 = r0.getTag(r1)
            java.util.List r0 = (java.util.List) r0
            if (r0 != 0) goto L_0x0223
            java.util.List r0 = java.util.Collections.EMPTY_LIST
        L_0x0223:
            r8 = 0
        L_0x0224:
            int r1 = r0.size()
            if (r8 >= r1) goto L_0x023c
            java.lang.Object r1 = r0.get(r8)
            z.c r1 = (z.C0184c) r1
            java.lang.Object r1 = r1.f1611a
            android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction r1 = (android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction) r1
            android.view.accessibility.AccessibilityNodeInfo r2 = r3.f1612a
            r2.addAction(r1)
            int r8 = r8 + 1
            goto L_0x0224
        L_0x023c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y.C0157a.onInitializeAccessibilityNodeInfo(android.view.View, android.view.accessibility.AccessibilityNodeInfo):void");
    }

    public final void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
        this.f1572a.f1574a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public final boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f1572a.f1574a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public final boolean performAccessibilityAction(View view, int i2, Bundle bundle) {
        return this.f1572a.c(view, i2, bundle);
    }

    public final void sendAccessibilityEvent(View view, int i2) {
        this.f1572a.f1574a.sendAccessibilityEvent(view, i2);
    }

    public final void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
        this.f1572a.f1574a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }
}
