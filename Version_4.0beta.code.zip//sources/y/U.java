package y;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import r.C0136c;

public final class U extends X {

    /* renamed from: c  reason: collision with root package name */
    public static Field f1557c = null;

    /* renamed from: d  reason: collision with root package name */
    public static boolean f1558d = false;

    /* renamed from: e  reason: collision with root package name */
    public static Constructor f1559e = null;
    public static boolean f = false;

    /* renamed from: a  reason: collision with root package name */
    public WindowInsets f1560a;
    public C0136c b;

    public U() {
        this.f1560a = e();
    }

    private static WindowInsets e() {
        Class<WindowInsets> cls = WindowInsets.class;
        if (!f1558d) {
            try {
                f1557c = cls.getDeclaredField("CONSUMED");
            } catch (ReflectiveOperationException e2) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
            }
            f1558d = true;
        }
        Field field = f1557c;
        if (field != null) {
            try {
                WindowInsets windowInsets = (WindowInsets) field.get((Object) null);
                if (windowInsets != null) {
                    return new WindowInsets(windowInsets);
                }
            } catch (ReflectiveOperationException e3) {
                Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
            }
        }
        if (!f) {
            try {
                f1559e = cls.getConstructor(new Class[]{Rect.class});
            } catch (ReflectiveOperationException e4) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
            }
            f = true;
        }
        Constructor constructor = f1559e;
        if (constructor != null) {
            try {
                return (WindowInsets) constructor.newInstance(new Object[]{new Rect()});
            } catch (ReflectiveOperationException e5) {
                Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
            }
        }
        return null;
    }

    public f0 b() {
        a();
        f0 c2 = f0.c(this.f1560a, (View) null);
        d0 d0Var = c2.f1584a;
        d0Var.o((C0136c[]) null);
        d0Var.q(this.b);
        return c2;
    }

    public void c(C0136c cVar) {
        this.b = cVar;
    }

    public void d(C0136c cVar) {
        WindowInsets windowInsets = this.f1560a;
        if (windowInsets != null) {
            this.f1560a = windowInsets.replaceSystemWindowInsets(cVar.f1500a, cVar.b, cVar.f1501c, cVar.f1502d);
        }
    }

    public U(f0 f0Var) {
        super(f0Var);
        this.f1560a = f0Var.b();
    }
}
