package y;

import android.net.Uri;
import android.os.Bundle;

/* renamed from: y.d  reason: case insensitive filesystem */
public interface C0160d {
    void a(Bundle bundle);

    void e(Uri uri);

    C0163g k();

    void w(int i2);
}
