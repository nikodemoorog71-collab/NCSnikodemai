package y;

import android.view.View;
import android.view.WindowInsets;

/* renamed from: y.y  reason: case insensitive filesystem */
public abstract class C0180y {
    public static WindowInsets a(View view, WindowInsets windowInsets) {
        return view.dispatchApplyWindowInsets(windowInsets);
    }

    public static WindowInsets b(View view, WindowInsets windowInsets) {
        return view.onApplyWindowInsets(windowInsets);
    }

    public static void c(View view) {
        view.requestApplyInsets();
    }
}
