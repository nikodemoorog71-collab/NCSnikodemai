package K;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Objects;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public final int f104a;
    public final int b;

    /* renamed from: c  reason: collision with root package name */
    public final long f105c;

    /* renamed from: d  reason: collision with root package name */
    public final long f106d;

    public n(int i2, int i3, long j2, long j3) {
        this.f104a = i2;
        this.b = i3;
        this.f105c = j2;
        this.f106d = j3;
    }

    public static n a(File file) {
        Throwable th;
        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
        try {
            n nVar = new n(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readLong(), dataInputStream.readLong());
            dataInputStream.close();
            return nVar;
        } catch (Throwable th2) {
            th.addSuppressed(th2);
        }
        throw th;
    }

    public final void b(File file) {
        file.delete();
        DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
        try {
            dataOutputStream.writeInt(this.f104a);
            dataOutputStream.writeInt(this.b);
            dataOutputStream.writeLong(this.f105c);
            dataOutputStream.writeLong(this.f106d);
            dataOutputStream.close();
            return;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && (obj instanceof n)) {
            n nVar = (n) obj;
            if (this.b == nVar.b && this.f105c == nVar.f105c && this.f104a == nVar.f104a && this.f106d == nVar.f106d) {
                return true;
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(new Object[]{Integer.valueOf(this.b), Long.valueOf(this.f105c), Integer.valueOf(this.f104a), Long.valueOf(this.f106d)});
    }
}
