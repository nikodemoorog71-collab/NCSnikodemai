package K;

import android.content.Context;

public final /* synthetic */ class i implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f102a;
    public final /* synthetic */ Context b;

    public /* synthetic */ i(Context context, int i2) {
        this.f102a = i2;
        this.b = context;
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.util.concurrent.Executor, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x005f, code lost:
        if (r2 != null) goto L_0x0064;
     */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x006e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r11 = this;
            int r0 = r11.f102a
            switch(r0) {
                case 0: goto L_0x0097;
                case 1: goto L_0x0089;
                default: goto L_0x0005;
            }
        L_0x0005:
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 1
            r2 = 33
            if (r0 < r2) goto L_0x0086
            android.content.ComponentName r3 = new android.content.ComponentName
            android.content.Context r4 = r11.b
            java.lang.String r5 = "androidx.appcompat.app.AppLocalesMetadataHolderService"
            r3.<init>(r4, r5)
            android.content.pm.PackageManager r5 = r4.getPackageManager()
            int r5 = r5.getComponentEnabledSetting(r3)
            if (r5 == r1) goto L_0x0086
            java.lang.String r5 = "locale"
            if (r0 < r2) goto L_0x005d
            l.c r0 = e.o.f875g
            java.util.Iterator r0 = r0.iterator()
        L_0x0029:
            r2 = r0
            l.g r2 = (l.C0111g) r2
            boolean r6 = r2.hasNext()
            if (r6 == 0) goto L_0x004b
            java.lang.Object r2 = r2.next()
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2
            java.lang.Object r2 = r2.get()
            e.o r2 = (e.o) r2
            if (r2 == 0) goto L_0x0029
            e.C r2 = (e.C0012C) r2
            android.content.Context r2 = r2.f766k
            if (r2 == 0) goto L_0x0029
            java.lang.Object r0 = r2.getSystemService(r5)
            goto L_0x004c
        L_0x004b:
            r0 = 0
        L_0x004c:
            if (r0 == 0) goto L_0x0062
            android.os.LocaleList r0 = e.C0024l.a(r0)
            u.c r2 = new u.c
            u.d r6 = new u.d
            r6.<init>(r0)
            r2.<init>(r6)
            goto L_0x0064
        L_0x005d:
            u.c r2 = e.o.f872c
            if (r2 == 0) goto L_0x0062
            goto L_0x0064
        L_0x0062:
            u.c r2 = u.C0150c.b
        L_0x0064:
            u.d r0 = r2.f1522a
            android.os.LocaleList r0 = r0.f1523a
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L_0x007f
            java.lang.String r0 = o.e.f(r4)
            java.lang.Object r2 = r4.getSystemService(r5)
            if (r2 == 0) goto L_0x007f
            android.os.LocaleList r0 = e.C0023k.a(r0)
            e.C0024l.b(r2, r0)
        L_0x007f:
            android.content.pm.PackageManager r0 = r4.getPackageManager()
            r0.setComponentEnabledSetting(r3, r1, r1)
        L_0x0086:
            e.o.f = r1
            return
        L_0x0089:
            K.e r0 = new K.e
            r0.<init>()
            F.d r1 = K.g.f92a
            r2 = 0
            android.content.Context r3 = r11.b
            K.g.s(r3, r0, r1, r2)
            return
        L_0x0097:
            java.util.concurrent.ThreadPoolExecutor r4 = new java.util.concurrent.ThreadPoolExecutor
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.MILLISECONDS
            java.util.concurrent.LinkedBlockingQueue r10 = new java.util.concurrent.LinkedBlockingQueue
            r10.<init>()
            r6 = 1
            r7 = 0
            r5 = 0
            r4.<init>(r5, r6, r7, r9, r10)
            K.i r0 = new K.i
            android.content.Context r1 = r11.b
            r2 = 1
            r0.<init>(r1, r2)
            r4.execute(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: K.i.run():void");
    }
}
