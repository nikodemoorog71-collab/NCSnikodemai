package K;

import java.io.Serializable;

public interface f {
    void l(int i2, Serializable serializable);

    void q();
}
