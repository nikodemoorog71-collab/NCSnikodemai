package K;

import android.content.res.AssetManager;
import android.os.Build;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.concurrent.Executor;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final Executor f79a;
    public final f b;

    /* renamed from: c  reason: collision with root package name */
    public final byte[] f80c;

    /* renamed from: d  reason: collision with root package name */
    public final File f81d;

    /* renamed from: e  reason: collision with root package name */
    public final String f82e;
    public boolean f = false;

    /* renamed from: g  reason: collision with root package name */
    public c[] f83g;

    /* renamed from: h  reason: collision with root package name */
    public byte[] f84h;

    public b(AssetManager assetManager, Executor executor, f fVar, String str, File file) {
        this.f79a = executor;
        this.b = fVar;
        this.f82e = str;
        this.f81d = file;
        int i2 = Build.VERSION.SDK_INT;
        byte[] bArr = null;
        if (i2 <= 34) {
            switch (i2) {
                case 24:
                case 25:
                    bArr = g.f97h;
                    break;
                case 26:
                    bArr = g.f96g;
                    break;
                case 27:
                    bArr = g.f;
                    break;
                case 28:
                case 29:
                case 30:
                    bArr = g.f95e;
                    break;
                case 31:
                case 32:
                case 33:
                case 34:
                    bArr = g.f94d;
                    break;
            }
        }
        this.f80c = bArr;
    }

    public final FileInputStream a(AssetManager assetManager, String str) {
        try {
            return assetManager.openFd(str).createInputStream();
        } catch (FileNotFoundException e2) {
            String message = e2.getMessage();
            if (message == null || !message.contains("compressed")) {
                return null;
            }
            this.b.q();
            return null;
        }
    }

    public final void b(int i2, Serializable serializable) {
        this.f79a.execute(new a(this, i2, serializable));
    }
}
