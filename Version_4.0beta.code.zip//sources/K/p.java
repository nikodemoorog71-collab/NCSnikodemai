package K;

public final class p {

    /* renamed from: a  reason: collision with root package name */
    public final int f109a;
    public final byte[] b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f110c;

    public p(int i2, byte[] bArr, boolean z2) {
        this.f109a = i2;
        this.b = bArr;
        this.f110c = z2;
    }
}
