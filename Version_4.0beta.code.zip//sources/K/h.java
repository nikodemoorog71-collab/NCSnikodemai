package K;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.profileinstaller.ProfileInstallerInitializer;
import e.m;
import i.U;
import java.util.Random;

public final /* synthetic */ class h implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f100a;
    public final /* synthetic */ Object b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f101c;

    public /* synthetic */ h(Object obj, int i2, Object obj2) {
        this.f100a = i2;
        this.b = obj;
        this.f101c = obj2;
    }

    public final void run() {
        Handler handler;
        switch (this.f100a) {
            case 0:
                ((ProfileInstallerInitializer) this.b).getClass();
                if (Build.VERSION.SDK_INT >= 28) {
                    handler = l.a(Looper.getMainLooper());
                } else {
                    handler = new Handler(Looper.getMainLooper());
                }
                handler.postDelayed(new i((Context) this.f101c, 0), (long) (new Random().nextInt(Math.max(1000, 1)) + 5000));
                return;
            case 1:
                Runnable runnable = (Runnable) this.f101c;
                m mVar = (m) this.b;
                mVar.getClass();
                try {
                    runnable.run();
                    return;
                } finally {
                    mVar.a();
                }
            default:
                ((U) this.b).b((Typeface) this.f101c);
                return;
        }
    }
}
