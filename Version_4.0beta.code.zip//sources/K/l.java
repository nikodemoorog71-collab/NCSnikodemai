package K;

import android.os.Handler;
import android.os.Looper;

public abstract class l {
    public static Handler a(Looper looper) {
        return Handler.createAsync(looper);
    }
}
