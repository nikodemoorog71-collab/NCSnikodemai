package K;

import android.view.Choreographer;

public final /* synthetic */ class j implements Choreographer.FrameCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Runnable f103a;

    public /* synthetic */ j(Runnable runnable) {
        this.f103a = runnable;
    }

    public final void doFrame(long j2) {
        this.f103a.run();
    }
}
