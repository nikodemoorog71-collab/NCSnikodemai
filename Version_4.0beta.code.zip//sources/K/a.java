package K;

import java.io.Serializable;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f77a;
    public final /* synthetic */ int b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Serializable f78c;

    public /* synthetic */ a(b bVar, int i2, Serializable serializable) {
        this.f77a = bVar;
        this.b = i2;
        this.f78c = serializable;
    }

    public final void run() {
        this.f77a.b.l(this.b, this.f78c);
    }
}
