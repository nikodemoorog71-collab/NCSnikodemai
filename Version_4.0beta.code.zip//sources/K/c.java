package K;

import java.util.TreeMap;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final String f85a;
    public final String b;

    /* renamed from: c  reason: collision with root package name */
    public final long f86c;

    /* renamed from: d  reason: collision with root package name */
    public long f87d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f88e;
    public final int f;

    /* renamed from: g  reason: collision with root package name */
    public final int f89g;

    /* renamed from: h  reason: collision with root package name */
    public int[] f90h;

    /* renamed from: i  reason: collision with root package name */
    public final TreeMap f91i;

    public c(String str, String str2, long j2, int i2, int i3, int i4, int[] iArr, TreeMap treeMap) {
        this.f85a = str;
        this.b = str2;
        this.f86c = j2;
        this.f88e = i2;
        this.f = i3;
        this.f89g = i4;
        this.f90h = iArr;
        this.f91i = treeMap;
    }
}
