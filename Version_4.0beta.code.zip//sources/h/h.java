package h;

import C.j;
import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.transition.Transition;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import i.C0085t0;
import i.I0;
import i.L0;
import java.util.ArrayList;
import nikodemai.firmware.ncs.R;

public final class h extends v implements View.OnKeyListener, PopupWindow.OnDismissListener {
    public final Context b;

    /* renamed from: c  reason: collision with root package name */
    public final int f998c;

    /* renamed from: d  reason: collision with root package name */
    public final int f999d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f1000e;
    public final Handler f;

    /* renamed from: g  reason: collision with root package name */
    public final ArrayList f1001g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    public final ArrayList f1002h = new ArrayList();

    /* renamed from: i  reason: collision with root package name */
    public final C0040d f1003i = new C0040d(0, this);

    /* renamed from: j  reason: collision with root package name */
    public final C0041e f1004j = new C0041e(this, 0);

    /* renamed from: k  reason: collision with root package name */
    public final j f1005k = new j(15, (Object) this);

    /* renamed from: l  reason: collision with root package name */
    public int f1006l;

    /* renamed from: m  reason: collision with root package name */
    public int f1007m;

    /* renamed from: n  reason: collision with root package name */
    public View f1008n;

    /* renamed from: o  reason: collision with root package name */
    public View f1009o;

    /* renamed from: p  reason: collision with root package name */
    public int f1010p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f1011q;

    /* renamed from: r  reason: collision with root package name */
    public boolean f1012r;

    /* renamed from: s  reason: collision with root package name */
    public int f1013s;

    /* renamed from: t  reason: collision with root package name */
    public int f1014t;

    /* renamed from: u  reason: collision with root package name */
    public boolean f1015u;

    /* renamed from: v  reason: collision with root package name */
    public boolean f1016v;

    /* renamed from: w  reason: collision with root package name */
    public y f1017w;

    /* renamed from: x  reason: collision with root package name */
    public ViewTreeObserver f1018x;

    /* renamed from: y  reason: collision with root package name */
    public w f1019y;

    /* renamed from: z  reason: collision with root package name */
    public boolean f1020z;

    public h(Context context, View view, int i2, boolean z2) {
        int i3 = 0;
        this.f1006l = 0;
        this.f1007m = 0;
        this.b = context;
        this.f1008n = view;
        this.f999d = i2;
        this.f1000e = z2;
        this.f1015u = false;
        this.f1010p = view.getLayoutDirection() != 1 ? 1 : i3;
        Resources resources = context.getResources();
        this.f998c = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f = new Handler();
    }

    public final boolean a() {
        ArrayList arrayList = this.f1002h;
        if (arrayList.size() <= 0 || !((g) arrayList.get(0)).f996a.f1141y.isShowing()) {
            return false;
        }
        return true;
    }

    public final void b(n nVar, boolean z2) {
        int i2;
        ArrayList arrayList = this.f1002h;
        int size = arrayList.size();
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                i3 = -1;
                break;
            } else if (nVar == ((g) arrayList.get(i3)).b) {
                break;
            } else {
                i3++;
            }
        }
        if (i3 >= 0) {
            int i4 = i3 + 1;
            if (i4 < arrayList.size()) {
                ((g) arrayList.get(i4)).b.c(false);
            }
            g gVar = (g) arrayList.remove(i3);
            gVar.b.r(this);
            boolean z3 = this.f1020z;
            L0 l0 = gVar.f996a;
            if (z3) {
                I0.b(l0.f1141y, (Transition) null);
                l0.f1141y.setAnimationStyle(0);
            }
            l0.dismiss();
            int size2 = arrayList.size();
            if (size2 > 0) {
                this.f1010p = ((g) arrayList.get(size2 - 1)).f997c;
            } else {
                if (this.f1008n.getLayoutDirection() == 1) {
                    i2 = 0;
                } else {
                    i2 = 1;
                }
                this.f1010p = i2;
            }
            if (size2 == 0) {
                dismiss();
                y yVar = this.f1017w;
                if (yVar != null) {
                    yVar.b(nVar, true);
                }
                ViewTreeObserver viewTreeObserver = this.f1018x;
                if (viewTreeObserver != null) {
                    if (viewTreeObserver.isAlive()) {
                        this.f1018x.removeGlobalOnLayoutListener(this.f1003i);
                    }
                    this.f1018x = null;
                }
                this.f1009o.removeOnAttachStateChangeListener(this.f1004j);
                this.f1019y.onDismiss();
            } else if (z2) {
                ((g) arrayList.get(0)).b.c(false);
            }
        }
    }

    public final void c() {
        ArrayList arrayList = this.f1002h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            ListAdapter adapter = ((g) obj).f996a.f1120c.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((k) adapter).notifyDataSetChanged();
        }
    }

    public final void dismiss() {
        ArrayList arrayList = this.f1002h;
        int size = arrayList.size();
        if (size > 0) {
            g[] gVarArr = (g[]) arrayList.toArray(new g[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                g gVar = gVarArr[i2];
                if (gVar.f996a.f1141y.isShowing()) {
                    gVar.f996a.dismiss();
                }
            }
        }
    }

    public final void e(y yVar) {
        this.f1017w = yVar;
    }

    public final C0085t0 f() {
        ArrayList arrayList = this.f1002h;
        if (arrayList.isEmpty()) {
            return null;
        }
        return ((g) arrayList.get(arrayList.size() - 1)).f996a.f1120c;
    }

    public final void h() {
        if (!a()) {
            ArrayList arrayList = this.f1001g;
            int size = arrayList.size();
            boolean z2 = false;
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                v((n) obj);
            }
            arrayList.clear();
            View view = this.f1008n;
            this.f1009o = view;
            if (view != null) {
                if (this.f1018x == null) {
                    z2 = true;
                }
                ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
                this.f1018x = viewTreeObserver;
                if (z2) {
                    viewTreeObserver.addOnGlobalLayoutListener(this.f1003i);
                }
                this.f1009o.addOnAttachStateChangeListener(this.f1004j);
            }
        }
    }

    public final boolean i() {
        return false;
    }

    public final boolean j(F f2) {
        ArrayList arrayList = this.f1002h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            g gVar = (g) obj;
            if (f2 == gVar.b) {
                gVar.f996a.f1120c.requestFocus();
                return true;
            }
        }
        if (!f2.hasVisibleItems()) {
            return false;
        }
        l(f2);
        y yVar = this.f1017w;
        if (yVar != null) {
            yVar.m(f2);
        }
        return true;
    }

    public final void l(n nVar) {
        nVar.b(this, this.b);
        if (a()) {
            v(nVar);
        } else {
            this.f1001g.add(nVar);
        }
    }

    public final void n(View view) {
        if (this.f1008n != view) {
            this.f1008n = view;
            this.f1007m = Gravity.getAbsoluteGravity(this.f1006l, view.getLayoutDirection());
        }
    }

    public final void o(boolean z2) {
        this.f1015u = z2;
    }

    public final void onDismiss() {
        g gVar;
        ArrayList arrayList = this.f1002h;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                gVar = null;
                break;
            }
            gVar = (g) arrayList.get(i2);
            if (!gVar.f996a.f1141y.isShowing()) {
                break;
            }
            i2++;
        }
        if (gVar != null) {
            gVar.b.c(false);
        }
    }

    public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    public final void p(int i2) {
        if (this.f1006l != i2) {
            this.f1006l = i2;
            this.f1007m = Gravity.getAbsoluteGravity(i2, this.f1008n.getLayoutDirection());
        }
    }

    public final void q(int i2) {
        this.f1011q = true;
        this.f1013s = i2;
    }

    public final void r(PopupWindow.OnDismissListener onDismissListener) {
        this.f1019y = (w) onDismissListener;
    }

    public final void s(boolean z2) {
        this.f1016v = z2;
    }

    public final void t(int i2) {
        this.f1012r = true;
        this.f1014t = i2;
    }

    /* JADX WARNING: type inference failed for: r7v0, types: [i.L0, i.G0] */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x0146, code lost:
        if (((r8.getWidth() + r11[0]) + r5) > r9.right) goto L_0x0148;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x014b, code lost:
        r8 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x0150, code lost:
        if ((r11[0] - r5) < 0) goto L_0x014b;
     */
    /* JADX WARNING: Removed duplicated region for block: B:104:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00ef  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x01ba  */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x01f4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void v(h.n r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            android.content.Context r2 = r0.b
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r2)
            h.k r4 = new h.k
            boolean r5 = r0.f1000e
            r6 = 2131427339(0x7f0b000b, float:1.8476291E38)
            r4.<init>(r1, r3, r5, r6)
            boolean r5 = r0.a()
            r6 = 1
            if (r5 != 0) goto L_0x0022
            boolean r5 = r0.f1015u
            if (r5 == 0) goto L_0x0022
            r4.f1027c = r6
            goto L_0x002e
        L_0x0022:
            boolean r5 = r0.a()
            if (r5 == 0) goto L_0x002e
            boolean r5 = h.v.u(r1)
            r4.f1027c = r5
        L_0x002e:
            int r5 = r0.f998c
            int r5 = h.v.m(r4, r2, r5)
            i.L0 r7 = new i.L0
            int r8 = r0.f999d
            r9 = 0
            r7.<init>(r2, r9, r8)
            C.j r2 = r0.f1005k
            r7.f1156B = r2
            r7.f1132p = r0
            i.D r2 = r7.f1141y
            r2.setOnDismissListener(r0)
            android.view.View r2 = r0.f1008n
            r7.f1131o = r2
            int r2 = r0.f1007m
            r7.f1128l = r2
            r7.f1140x = r6
            i.D r2 = r7.f1141y
            r2.setFocusable(r6)
            i.D r2 = r7.f1141y
            r8 = 2
            r2.setInputMethodMode(r8)
            r7.m(r4)
            r7.p(r5)
            int r2 = r0.f1007m
            r7.f1128l = r2
            java.util.ArrayList r2 = r0.f1002h
            int r4 = r2.size()
            r10 = 0
            if (r4 <= 0) goto L_0x00e9
            int r4 = r2.size()
            int r4 = r4 - r6
            java.lang.Object r4 = r2.get(r4)
            h.g r4 = (h.g) r4
            h.n r11 = r4.b
            java.util.ArrayList r12 = r11.f
            int r12 = r12.size()
            r13 = r10
        L_0x0083:
            if (r13 >= r12) goto L_0x0099
            android.view.MenuItem r14 = r11.getItem(r13)
            boolean r15 = r14.hasSubMenu()
            if (r15 == 0) goto L_0x0096
            android.view.SubMenu r15 = r14.getSubMenu()
            if (r1 != r15) goto L_0x0096
            goto L_0x009a
        L_0x0096:
            int r13 = r13 + 1
            goto L_0x0083
        L_0x0099:
            r14 = r9
        L_0x009a:
            if (r14 != 0) goto L_0x00a0
            r16 = r6
            r6 = r9
            goto L_0x00ed
        L_0x00a0:
            i.L0 r11 = r4.f996a
            i.t0 r11 = r11.f1120c
            android.widget.ListAdapter r12 = r11.getAdapter()
            boolean r13 = r12 instanceof android.widget.HeaderViewListAdapter
            if (r13 == 0) goto L_0x00b9
            android.widget.HeaderViewListAdapter r12 = (android.widget.HeaderViewListAdapter) r12
            int r13 = r12.getHeadersCount()
            android.widget.ListAdapter r12 = r12.getWrappedAdapter()
            h.k r12 = (h.k) r12
            goto L_0x00bc
        L_0x00b9:
            h.k r12 = (h.k) r12
            r13 = r10
        L_0x00bc:
            int r15 = r12.getCount()
            r16 = r6
            r6 = r10
        L_0x00c3:
            r8 = -1
            if (r6 >= r15) goto L_0x00d1
            h.p r9 = r12.getItem(r6)
            if (r14 != r9) goto L_0x00cd
            goto L_0x00d2
        L_0x00cd:
            int r6 = r6 + 1
            r9 = 0
            goto L_0x00c3
        L_0x00d1:
            r6 = r8
        L_0x00d2:
            if (r6 != r8) goto L_0x00d5
            goto L_0x00ec
        L_0x00d5:
            int r6 = r6 + r13
            int r8 = r11.getFirstVisiblePosition()
            int r6 = r6 - r8
            if (r6 < 0) goto L_0x00ec
            int r8 = r11.getChildCount()
            if (r6 < r8) goto L_0x00e4
            goto L_0x00ec
        L_0x00e4:
            android.view.View r6 = r11.getChildAt(r6)
            goto L_0x00ed
        L_0x00e9:
            r16 = r6
            r4 = 0
        L_0x00ec:
            r6 = 0
        L_0x00ed:
            if (r6 == 0) goto L_0x01ba
            int r8 = android.os.Build.VERSION.SDK_INT
            i.D r9 = r7.f1141y
            r11 = 28
            if (r8 > r11) goto L_0x010d
            java.lang.reflect.Method r8 = i.L0.f1155C
            if (r8 == 0) goto L_0x0110
            java.lang.Boolean r11 = java.lang.Boolean.FALSE     // Catch:{ Exception -> 0x0105 }
            java.lang.Object[] r11 = new java.lang.Object[]{r11}     // Catch:{ Exception -> 0x0105 }
            r8.invoke(r9, r11)     // Catch:{ Exception -> 0x0105 }
            goto L_0x0110
        L_0x0105:
            java.lang.String r8 = "MenuPopupWindow"
            java.lang.String r9 = "Could not invoke setTouchModal() on PopupWindow. Oh well."
            android.util.Log.i(r8, r9)
            goto L_0x0110
        L_0x010d:
            i.J0.a(r9, r10)
        L_0x0110:
            i.D r8 = r7.f1141y
            r9 = 0
            i.I0.a(r8, r9)
            int r8 = r2.size()
            int r8 = r8 + -1
            java.lang.Object r8 = r2.get(r8)
            h.g r8 = (h.g) r8
            i.L0 r8 = r8.f996a
            i.t0 r8 = r8.f1120c
            r9 = 2
            int[] r11 = new int[r9]
            r8.getLocationOnScreen(r11)
            android.graphics.Rect r9 = new android.graphics.Rect
            r9.<init>()
            android.view.View r12 = r0.f1009o
            r12.getWindowVisibleDisplayFrame(r9)
            int r12 = r0.f1010p
            r13 = r16
            if (r12 != r13) goto L_0x014d
            r11 = r11[r10]
            int r8 = r8.getWidth()
            int r8 = r8 + r11
            int r8 = r8 + r5
            int r9 = r9.right
            if (r8 <= r9) goto L_0x014b
        L_0x0148:
            r8 = r10
        L_0x0149:
            r13 = 1
            goto L_0x0153
        L_0x014b:
            r8 = 1
            goto L_0x0149
        L_0x014d:
            r8 = r11[r10]
            int r8 = r8 - r5
            if (r8 >= 0) goto L_0x0148
            goto L_0x014b
        L_0x0153:
            if (r8 != r13) goto L_0x0157
            r13 = 1
            goto L_0x0158
        L_0x0157:
            r13 = r10
        L_0x0158:
            r0.f1010p = r8
            int r8 = android.os.Build.VERSION.SDK_INT
            r9 = 26
            r11 = 5
            if (r8 < r9) goto L_0x0166
            r7.f1131o = r6
            r9 = r10
            r12 = r9
            goto L_0x0199
        L_0x0166:
            r9 = 2
            int[] r8 = new int[r9]
            android.view.View r12 = r0.f1008n
            r12.getLocationOnScreen(r8)
            int[] r9 = new int[r9]
            r6.getLocationOnScreen(r9)
            int r12 = r0.f1007m
            r12 = r12 & 7
            if (r12 != r11) goto L_0x018d
            r12 = r8[r10]
            android.view.View r14 = r0.f1008n
            int r14 = r14.getWidth()
            int r14 = r14 + r12
            r8[r10] = r14
            r12 = r9[r10]
            int r14 = r6.getWidth()
            int r14 = r14 + r12
            r9[r10] = r14
        L_0x018d:
            r12 = r9[r10]
            r14 = r8[r10]
            int r12 = r12 - r14
            r16 = 1
            r9 = r9[r16]
            r8 = r8[r16]
            int r9 = r9 - r8
        L_0x0199:
            int r8 = r0.f1007m
            r8 = r8 & r11
            if (r8 != r11) goto L_0x01a8
            if (r13 == 0) goto L_0x01a2
            int r12 = r12 + r5
            goto L_0x01af
        L_0x01a2:
            int r5 = r6.getWidth()
        L_0x01a6:
            int r12 = r12 - r5
            goto L_0x01af
        L_0x01a8:
            if (r13 == 0) goto L_0x01a6
            int r5 = r6.getWidth()
            int r12 = r12 + r5
        L_0x01af:
            r7.f = r12
            r13 = 1
            r7.f1127k = r13
            r7.f1126j = r13
            r7.k(r9)
            goto L_0x01d8
        L_0x01ba:
            boolean r5 = r0.f1011q
            if (r5 == 0) goto L_0x01c2
            int r5 = r0.f1013s
            r7.f = r5
        L_0x01c2:
            boolean r5 = r0.f1012r
            if (r5 == 0) goto L_0x01cb
            int r5 = r0.f1014t
            r7.k(r5)
        L_0x01cb:
            android.graphics.Rect r5 = r0.f1089a
            if (r5 == 0) goto L_0x01d5
            android.graphics.Rect r9 = new android.graphics.Rect
            r9.<init>(r5)
            goto L_0x01d6
        L_0x01d5:
            r9 = 0
        L_0x01d6:
            r7.f1139w = r9
        L_0x01d8:
            h.g r5 = new h.g
            int r6 = r0.f1010p
            r5.<init>(r7, r1, r6)
            r2.add(r5)
            r7.h()
            i.t0 r2 = r7.f1120c
            r2.setOnKeyListener(r0)
            if (r4 != 0) goto L_0x0215
            boolean r4 = r0.f1016v
            if (r4 == 0) goto L_0x0215
            java.lang.CharSequence r4 = r1.f1041m
            if (r4 == 0) goto L_0x0215
            r4 = 2131427346(0x7f0b0012, float:1.8476306E38)
            android.view.View r3 = r3.inflate(r4, r2, r10)
            android.widget.FrameLayout r3 = (android.widget.FrameLayout) r3
            r4 = 16908310(0x1020016, float:2.387729E-38)
            android.view.View r4 = r3.findViewById(r4)
            android.widget.TextView r4 = (android.widget.TextView) r4
            r3.setEnabled(r10)
            java.lang.CharSequence r1 = r1.f1041m
            r4.setText(r1)
            r9 = 0
            r2.addHeaderView(r3, r9, r10)
            r7.h()
        L_0x0215:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: h.h.v(h.n):void");
    }
}
