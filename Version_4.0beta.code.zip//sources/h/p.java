package h;

import C.j;
import D.g;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.LinearLayout;
import java.util.ArrayList;
import s.C0142a;
import t.C0147a;

public final class p implements C0147a {

    /* renamed from: A  reason: collision with root package name */
    public q f1055A;

    /* renamed from: B  reason: collision with root package name */
    public MenuItem.OnActionExpandListener f1056B;

    /* renamed from: C  reason: collision with root package name */
    public boolean f1057C = false;

    /* renamed from: a  reason: collision with root package name */
    public final int f1058a;
    public final int b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1059c;

    /* renamed from: d  reason: collision with root package name */
    public final int f1060d;

    /* renamed from: e  reason: collision with root package name */
    public CharSequence f1061e;
    public CharSequence f;

    /* renamed from: g  reason: collision with root package name */
    public Intent f1062g;

    /* renamed from: h  reason: collision with root package name */
    public char f1063h;

    /* renamed from: i  reason: collision with root package name */
    public int f1064i = 4096;

    /* renamed from: j  reason: collision with root package name */
    public char f1065j;

    /* renamed from: k  reason: collision with root package name */
    public int f1066k = 4096;

    /* renamed from: l  reason: collision with root package name */
    public Drawable f1067l;

    /* renamed from: m  reason: collision with root package name */
    public int f1068m = 0;

    /* renamed from: n  reason: collision with root package name */
    public final n f1069n;

    /* renamed from: o  reason: collision with root package name */
    public F f1070o;

    /* renamed from: p  reason: collision with root package name */
    public MenuItem.OnMenuItemClickListener f1071p;

    /* renamed from: q  reason: collision with root package name */
    public CharSequence f1072q;

    /* renamed from: r  reason: collision with root package name */
    public CharSequence f1073r;

    /* renamed from: s  reason: collision with root package name */
    public ColorStateList f1074s = null;

    /* renamed from: t  reason: collision with root package name */
    public PorterDuff.Mode f1075t = null;

    /* renamed from: u  reason: collision with root package name */
    public boolean f1076u = false;

    /* renamed from: v  reason: collision with root package name */
    public boolean f1077v = false;

    /* renamed from: w  reason: collision with root package name */
    public boolean f1078w = false;

    /* renamed from: x  reason: collision with root package name */
    public int f1079x = 16;

    /* renamed from: y  reason: collision with root package name */
    public int f1080y;

    /* renamed from: z  reason: collision with root package name */
    public View f1081z;

    public p(n nVar, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f1069n = nVar;
        this.f1058a = i3;
        this.b = i2;
        this.f1059c = i4;
        this.f1060d = i5;
        this.f1061e = charSequence;
        this.f1080y = i6;
    }

    public static void c(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    public final q a() {
        return this.f1055A;
    }

    public final C0147a b(q qVar) {
        this.f1081z = null;
        this.f1055A = qVar;
        this.f1069n.p(true);
        q qVar2 = this.f1055A;
        if (qVar2 != null) {
            qVar2.f1082a = new j(16, (Object) this);
            qVar2.b.setVisibilityListener(qVar2);
        }
        return this;
    }

    public final boolean collapseActionView() {
        if ((this.f1080y & 8) == 0) {
            return false;
        }
        if (this.f1081z == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1056B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f1069n.d(this);
        }
        return false;
    }

    public final Drawable d(Drawable drawable) {
        if (drawable != null && this.f1078w && (this.f1076u || this.f1077v)) {
            drawable = drawable.mutate();
            if (this.f1076u) {
                C0142a.h(drawable, this.f1074s);
            }
            if (this.f1077v) {
                C0142a.i(drawable, this.f1075t);
            }
            this.f1078w = false;
        }
        return drawable;
    }

    public final boolean e() {
        q qVar;
        if ((this.f1080y & 8) != 0) {
            if (this.f1081z == null && (qVar = this.f1055A) != null) {
                this.f1081z = qVar.b.onCreateActionView(this);
            }
            if (this.f1081z != null) {
                return true;
            }
        }
        return false;
    }

    public final boolean expandActionView() {
        if (!e()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1056B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f1069n.f(this);
        }
        return false;
    }

    public final void f(boolean z2) {
        if (z2) {
            this.f1079x |= 32;
        } else {
            this.f1079x &= -33;
        }
    }

    public final ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    public final View getActionView() {
        View view = this.f1081z;
        if (view != null) {
            return view;
        }
        q qVar = this.f1055A;
        if (qVar == null) {
            return null;
        }
        View onCreateActionView = qVar.b.onCreateActionView(this);
        this.f1081z = onCreateActionView;
        return onCreateActionView;
    }

    public final int getAlphabeticModifiers() {
        return this.f1066k;
    }

    public final char getAlphabeticShortcut() {
        return this.f1065j;
    }

    public final CharSequence getContentDescription() {
        return this.f1072q;
    }

    public final int getGroupId() {
        return this.b;
    }

    public final Drawable getIcon() {
        Drawable drawable = this.f1067l;
        if (drawable != null) {
            return d(drawable);
        }
        int i2 = this.f1068m;
        if (i2 == 0) {
            return null;
        }
        Drawable s2 = g.s(this.f1069n.f1031a, i2);
        this.f1068m = 0;
        this.f1067l = s2;
        return d(s2);
    }

    public final ColorStateList getIconTintList() {
        return this.f1074s;
    }

    public final PorterDuff.Mode getIconTintMode() {
        return this.f1075t;
    }

    public final Intent getIntent() {
        return this.f1062g;
    }

    public final int getItemId() {
        return this.f1058a;
    }

    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public final int getNumericModifiers() {
        return this.f1064i;
    }

    public final char getNumericShortcut() {
        return this.f1063h;
    }

    public final int getOrder() {
        return this.f1059c;
    }

    public final SubMenu getSubMenu() {
        return this.f1070o;
    }

    public final CharSequence getTitle() {
        return this.f1061e;
    }

    public final CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f;
        if (charSequence != null) {
            return charSequence;
        }
        return this.f1061e;
    }

    public final CharSequence getTooltipText() {
        return this.f1073r;
    }

    public final boolean hasSubMenu() {
        if (this.f1070o != null) {
            return true;
        }
        return false;
    }

    public final boolean isActionViewExpanded() {
        return this.f1057C;
    }

    public final boolean isCheckable() {
        if ((this.f1079x & 1) == 1) {
            return true;
        }
        return false;
    }

    public final boolean isChecked() {
        if ((this.f1079x & 2) == 2) {
            return true;
        }
        return false;
    }

    public final boolean isEnabled() {
        if ((this.f1079x & 16) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isVisible() {
        q qVar = this.f1055A;
        if (qVar == null || !qVar.b.overridesItemVisibility()) {
            if ((this.f1079x & 8) == 0) {
                return true;
            }
            return false;
        } else if ((this.f1079x & 8) != 0 || !this.f1055A.b.isVisible()) {
            return false;
        } else {
            return true;
        }
    }

    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    public final MenuItem setActionView(View view) {
        int i2;
        this.f1081z = view;
        this.f1055A = null;
        if (view != null && view.getId() == -1 && (i2 = this.f1058a) > 0) {
            view.setId(i2);
        }
        n nVar = this.f1069n;
        nVar.f1039k = true;
        nVar.p(true);
        return this;
    }

    public final MenuItem setAlphabeticShortcut(char c2) {
        if (this.f1065j == c2) {
            return this;
        }
        this.f1065j = Character.toLowerCase(c2);
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setCheckable(boolean z2) {
        int i2 = this.f1079x;
        boolean z3 = z2 | (i2 & true);
        this.f1079x = z3 ? 1 : 0;
        if (i2 != z3) {
            this.f1069n.p(false);
        }
        return this;
    }

    public final MenuItem setChecked(boolean z2) {
        boolean z3;
        int i2;
        int i3 = this.f1079x;
        int i4 = 2;
        if ((i3 & 4) != 0) {
            n nVar = this.f1069n;
            nVar.getClass();
            ArrayList arrayList = nVar.f;
            int size = arrayList.size();
            nVar.w();
            for (int i5 = 0; i5 < size; i5++) {
                p pVar = (p) arrayList.get(i5);
                if (pVar.b == this.b && (pVar.f1079x & 4) != 0 && pVar.isCheckable()) {
                    if (pVar == this) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    int i6 = pVar.f1079x;
                    int i7 = i6 & -3;
                    if (z3) {
                        i2 = 2;
                    } else {
                        i2 = 0;
                    }
                    int i8 = i2 | i7;
                    pVar.f1079x = i8;
                    if (i6 != i8) {
                        pVar.f1069n.p(false);
                    }
                }
            }
            nVar.v();
            return this;
        }
        int i9 = i3 & -3;
        if (!z2) {
            i4 = 0;
        }
        int i10 = i9 | i4;
        this.f1079x = i10;
        if (i3 != i10) {
            this.f1069n.p(false);
        }
        return this;
    }

    public final MenuItem setEnabled(boolean z2) {
        if (z2) {
            this.f1079x |= 16;
        } else {
            this.f1079x &= -17;
        }
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setIcon(Drawable drawable) {
        this.f1068m = 0;
        this.f1067l = drawable;
        this.f1078w = true;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1074s = colorStateList;
        this.f1076u = true;
        this.f1078w = true;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1075t = mode;
        this.f1077v = true;
        this.f1078w = true;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setIntent(Intent intent) {
        this.f1062g = intent;
        return this;
    }

    public final MenuItem setNumericShortcut(char c2) {
        if (this.f1063h == c2) {
            return this;
        }
        this.f1063h = c2;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f1056B = onActionExpandListener;
        return this;
    }

    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f1071p = onMenuItemClickListener;
        return this;
    }

    public final MenuItem setShortcut(char c2, char c3) {
        this.f1063h = c2;
        this.f1065j = Character.toLowerCase(c3);
        this.f1069n.p(false);
        return this;
    }

    public final void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 == 0 || i3 == 1 || i3 == 2) {
            this.f1080y = i2;
            n nVar = this.f1069n;
            nVar.f1039k = true;
            nVar.p(true);
            return;
        }
        throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
    }

    public final MenuItem setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    public final MenuItem setTitle(CharSequence charSequence) {
        this.f1061e = charSequence;
        this.f1069n.p(false);
        F f2 = this.f1070o;
        if (f2 != null) {
            f2.setHeaderTitle(charSequence);
        }
        return this;
    }

    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f = charSequence;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setVisible(boolean z2) {
        int i2;
        int i3 = this.f1079x;
        int i4 = i3 & -9;
        if (z2) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        int i5 = i2 | i4;
        this.f1079x = i5;
        if (i3 != i5) {
            n nVar = this.f1069n;
            nVar.f1036h = true;
            nVar.p(true);
        }
        return this;
    }

    public final String toString() {
        CharSequence charSequence = this.f1061e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public final C0147a setContentDescription(CharSequence charSequence) {
        this.f1072q = charSequence;
        this.f1069n.p(false);
        return this;
    }

    public final C0147a setTooltipText(CharSequence charSequence) {
        this.f1073r = charSequence;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.f1065j == c2 && this.f1066k == i2) {
            return this;
        }
        this.f1065j = Character.toLowerCase(c2);
        this.f1066k = KeyEvent.normalizeMetaState(i2);
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setNumericShortcut(char c2, int i2) {
        if (this.f1063h == c2 && this.f1064i == i2) {
            return this;
        }
        this.f1063h = c2;
        this.f1064i = KeyEvent.normalizeMetaState(i2);
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f1063h = c2;
        this.f1064i = KeyEvent.normalizeMetaState(i2);
        this.f1065j = Character.toLowerCase(c3);
        this.f1066k = KeyEvent.normalizeMetaState(i3);
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setIcon(int i2) {
        this.f1067l = null;
        this.f1068m = i2;
        this.f1078w = true;
        this.f1069n.p(false);
        return this;
    }

    public final MenuItem setTitle(int i2) {
        setTitle((CharSequence) this.f1069n.f1031a.getString(i2));
        return this;
    }

    public final MenuItem setActionView(int i2) {
        int i3;
        Context context = this.f1069n.f1031a;
        View inflate = LayoutInflater.from(context).inflate(i2, new LinearLayout(context), false);
        this.f1081z = inflate;
        this.f1055A = null;
        if (inflate != null && inflate.getId() == -1 && (i3 = this.f1058a) > 0) {
            inflate.setId(i3);
        }
        n nVar = this.f1069n;
        nVar.f1039k = true;
        nVar.p(true);
        return this;
    }
}
