package h;

public interface m {
    boolean b(p pVar);
}
