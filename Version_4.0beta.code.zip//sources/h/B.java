package h;

public interface B {
    void a(n nVar);
}
