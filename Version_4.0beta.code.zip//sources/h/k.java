package h;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.util.ArrayList;

public final class k extends BaseAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final n f1026a;
    public int b = -1;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1027c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f1028d;

    /* renamed from: e  reason: collision with root package name */
    public final LayoutInflater f1029e;
    public final int f;

    public k(n nVar, LayoutInflater layoutInflater, boolean z2, int i2) {
        this.f1028d = z2;
        this.f1029e = layoutInflater;
        this.f1026a = nVar;
        this.f = i2;
        a();
    }

    public final void a() {
        n nVar = this.f1026a;
        p pVar = nVar.f1050v;
        if (pVar != null) {
            nVar.i();
            ArrayList arrayList = nVar.f1038j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((p) arrayList.get(i2)) == pVar) {
                    this.b = i2;
                    return;
                }
            }
        }
        this.b = -1;
    }

    /* renamed from: b */
    public final p getItem(int i2) {
        ArrayList arrayList;
        n nVar = this.f1026a;
        if (this.f1028d) {
            nVar.i();
            arrayList = nVar.f1038j;
        } else {
            arrayList = nVar.l();
        }
        int i3 = this.b;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (p) arrayList.get(i2);
    }

    public final int getCount() {
        ArrayList arrayList;
        n nVar = this.f1026a;
        if (this.f1028d) {
            nVar.i();
            arrayList = nVar.f1038j;
        } else {
            arrayList = nVar.l();
        }
        if (this.b < 0) {
            return arrayList.size();
        }
        return arrayList.size() - 1;
    }

    public final long getItemId(int i2) {
        return (long) i2;
    }

    public final View getView(int i2, View view, ViewGroup viewGroup) {
        int i3;
        boolean z2 = false;
        if (view == null) {
            view = this.f1029e.inflate(this.f, viewGroup, false);
        }
        int i4 = getItem(i2).b;
        int i5 = i2 - 1;
        if (i5 >= 0) {
            i3 = getItem(i5).b;
        } else {
            i3 = i4;
        }
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        if (this.f1026a.m() && i4 != i3) {
            z2 = true;
        }
        listMenuItemView.setGroupDividerEnabled(z2);
        C0036A a2 = (C0036A) view;
        if (this.f1027c) {
            listMenuItemView.setForceShowIcon(true);
        }
        a2.c(getItem(i2));
        return view;
    }

    public final void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
