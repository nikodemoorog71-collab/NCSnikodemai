package h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public final class F extends n implements SubMenu {

    /* renamed from: A  reason: collision with root package name */
    public final p f973A;

    /* renamed from: z  reason: collision with root package name */
    public final n f974z;

    public F(Context context, n nVar, p pVar) {
        super(context);
        this.f974z = nVar;
        this.f973A = pVar;
    }

    public final boolean d(p pVar) {
        return this.f974z.d(pVar);
    }

    public final boolean e(n nVar, MenuItem menuItem) {
        if (super.e(nVar, menuItem) || this.f974z.e(nVar, menuItem)) {
            return true;
        }
        return false;
    }

    public final boolean f(p pVar) {
        return this.f974z.f(pVar);
    }

    public final MenuItem getItem() {
        return this.f973A;
    }

    public final String j() {
        int i2;
        p pVar = this.f973A;
        if (pVar != null) {
            i2 = pVar.f1058a;
        } else {
            i2 = 0;
        }
        if (i2 == 0) {
            return null;
        }
        return "android:menu:actionviewstates:" + i2;
    }

    public final n k() {
        return this.f974z.k();
    }

    public final boolean m() {
        return this.f974z.m();
    }

    public final boolean n() {
        return this.f974z.n();
    }

    public final boolean o() {
        return this.f974z.o();
    }

    public final void setGroupDividerEnabled(boolean z2) {
        this.f974z.setGroupDividerEnabled(z2);
    }

    public final SubMenu setHeaderIcon(Drawable drawable) {
        u(0, (CharSequence) null, 0, drawable, (View) null);
        return this;
    }

    public final SubMenu setHeaderTitle(CharSequence charSequence) {
        u(0, charSequence, 0, (Drawable) null, (View) null);
        return this;
    }

    public final SubMenu setHeaderView(View view) {
        u(0, (CharSequence) null, 0, (Drawable) null, view);
        return this;
    }

    public final SubMenu setIcon(Drawable drawable) {
        this.f973A.setIcon(drawable);
        return this;
    }

    public final void setQwertyMode(boolean z2) {
        this.f974z.setQwertyMode(z2);
    }

    public final SubMenu setHeaderIcon(int i2) {
        u(0, (CharSequence) null, i2, (Drawable) null, (View) null);
        return this;
    }

    public final SubMenu setHeaderTitle(int i2) {
        u(i2, (CharSequence) null, 0, (Drawable) null, (View) null);
        return this;
    }

    public final SubMenu setIcon(int i2) {
        this.f973A.setIcon(i2);
        return this;
    }
}
