package h;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import nikodemai.firmware.ncs.R;

public class x {

    /* renamed from: a  reason: collision with root package name */
    public final Context f1091a;
    public final n b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f1092c;

    /* renamed from: d  reason: collision with root package name */
    public final int f1093d;

    /* renamed from: e  reason: collision with root package name */
    public View f1094e;
    public int f = 8388611;

    /* renamed from: g  reason: collision with root package name */
    public boolean f1095g;

    /* renamed from: h  reason: collision with root package name */
    public y f1096h;

    /* renamed from: i  reason: collision with root package name */
    public v f1097i;

    /* renamed from: j  reason: collision with root package name */
    public w f1098j;

    /* renamed from: k  reason: collision with root package name */
    public final w f1099k = new w(this);

    public x(int i2, Context context, View view, n nVar, boolean z2) {
        this.f1091a = context;
        this.b = nVar;
        this.f1094e = view;
        this.f1092c = z2;
        this.f1093d = i2;
    }

    public final v a() {
        v vVar;
        if (this.f1097i == null) {
            Context context = this.f1091a;
            Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getRealSize(point);
            if (Math.min(point.x, point.y) >= context.getResources().getDimensionPixelSize(R.dimen.abc_cascading_menus_min_smallest_width)) {
                vVar = new h(context, this.f1094e, this.f1093d, this.f1092c);
            } else {
                View view = this.f1094e;
                Context context2 = this.f1091a;
                boolean z2 = this.f1092c;
                vVar = new E(this.f1093d, context2, view, this.b, z2);
            }
            vVar.l(this.b);
            vVar.r(this.f1099k);
            vVar.n(this.f1094e);
            vVar.e(this.f1096h);
            vVar.o(this.f1095g);
            vVar.p(this.f);
            this.f1097i = vVar;
        }
        return this.f1097i;
    }

    public final boolean b() {
        v vVar = this.f1097i;
        if (vVar == null || !vVar.a()) {
            return false;
        }
        return true;
    }

    public void c() {
        this.f1097i = null;
        w wVar = this.f1098j;
        if (wVar != null) {
            wVar.onDismiss();
        }
    }

    public final void d(int i2, int i3, boolean z2, boolean z3) {
        v a2 = a();
        a2.s(z3);
        if (z2) {
            if ((Gravity.getAbsoluteGravity(this.f, this.f1094e.getLayoutDirection()) & 7) == 5) {
                i2 -= this.f1094e.getWidth();
            }
            a2.q(i2);
            a2.t(i3);
            int i4 = (int) ((this.f1091a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            a2.f1089a = new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4);
        }
        a2.h();
    }
}
