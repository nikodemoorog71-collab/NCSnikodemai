package h;

public interface y {
    void b(n nVar, boolean z2);

    boolean m(n nVar);
}
