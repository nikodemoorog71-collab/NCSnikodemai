package h;

import android.view.MenuItem;

public final class t implements MenuItem.OnMenuItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final MenuItem.OnMenuItemClickListener f1086a;
    public final /* synthetic */ u b;

    public t(u uVar, MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.b = uVar;
        this.f1086a = onMenuItemClickListener;
    }

    public final boolean onMenuItemClick(MenuItem menuItem) {
        return this.f1086a.onMenuItemClick(this.b.f(menuItem));
    }
}
