package h;

import android.view.View;
import android.view.ViewTreeObserver;

/* renamed from: h.e  reason: case insensitive filesystem */
public final class C0041e implements View.OnAttachStateChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f992a;
    public final /* synthetic */ v b;

    public /* synthetic */ C0041e(v vVar, int i2) {
        this.f992a = i2;
        this.b = vVar;
    }

    public final void onViewAttachedToWindow(View view) {
        int i2 = this.f992a;
    }

    public final void onViewDetachedFromWindow(View view) {
        switch (this.f992a) {
            case 0:
                h hVar = (h) this.b;
                ViewTreeObserver viewTreeObserver = hVar.f1018x;
                if (viewTreeObserver != null) {
                    if (!viewTreeObserver.isAlive()) {
                        hVar.f1018x = view.getViewTreeObserver();
                    }
                    hVar.f1018x.removeGlobalOnLayoutListener(hVar.f1003i);
                }
                view.removeOnAttachStateChangeListener(this);
                return;
            default:
                E e2 = (E) this.b;
                ViewTreeObserver viewTreeObserver2 = e2.f967o;
                if (viewTreeObserver2 != null) {
                    if (!viewTreeObserver2.isAlive()) {
                        e2.f967o = view.getViewTreeObserver();
                    }
                    e2.f967o.removeGlobalOnLayoutListener(e2.f961i);
                }
                view.removeOnAttachStateChangeListener(this);
                return;
        }
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }
}
