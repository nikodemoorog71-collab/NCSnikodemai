package h;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import p.C0117a;
import s.C0142a;
import t.C0147a;

/* renamed from: h.a  reason: case insensitive filesystem */
public final class C0037a implements C0147a {

    /* renamed from: a  reason: collision with root package name */
    public CharSequence f975a;
    public CharSequence b;

    /* renamed from: c  reason: collision with root package name */
    public Intent f976c;

    /* renamed from: d  reason: collision with root package name */
    public char f977d;

    /* renamed from: e  reason: collision with root package name */
    public int f978e;
    public char f;

    /* renamed from: g  reason: collision with root package name */
    public int f979g;

    /* renamed from: h  reason: collision with root package name */
    public Drawable f980h;

    /* renamed from: i  reason: collision with root package name */
    public Context f981i;

    /* renamed from: j  reason: collision with root package name */
    public CharSequence f982j;

    /* renamed from: k  reason: collision with root package name */
    public CharSequence f983k;

    /* renamed from: l  reason: collision with root package name */
    public ColorStateList f984l;

    /* renamed from: m  reason: collision with root package name */
    public PorterDuff.Mode f985m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f986n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f987o;

    /* renamed from: p  reason: collision with root package name */
    public int f988p;

    public final q a() {
        return null;
    }

    public final C0147a b(q qVar) {
        throw new UnsupportedOperationException();
    }

    public final void c() {
        Drawable drawable = this.f980h;
        if (drawable == null) {
            return;
        }
        if (this.f986n || this.f987o) {
            this.f980h = drawable;
            Drawable mutate = drawable.mutate();
            this.f980h = mutate;
            if (this.f986n) {
                C0142a.h(mutate, this.f984l);
            }
            if (this.f987o) {
                C0142a.i(this.f980h, this.f985m);
            }
        }
    }

    public final boolean collapseActionView() {
        return false;
    }

    public final boolean expandActionView() {
        return false;
    }

    public final ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    public final View getActionView() {
        return null;
    }

    public final int getAlphabeticModifiers() {
        return this.f979g;
    }

    public final char getAlphabeticShortcut() {
        return this.f;
    }

    public final CharSequence getContentDescription() {
        return this.f982j;
    }

    public final int getGroupId() {
        return 0;
    }

    public final Drawable getIcon() {
        return this.f980h;
    }

    public final ColorStateList getIconTintList() {
        return this.f984l;
    }

    public final PorterDuff.Mode getIconTintMode() {
        return this.f985m;
    }

    public final Intent getIntent() {
        return this.f976c;
    }

    public final int getItemId() {
        return 16908332;
    }

    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public final int getNumericModifiers() {
        return this.f978e;
    }

    public final char getNumericShortcut() {
        return this.f977d;
    }

    public final int getOrder() {
        return 0;
    }

    public final SubMenu getSubMenu() {
        return null;
    }

    public final CharSequence getTitle() {
        return this.f975a;
    }

    public final CharSequence getTitleCondensed() {
        CharSequence charSequence = this.b;
        if (charSequence != null) {
            return charSequence;
        }
        return this.f975a;
    }

    public final CharSequence getTooltipText() {
        return this.f983k;
    }

    public final boolean hasSubMenu() {
        return false;
    }

    public final boolean isActionViewExpanded() {
        return false;
    }

    public final boolean isCheckable() {
        if ((this.f988p & 1) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isChecked() {
        if ((this.f988p & 2) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isEnabled() {
        if ((this.f988p & 16) != 0) {
            return true;
        }
        return false;
    }

    public final boolean isVisible() {
        if ((this.f988p & 8) == 0) {
            return true;
        }
        return false;
    }

    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public final MenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    public final MenuItem setAlphabeticShortcut(char c2) {
        this.f = Character.toLowerCase(c2);
        return this;
    }

    public final MenuItem setCheckable(boolean z2) {
        this.f988p = z2 | (this.f988p & true) ? 1 : 0;
        return this;
    }

    public final MenuItem setChecked(boolean z2) {
        int i2;
        int i3 = this.f988p & -3;
        if (z2) {
            i2 = 2;
        } else {
            i2 = 0;
        }
        this.f988p = i2 | i3;
        return this;
    }

    public final MenuItem setContentDescription(CharSequence charSequence) {
        this.f982j = charSequence;
        return this;
    }

    public final MenuItem setEnabled(boolean z2) {
        int i2;
        int i3 = this.f988p & -17;
        if (z2) {
            i2 = 16;
        } else {
            i2 = 0;
        }
        this.f988p = i2 | i3;
        return this;
    }

    public final MenuItem setIcon(Drawable drawable) {
        this.f980h = drawable;
        c();
        return this;
    }

    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f984l = colorStateList;
        this.f986n = true;
        c();
        return this;
    }

    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f985m = mode;
        this.f987o = true;
        c();
        return this;
    }

    public final MenuItem setIntent(Intent intent) {
        this.f976c = intent;
        return this;
    }

    public final MenuItem setNumericShortcut(char c2) {
        this.f977d = c2;
        return this;
    }

    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    public final MenuItem setShortcut(char c2, char c3) {
        this.f977d = c2;
        this.f = Character.toLowerCase(c3);
        return this;
    }

    public final MenuItem setTitle(CharSequence charSequence) {
        this.f975a = charSequence;
        return this;
    }

    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.b = charSequence;
        return this;
    }

    public final MenuItem setTooltipText(CharSequence charSequence) {
        this.f983k = charSequence;
        return this;
    }

    public final MenuItem setVisible(boolean z2) {
        int i2 = 8;
        int i3 = this.f988p & 8;
        if (z2) {
            i2 = 0;
        }
        this.f988p = i3 | i2;
        return this;
    }

    public final MenuItem setActionView(int i2) {
        throw new UnsupportedOperationException();
    }

    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        this.f = Character.toLowerCase(c2);
        this.f979g = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    /* renamed from: setContentDescription  reason: collision with other method in class */
    public final C0147a m9setContentDescription(CharSequence charSequence) {
        this.f982j = charSequence;
        return this;
    }

    public final MenuItem setNumericShortcut(char c2, int i2) {
        this.f977d = c2;
        this.f978e = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    public final MenuItem setTitle(int i2) {
        this.f975a = this.f981i.getResources().getString(i2);
        return this;
    }

    /* renamed from: setTooltipText  reason: collision with other method in class */
    public final C0147a m10setTooltipText(CharSequence charSequence) {
        this.f983k = charSequence;
        return this;
    }

    public final MenuItem setIcon(int i2) {
        this.f980h = C0117a.b(this.f981i, i2);
        c();
        return this;
    }

    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f977d = c2;
        this.f978e = KeyEvent.normalizeMetaState(i2);
        this.f = Character.toLowerCase(c3);
        this.f979g = KeyEvent.normalizeMetaState(i3);
        return this;
    }

    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        return this;
    }

    public final void setShowAsAction(int i2) {
    }

    public final MenuItem setShowAsActionFlags(int i2) {
        return this;
    }
}
