package h;

import android.view.View;
import android.view.ViewTreeObserver;
import i.L0;
import i.O;
import i.S;
import java.util.ArrayList;

/* renamed from: h.d  reason: case insensitive filesystem */
public final class C0040d implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f991a;
    public final /* synthetic */ Object b;

    public /* synthetic */ C0040d(int i2, Object obj) {
        this.f991a = i2;
        this.b = obj;
    }

    public final void onGlobalLayout() {
        switch (this.f991a) {
            case 0:
                h hVar = (h) this.b;
                if (hVar.a()) {
                    ArrayList arrayList = hVar.f1002h;
                    if (arrayList.size() > 0) {
                        int i2 = 0;
                        if (!((g) arrayList.get(0)).f996a.f1140x) {
                            View view = hVar.f1009o;
                            if (view == null || !view.isShown()) {
                                hVar.dismiss();
                                return;
                            }
                            int size = arrayList.size();
                            while (i2 < size) {
                                Object obj = arrayList.get(i2);
                                i2++;
                                ((g) obj).f996a.h();
                            }
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            case 1:
                E e2 = (E) this.b;
                if (e2.a()) {
                    L0 l0 = e2.f960h;
                    if (!l0.f1140x) {
                        View view2 = e2.f965m;
                        if (view2 == null || !view2.isShown()) {
                            e2.dismiss();
                            return;
                        } else {
                            l0.h();
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            case 2:
                S s2 = (S) this.b;
                if (!s2.getInternalPopup().a()) {
                    s2.f.e(s2.getTextDirection(), s2.getTextAlignment());
                }
                ViewTreeObserver viewTreeObserver = s2.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeOnGlobalLayoutListener(this);
                    return;
                }
                return;
            default:
                O o2 = (O) this.b;
                S s3 = o2.f1169F;
                o2.getClass();
                if (!s3.isAttachedToWindow() || !s3.getGlobalVisibleRect(o2.f1167D)) {
                    o2.dismiss();
                    return;
                }
                o2.q();
                o2.h();
                return;
        }
    }
}
