package h;

import android.content.Context;

public interface z {
    void b(n nVar, boolean z2);

    void c();

    boolean d(p pVar);

    void e(y yVar);

    void g(Context context, n nVar);

    boolean i();

    boolean j(F f);

    boolean k(p pVar);
}
