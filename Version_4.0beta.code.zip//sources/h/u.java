package h;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import e.z;
import java.lang.reflect.Method;
import t.C0147a;

public final class u extends z implements MenuItem {

    /* renamed from: c  reason: collision with root package name */
    public final C0147a f1087c;

    /* renamed from: d  reason: collision with root package name */
    public Method f1088d;

    public u(Context context, C0147a aVar) {
        super(context);
        if (aVar != null) {
            this.f1087c = aVar;
            return;
        }
        throw new IllegalArgumentException("Wrapped Object can not be null.");
    }

    public final boolean collapseActionView() {
        return this.f1087c.collapseActionView();
    }

    public final boolean expandActionView() {
        return this.f1087c.expandActionView();
    }

    public final ActionProvider getActionProvider() {
        q a2 = this.f1087c.a();
        if (a2 != null) {
            return a2.b;
        }
        return null;
    }

    public final View getActionView() {
        View actionView = this.f1087c.getActionView();
        if (actionView instanceof r) {
            return (View) ((r) actionView).f1084a;
        }
        return actionView;
    }

    public final int getAlphabeticModifiers() {
        return this.f1087c.getAlphabeticModifiers();
    }

    public final char getAlphabeticShortcut() {
        return this.f1087c.getAlphabeticShortcut();
    }

    public final CharSequence getContentDescription() {
        return this.f1087c.getContentDescription();
    }

    public final int getGroupId() {
        return this.f1087c.getGroupId();
    }

    public final Drawable getIcon() {
        return this.f1087c.getIcon();
    }

    public final ColorStateList getIconTintList() {
        return this.f1087c.getIconTintList();
    }

    public final PorterDuff.Mode getIconTintMode() {
        return this.f1087c.getIconTintMode();
    }

    public final Intent getIntent() {
        return this.f1087c.getIntent();
    }

    public final int getItemId() {
        return this.f1087c.getItemId();
    }

    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f1087c.getMenuInfo();
    }

    public final int getNumericModifiers() {
        return this.f1087c.getNumericModifiers();
    }

    public final char getNumericShortcut() {
        return this.f1087c.getNumericShortcut();
    }

    public final int getOrder() {
        return this.f1087c.getOrder();
    }

    public final SubMenu getSubMenu() {
        return this.f1087c.getSubMenu();
    }

    public final CharSequence getTitle() {
        return this.f1087c.getTitle();
    }

    public final CharSequence getTitleCondensed() {
        return this.f1087c.getTitleCondensed();
    }

    public final CharSequence getTooltipText() {
        return this.f1087c.getTooltipText();
    }

    public final boolean hasSubMenu() {
        return this.f1087c.hasSubMenu();
    }

    public final boolean isActionViewExpanded() {
        return this.f1087c.isActionViewExpanded();
    }

    public final boolean isCheckable() {
        return this.f1087c.isCheckable();
    }

    public final boolean isChecked() {
        return this.f1087c.isChecked();
    }

    public final boolean isEnabled() {
        return this.f1087c.isEnabled();
    }

    public final boolean isVisible() {
        return this.f1087c.isVisible();
    }

    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        q qVar = new q(this, actionProvider);
        if (actionProvider == null) {
            qVar = null;
        }
        this.f1087c.b(qVar);
        return this;
    }

    public final MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new r(view);
        }
        this.f1087c.setActionView(view);
        return this;
    }

    public final MenuItem setAlphabeticShortcut(char c2) {
        this.f1087c.setAlphabeticShortcut(c2);
        return this;
    }

    public final MenuItem setCheckable(boolean z2) {
        this.f1087c.setCheckable(z2);
        return this;
    }

    public final MenuItem setChecked(boolean z2) {
        this.f1087c.setChecked(z2);
        return this;
    }

    public final MenuItem setContentDescription(CharSequence charSequence) {
        this.f1087c.setContentDescription(charSequence);
        return this;
    }

    public final MenuItem setEnabled(boolean z2) {
        this.f1087c.setEnabled(z2);
        return this;
    }

    public final MenuItem setIcon(Drawable drawable) {
        this.f1087c.setIcon(drawable);
        return this;
    }

    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1087c.setIconTintList(colorStateList);
        return this;
    }

    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1087c.setIconTintMode(mode);
        return this;
    }

    public final MenuItem setIntent(Intent intent) {
        this.f1087c.setIntent(intent);
        return this;
    }

    public final MenuItem setNumericShortcut(char c2) {
        this.f1087c.setNumericShortcut(c2);
        return this;
    }

    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        s sVar;
        if (onActionExpandListener != null) {
            sVar = new s(this, onActionExpandListener);
        } else {
            sVar = null;
        }
        this.f1087c.setOnActionExpandListener(sVar);
        return this;
    }

    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        t tVar;
        if (onMenuItemClickListener != null) {
            tVar = new t(this, onMenuItemClickListener);
        } else {
            tVar = null;
        }
        this.f1087c.setOnMenuItemClickListener(tVar);
        return this;
    }

    public final MenuItem setShortcut(char c2, char c3) {
        this.f1087c.setShortcut(c2, c3);
        return this;
    }

    public final void setShowAsAction(int i2) {
        this.f1087c.setShowAsAction(i2);
    }

    public final MenuItem setShowAsActionFlags(int i2) {
        this.f1087c.setShowAsActionFlags(i2);
        return this;
    }

    public final MenuItem setTitle(CharSequence charSequence) {
        this.f1087c.setTitle(charSequence);
        return this;
    }

    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f1087c.setTitleCondensed(charSequence);
        return this;
    }

    public final MenuItem setTooltipText(CharSequence charSequence) {
        this.f1087c.setTooltipText(charSequence);
        return this;
    }

    public final MenuItem setVisible(boolean z2) {
        return this.f1087c.setVisible(z2);
    }

    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        this.f1087c.setAlphabeticShortcut(c2, i2);
        return this;
    }

    public final MenuItem setIcon(int i2) {
        this.f1087c.setIcon(i2);
        return this;
    }

    public final MenuItem setNumericShortcut(char c2, int i2) {
        this.f1087c.setNumericShortcut(c2, i2);
        return this;
    }

    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f1087c.setShortcut(c2, c3, i2, i3);
        return this;
    }

    public final MenuItem setTitle(int i2) {
        this.f1087c.setTitle(i2);
        return this;
    }

    public final MenuItem setActionView(int i2) {
        C0147a aVar = this.f1087c;
        aVar.setActionView(i2);
        View actionView = aVar.getActionView();
        if (actionView instanceof CollapsibleActionView) {
            aVar.setActionView(new r(actionView));
        }
        return this;
    }
}
