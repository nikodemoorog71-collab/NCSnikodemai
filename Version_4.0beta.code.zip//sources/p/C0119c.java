package p;

import android.content.Context;
import java.io.File;

/* renamed from: p.c  reason: case insensitive filesystem */
public abstract class C0119c {
    public static File[] a(Context context) {
        return context.getExternalMediaDirs();
    }
}
