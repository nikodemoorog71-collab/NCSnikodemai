package g;

import android.view.View;
import android.view.animation.BaseInterpolator;
import java.util.ArrayList;
import y.Q;
import z.C0190i;

/* renamed from: g.j  reason: case insensitive filesystem */
public final class C0034j {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList f951a = new ArrayList();
    public long b = -1;

    /* renamed from: c  reason: collision with root package name */
    public BaseInterpolator f952c;

    /* renamed from: d  reason: collision with root package name */
    public C0190i f953d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f954e;
    public final C0033i f = new C0033i(this);

    public final void a() {
        if (this.f954e) {
            ArrayList arrayList = this.f951a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                ((Q) obj).b();
            }
            this.f954e = false;
        }
    }

    public final void b() {
        View view;
        if (!this.f954e) {
            ArrayList arrayList = this.f951a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                Q q2 = (Q) obj;
                long j2 = this.b;
                if (j2 >= 0) {
                    q2.c(j2);
                }
                BaseInterpolator baseInterpolator = this.f952c;
                if (!(baseInterpolator == null || (view = (View) q2.f1553a.get()) == null)) {
                    view.animate().setInterpolator(baseInterpolator);
                }
                if (this.f953d != null) {
                    q2.d(this.f);
                }
                View view2 = (View) q2.f1553a.get();
                if (view2 != null) {
                    view2.animate().start();
                }
            }
            this.f954e = true;
        }
    }
}
