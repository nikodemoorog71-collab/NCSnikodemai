package m;

public final class f {

    /* renamed from: c  reason: collision with root package name */
    public static final f f1432c = new Object();

    /* renamed from: a  reason: collision with root package name */
    public volatile Thread f1433a;
    public volatile f b;

    public f() {
        g.f.L(this, Thread.currentThread());
    }
}
