package m;

/* renamed from: m.c  reason: case insensitive filesystem */
public final class C0114c {
    public static final C0114c b = new Object();

    /* renamed from: a  reason: collision with root package name */
    public C0114c f1426a;
}
