package m;

import D.g;

public final class e extends g {
    public final void K(f fVar, f fVar2) {
        fVar.b = fVar2;
    }

    public final void L(f fVar, Thread thread) {
        fVar.f1433a = thread;
    }

    public final boolean a(g gVar, C0114c cVar) {
        C0114c cVar2 = C0114c.b;
        synchronized (gVar) {
            try {
                if (gVar.b != cVar) {
                    return false;
                }
                gVar.b = cVar2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean b(g gVar, Object obj, Object obj2) {
        synchronized (gVar) {
            try {
                if (gVar.f1437a != obj) {
                    return false;
                }
                gVar.f1437a = obj2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean c(g gVar, f fVar, f fVar2) {
        synchronized (gVar) {
            try {
                if (gVar.f1438c != fVar) {
                    return false;
                }
                gVar.f1438c = fVar2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
