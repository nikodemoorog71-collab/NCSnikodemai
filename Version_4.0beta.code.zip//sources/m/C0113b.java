package m;

/* renamed from: m.b  reason: case insensitive filesystem */
public abstract class C0113b {
}
