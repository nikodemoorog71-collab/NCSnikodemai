package m;

import java.util.concurrent.CancellationException;

/* renamed from: m.a  reason: case insensitive filesystem */
public final class C0112a {
    public static final C0112a b;

    /* renamed from: c  reason: collision with root package name */
    public static final C0112a f1424c;

    /* renamed from: a  reason: collision with root package name */
    public final CancellationException f1425a;

    static {
        if (g.f1434d) {
            f1424c = null;
            b = null;
            return;
        }
        f1424c = new C0112a(false, (CancellationException) null);
        b = new C0112a(true, (CancellationException) null);
    }

    public C0112a(boolean z2, CancellationException cancellationException) {
        this.f1425a = cancellationException;
    }
}
