package m;

import D.g;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class d extends g {

    /* renamed from: o  reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1427o;

    /* renamed from: p  reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1428p;

    /* renamed from: q  reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1429q;

    /* renamed from: r  reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1430r;

    /* renamed from: s  reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1431s;

    public d(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
        this.f1427o = atomicReferenceFieldUpdater;
        this.f1428p = atomicReferenceFieldUpdater2;
        this.f1429q = atomicReferenceFieldUpdater3;
        this.f1430r = atomicReferenceFieldUpdater4;
        this.f1431s = atomicReferenceFieldUpdater5;
    }

    public final void K(f fVar, f fVar2) {
        this.f1428p.lazySet(fVar, fVar2);
    }

    public final void L(f fVar, Thread thread) {
        this.f1427o.lazySet(fVar, thread);
    }

    public final boolean a(g gVar, C0114c cVar) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        C0114c cVar2 = C0114c.b;
        do {
            atomicReferenceFieldUpdater = this.f1430r;
            if (atomicReferenceFieldUpdater.compareAndSet(gVar, cVar, cVar2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(gVar) == cVar);
        return false;
    }

    public final boolean b(g gVar, Object obj, Object obj2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f1431s;
            if (atomicReferenceFieldUpdater.compareAndSet(gVar, obj, obj2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(gVar) == obj);
        return false;
    }

    public final boolean c(g gVar, f fVar, f fVar2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f1429q;
            if (atomicReferenceFieldUpdater.compareAndSet(gVar, fVar, fVar2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(gVar) == fVar);
        return false;
    }
}
