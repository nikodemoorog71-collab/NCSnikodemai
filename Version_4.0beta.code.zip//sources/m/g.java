package m;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class g implements Future {

    /* renamed from: d  reason: collision with root package name */
    public static final boolean f1434d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* renamed from: e  reason: collision with root package name */
    public static final Logger f1435e;
    public static final D.g f;

    /* renamed from: g  reason: collision with root package name */
    public static final Object f1436g = new Object();

    /* renamed from: a  reason: collision with root package name */
    public volatile Object f1437a;
    public volatile C0114c b;

    /* renamed from: c  reason: collision with root package name */
    public volatile f f1438c;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v0, resolved type: m.d} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v3, resolved type: m.d} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v4, resolved type: m.d} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.String r0 = "b"
            java.lang.String r1 = "a"
            java.lang.Class<m.f> r2 = m.f.class
            java.lang.String r3 = "guava.concurrent.generate_cancellation_cause"
            java.lang.String r4 = "false"
            java.lang.String r3 = java.lang.System.getProperty(r3, r4)
            boolean r3 = java.lang.Boolean.parseBoolean(r3)
            f1434d = r3
            java.lang.Class<m.g> r3 = m.g.class
            java.lang.String r4 = r3.getName()
            java.util.logging.Logger r4 = java.util.logging.Logger.getLogger(r4)
            f1435e = r4
            m.d r5 = new m.d     // Catch:{ all -> 0x0043 }
            java.lang.Class<java.lang.Thread> r4 = java.lang.Thread.class
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r6 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r2, r4, r1)     // Catch:{ all -> 0x0043 }
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r2, r2, r0)     // Catch:{ all -> 0x0043 }
            java.lang.String r4 = "c"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r3, r2, r4)     // Catch:{ all -> 0x0043 }
            java.lang.Class<m.c> r2 = m.C0114c.class
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r9 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r3, r2, r0)     // Catch:{ all -> 0x0043 }
            java.lang.Class<java.lang.Object> r0 = java.lang.Object.class
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r10 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r3, r0, r1)     // Catch:{ all -> 0x0043 }
            r5.<init>(r6, r7, r8, r9, r10)     // Catch:{ all -> 0x0043 }
            r0 = 0
            goto L_0x0049
        L_0x0043:
            r0 = move-exception
            m.e r5 = new m.e
            r5.<init>()
        L_0x0049:
            f = r5
            if (r0 == 0) goto L_0x0056
            java.util.logging.Logger r1 = f1435e
            java.util.logging.Level r2 = java.util.logging.Level.SEVERE
            java.lang.String r3 = "SafeAtomicHelper is broken!"
            r1.log(r2, r3, r0)
        L_0x0056:
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            f1436g = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: m.g.<clinit>():void");
    }

    public static void b(g gVar) {
        f fVar;
        C0114c cVar;
        do {
            fVar = gVar.f1438c;
        } while (!f.c(gVar, fVar, f.f1432c));
        while (fVar != null) {
            Thread thread = fVar.f1433a;
            if (thread != null) {
                fVar.f1433a = null;
                LockSupport.unpark(thread);
            }
            fVar = fVar.b;
        }
        do {
            cVar = gVar.b;
        } while (!f.a(gVar, cVar));
        C0114c cVar2 = null;
        while (cVar != null) {
            C0114c cVar3 = cVar.f1426a;
            cVar.f1426a = cVar2;
            cVar2 = cVar;
            cVar = cVar3;
        }
        while (cVar2 != null) {
            cVar2 = cVar2.f1426a;
            try {
                throw null;
            } catch (RuntimeException e2) {
                f1435e.log(Level.SEVERE, "RuntimeException while executing runnable null with executor null", e2);
            }
        }
    }

    public static Object c(Object obj) {
        if (obj instanceof C0112a) {
            CancellationException cancellationException = ((C0112a) obj).f1425a;
            CancellationException cancellationException2 = new CancellationException("Task was cancelled.");
            cancellationException2.initCause(cancellationException);
            throw cancellationException2;
        } else if (obj instanceof C0113b) {
            ((C0113b) obj).getClass();
            throw new ExecutionException((Throwable) null);
        } else if (obj == f1436g) {
            return null;
        } else {
            return obj;
        }
    }

    public static Object d(g gVar) {
        Object obj;
        boolean z2 = false;
        while (true) {
            try {
                obj = gVar.get();
                break;
            } catch (InterruptedException unused) {
                z2 = true;
            } catch (Throwable th) {
                if (z2) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z2) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    public final void a(StringBuilder sb) {
        String str;
        try {
            Object d2 = d(this);
            sb.append("SUCCESS, result=[");
            if (d2 == this) {
                str = "this future";
            } else {
                str = String.valueOf(d2);
            }
            sb.append(str);
            sb.append("]");
        } catch (ExecutionException e2) {
            sb.append("FAILURE, cause=[");
            sb.append(e2.getCause());
            sb.append("]");
        } catch (CancellationException unused) {
            sb.append("CANCELLED");
        } catch (RuntimeException e3) {
            sb.append("UNKNOWN, cause=[");
            sb.append(e3.getClass());
            sb.append(" thrown from get()]");
        }
    }

    public final boolean cancel(boolean z2) {
        C0112a aVar;
        Object obj = this.f1437a;
        if (obj != null) {
            return false;
        }
        if (f1434d) {
            aVar = new C0112a(z2, new CancellationException("Future.cancel() was called."));
        } else if (z2) {
            aVar = C0112a.b;
        } else {
            aVar = C0112a.f1424c;
        }
        if (!f.b(this, obj, aVar)) {
            return false;
        }
        b(this);
        return true;
    }

    public final void e(f fVar) {
        fVar.f1433a = null;
        while (true) {
            f fVar2 = this.f1438c;
            if (fVar2 != f.f1432c) {
                f fVar3 = null;
                while (fVar2 != null) {
                    f fVar4 = fVar2.b;
                    if (fVar2.f1433a != null) {
                        fVar3 = fVar2;
                    } else if (fVar3 != null) {
                        fVar3.b = fVar4;
                        if (fVar3.f1433a == null) {
                        }
                    } else if (!f.c(this, fVar2, fVar4)) {
                    }
                    fVar2 = fVar4;
                }
                return;
            }
            return;
        }
    }

    public final Object get(long j2, TimeUnit timeUnit) {
        long nanos = timeUnit.toNanos(j2);
        if (!Thread.interrupted()) {
            Object obj = this.f1437a;
            if (obj != null) {
                return c(obj);
            }
            long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0;
            if (nanos >= 1000) {
                f fVar = this.f1438c;
                f fVar2 = f.f1432c;
                if (fVar != fVar2) {
                    f fVar3 = new f();
                    do {
                        D.g gVar = f;
                        gVar.K(fVar3, fVar);
                        if (gVar.c(this, fVar, fVar3)) {
                            do {
                                LockSupport.parkNanos(this, nanos);
                                if (!Thread.interrupted()) {
                                    Object obj2 = this.f1437a;
                                    if (obj2 != null) {
                                        return c(obj2);
                                    }
                                    nanos = nanoTime - System.nanoTime();
                                } else {
                                    e(fVar3);
                                    throw new InterruptedException();
                                }
                            } while (nanos >= 1000);
                            e(fVar3);
                        } else {
                            fVar = this.f1438c;
                        }
                    } while (fVar != fVar2);
                }
                return c(this.f1437a);
            }
            while (nanos > 0) {
                Object obj3 = this.f1437a;
                if (obj3 != null) {
                    return c(obj3);
                }
                if (!Thread.interrupted()) {
                    nanos = nanoTime - System.nanoTime();
                } else {
                    throw new InterruptedException();
                }
            }
            String gVar2 = toString();
            String obj4 = timeUnit.toString();
            Locale locale = Locale.ROOT;
            String lowerCase = obj4.toLowerCase(locale);
            String str = "Waited " + j2 + " " + timeUnit.toString().toLowerCase(locale);
            if (nanos + 1000 < 0) {
                String str2 = str + " (plus ";
                long j3 = -nanos;
                long convert = timeUnit.convert(j3, TimeUnit.NANOSECONDS);
                long nanos2 = j3 - timeUnit.toNanos(convert);
                int i2 = (convert > 0 ? 1 : (convert == 0 ? 0 : -1));
                boolean z2 = i2 == 0 || nanos2 > 1000;
                if (i2 > 0) {
                    String str3 = str2 + convert + " " + lowerCase;
                    if (z2) {
                        str3 = str3 + ",";
                    }
                    str2 = str3 + " ";
                }
                if (z2) {
                    str2 = str2 + nanos2 + " nanoseconds ";
                }
                str = str2 + "delay)";
            }
            if (isDone()) {
                throw new TimeoutException(str + " but future completed as timeout expired");
            }
            throw new TimeoutException(str + " for " + gVar2);
        }
        throw new InterruptedException();
    }

    public final boolean isCancelled() {
        return this.f1437a instanceof C0112a;
    }

    public final boolean isDone() {
        if (this.f1437a != null) {
            return true;
        }
        return false;
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[status=");
        if (this.f1437a instanceof C0112a) {
            sb.append("CANCELLED");
        } else if (isDone()) {
            a(sb);
        } else {
            try {
                if (this instanceof ScheduledFuture) {
                    str = "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
                } else {
                    str = null;
                }
            } catch (RuntimeException e2) {
                str = "Exception thrown from implementation: " + e2.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb.append("PENDING, info=[");
                sb.append(str);
                sb.append("]");
            } else if (isDone()) {
                a(sb);
            } else {
                sb.append("PENDING");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    public final Object get() {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.f1437a;
            if (obj2 != null) {
                return c(obj2);
            }
            f fVar = this.f1438c;
            f fVar2 = f.f1432c;
            if (fVar != fVar2) {
                f fVar3 = new f();
                do {
                    D.g gVar = f;
                    gVar.K(fVar3, fVar);
                    if (gVar.c(this, fVar, fVar3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f1437a;
                            } else {
                                e(fVar3);
                                throw new InterruptedException();
                            }
                        } while (obj == null);
                        return c(obj);
                    }
                    fVar = this.f1438c;
                } while (fVar != fVar2);
            }
            return c(this.f1437a);
        }
        throw new InterruptedException();
    }
}
